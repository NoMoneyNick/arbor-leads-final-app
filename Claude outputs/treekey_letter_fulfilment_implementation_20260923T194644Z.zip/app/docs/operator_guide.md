# TreeKey letter-fulfilment: operator guide

This covers the system built this session (2026-09-18): the pipeline that
turns "a lead was purchased" into "a personalised introduction letter is
printed and posted to the homeowner". It assumes you're an admin/operator,
not a developer -- for the code-level design, read fulfilment.py's,
worker.py's, and letter_providers/registry.py's module docstrings, which
this guide summarises and cross-references rather than duplicates.

**Nothing described here is live.** No production migration has been run,
no provider has real credentials, and no code in this session's work calls
this pipeline from a scheduler or cron job. This guide describes how to
operate it once those decisions are made -- see
[`launch_checklist.md`](launch_checklist.md) for exactly what's still
outstanding.

## 1. The lifecycle, in plain terms

Every purchased/dispatched/free-granted lead gets one row in
`letter_obligations`, moving through these states in order:

1. **`blocked_missing_data`** -- the lead had no address on file. Dead end;
   needs manual investigation (why did a lead with no address get sold?).
2. **`pending_approval`** -- waiting for the buying contractor to have
   approved their current letter content (business name, phone, insurance
   note). A contractor does this themselves at `/letter-settings` ->
   `/letter-settings/preview` -> `/letter-settings/approve` (2026-09-18
   review, Section 1, second pass -- see section 1a below); nothing moves
   past this state without a genuine, current approval -- editing settings
   after approving resets `approved=FALSE` and drops any obligation still
   at this stage back to needing re-approval. One approval covers every
   future lead the contractor buys (it's checked against the reusable
   TEMPLATE fingerprint, not a specific lead's rendered letter -- see
   `letter_content.template_fingerprint`'s own docstring) until their
   settings actually change.
3. **`pending_funding`** -- template approved, waiting on the funding gate
   (see section 2).
4. **`ready`** -- eligible for submission. Not yet attempted.
5. **`submitting`** -- a worker has atomically claimed it and is (or, in
   dry-run, is pretending to be) calling a provider right now.
6. Terminal states: **`provider_accepted`**, **`dispatched`**,
   **`delivered`** (real success, in increasing order of confirmation),
   **`failed`** (every usable provider confirmed rejection), **`unknown`**
   (ambiguous -- see section 4, the most important one to understand),
   **`suppressed`** (blocked by an objection), **`cancelled`** (refund
   before submission), **`dry_run`** (completed in test mode, never a real
   send).

Query `letter_obligations` directly (`SELECT status, COUNT(*) FROM
letter_obligations GROUP BY status;`) to see where everything sits. There
is no admin UI for this yet -- see the launch checklist.

## 1a. Contractor letter setup, preview & approval

2026-09-18 review, Section 1 (second pass). Three contractor-facing routes
in `main.py`, each authenticated by the signed `treekey_contractor_session`
cookie only (never a query param or form field -- see the routes' own
comments):

- **`GET /letter-settings`** -- setup form: business name, phone, contact
  email, a template selector (`letter_content.TEMPLATE_REGISTRY` --
  Friendly Introduction / Professional and Factual / Short and Direct,
  currently placeholder wording pending Nick's final copy), a business
  introduction, relevant services, service area, and insurance/
  qualifications notes -- the last two (and the two new freeform fields)
  shown exactly as the contractor writes them; TreeKey never invents a
  claim, and never auto-adds "trusted"/"vetted"/"qualified"/"insured"/
  "free"/availability wording of its own (see
  `letter_content.BANNED_AUTO_CLAIM_WORDS` and
  `tests/test_letter_content.py`'s `TestNoAutoAddedClaimWords`). Every
  field has a length limit, plus a combined content budget across all of
  them, and rejects raw `<`/`>` characters outright (2026-09-23 handoff --
  see `ContractorLetterSettings.validate`). The locked privacy/data-
  source/contact-policy footer has no corresponding form field at all, on
  any template -- there is nothing for a contractor (or a tampered POST)
  to override.
- **`POST /letter-settings`** -- saves via
  `letter_content.upsert_contractor_settings`, always under the session's
  own `contractor_email`. Always resets `approved=FALSE` -- a material
  change requires renewed approval.
- **`GET /letter-settings/preview`** -- renders the exact template via
  `letter_content.render_preview_letter` (a thin wrapper around
  `render_letter`, the SAME function a real send uses) against fixed,
  clearly-illustrative sample lead data -- `contractor_letter_settings` is
  per-contractor, not per-lead, so there's no specific real lead to show
  at setup time.
- **`POST /letter-settings/approve`** -- records approval. The
  fingerprint passed to `letter_content.approve_template` is always
  computed server-side, in this same request, from whatever settings row
  is *currently* saved under the session's own `contractor_email` -- the
  request body isn't even parsed for one. This is what makes the
  approval genuinely correspond to the exact content/version being
  approved, rather than trusting a value the client could have supplied
  or that could have gone stale between page load and submission.

**Why one approval covers every future lead:** eligibility (checked by
`worker.promote_pending_approvals`) is matched against
`letter_content.template_fingerprint(settings)` -- the contractor-
controlled fields only (business name, phone, notes, template version) --
never a specific lead's full rendered letter. An earlier version of this
logic fingerprinted the full render, which meant an approval could only
ever match the one lead it happened to be computed against; every other
lead has a different address/summary/council baked into ITS render, so it
would never match and would sit in `pending_approval` forever regardless
of the contractor's settings being perfectly current. Fixed as part of
building this UI -- see `letter_content.template_fingerprint`'s own
docstring, and `tests/test_letter_settings_journey.py` for the test that
specifically proves reusability across two different real leads with only
one approval in between.

No admin UI exists yet to view/reconcile `blocked_missing_data` or
`unknown` rows, or to confirm a funding budget or add a suppression row --
see the launch checklist, item 10.

## 2. The funding gate (`funding.py`)

Controls whether any obligation can move from `pending_funding` to `ready`.
Set via the `FUNDING_MODE` environment variable (see
`.env.example.letter-fulfilment`):

- **`hold`** (default): nothing is eligible until an admin has run
  `FundingGate.confirm_budget(cur, amount_pence=..., confirmed_by=...,
  note=...)` -- there is currently no admin UI for this either; it must be
  called from a Python shell/admin script against the real database.
  Recommended starting mode.
- **`simulate`**: for local testing. `FundingGate.simulate_budget(pence)`
  sets an in-process budget that's never written to the database. Resets
  every time the process restarts.
- **`working_capital`**: always eligible, no confirmation needed at all.
  Not recommended without a real reconciliation process behind it -- this
  is "spend now, reconcile against the bank later."

**2026-09-18 review, Section 6 -- atomic reservation, not just a soft
check.** `gate.check()` above (used by `worker.promote_pending_funding` to
move `pending_funding` -> `ready`) is a cheap, non-atomic PRELIMINARY
filter -- it reads available budget but doesn't claim any of it. The real
protection happens one stage later, automatically, inside
`letter_providers.registry.attempt_send`, immediately before any provider
is called (and only for a real, non-dry-run send):

- `gate.reserve(cur, obligation_id, pence)` atomically sets pence aside
  (`mailing_budget_confirmations.reserved_pence`), so a second obligation's
  `reserve()` call can never see that headroom as still available. If the
  full amount can't be covered, the obligation is marked `failed` WITHOUT
  ever calling a provider -- an admin can re-attempt it (reset to `ready`)
  once more budget is confirmed.
- On a real provider ACCEPTED/DISPATCHED, `gate.settle()` converts that
  reservation into real spend (`spent_pence`).
- On every usable provider confirming REJECTED, `gate.release()` frees the
  reservation back to the pool.
- On an `unknown` outcome (ambiguous response or a provider that raised),
  the reservation is deliberately left untouched -- neither settled nor
  released -- until a human reconciles the `unknown` row (section 4 below).
  This is what "preserve reservations for uncertain submissions until
  reconciled" means in practice: the money stays set aside rather than
  either being spent on a letter that might not have gone out, or being
  freed and re-spent on a different letter while the first might still be
  in the post.

`worker.run_batch` builds a real `FundingGate()` automatically if its
caller doesn't pass one (defaulting to `FUNDING_MODE=hold`, fail-safe), so
this protection is on by default for the normal operating path. `gate.spend(cur,
pence)` remains available as a lower-level primitive for a manual/admin
reconciliation outside the obligation pipeline (see its own docstring) --
the automated pipeline no longer needs it directly, since reserve()+settle()
covers that.

**Not implemented in this sandbox:** true multi-connection concurrency (two
real workers, two real database connections, racing for the same budget
row) was never exercised against a live Postgres instance -- none is
available here. `reserve()`'s atomicity relies on `SELECT ... FOR UPDATE`
row locking, which is a standard, well-understood Postgres mechanism, but
the guarantee itself is only proven at the unit/logic level in this
session's tests (see `tests/test_funding.py`'s own docstring on this),
not against a real concurrent workload. Verify this against a real staging
database with actual concurrent workers before relying on it in production.

## 3. Suppression (`suppression.py`)

A homeowner who's objected (by any channel -- letter reply, email, phone)
gets a row in `postal_suppressions`, added via `suppression.add_suppression`.
Two scopes:

- **`this_person`**: blocks only that named applicant at that address.
- **`this_address_anyone`**: blocks the address regardless of who applies
  next (use when the objection was clearly about the property, not one
  individual -- e.g. "stop sending planning-related mail to this house").

Checked automatically at send time (`letter_providers.registry.attempt_send`,
step 1, before the obligation is even claimed) -- no manual step needed
once a suppression row exists. **There is no admin UI to add a suppression
row yet** -- this must be done via direct DB access or a small admin
script. Building that UI is outstanding work, not something this session
implemented (Section 7 of the original brief asked for the mechanism, not
a full admin surface).

## 4. `unknown` outcomes -- read this before touching anything

An obligation lands in `status = 'unknown'` when a provider's response was
genuinely ambiguous: a timeout, a crash mid-request, a malformed response,
or any exception raised by the adapter. **This is deliberately a dead end,
not a retry queue.** `worker.run_batch` only ever selects `status =
'ready'` rows -- an `unknown` row is never picked up again automatically,
and `letter_providers.registry.attempt_send` never falls back to a second
provider after an unknown outcome (see that function's own module
docstring for exactly why: the first attempt may already have been
accepted, and trying a second provider risks a duplicate physical letter).

**Handling an `unknown` row is a manual, human decision**: check the
provider's own dashboard/support channel for what actually happened to
that specific submission (`provider_reference` may or may not be populated
-- it often isn't, for a genuinely unknown outcome), then either:
- confirm it was actually accepted -- manually update the row's status and
  `provider_accepted_at`/`dispatched_at` to match reality, or
- confirm it was never received -- manually reset it to `ready` (or
  `pending_funding` if you want the gate re-checked) so the worker will
  retry it, or
- give up and mark it `cancelled` with a note explaining why.

There is currently no tooling to do this other than direct SQL -- an admin
reconciliation screen for `unknown` and `blocked_missing_data` rows is
outstanding work (see launch checklist).

## 5. Running the worker: local and deployed entry points

**2026-09-18 review, Section 6 (second pass):** the first pass of this
review built the three pipeline stage functions
(`promote_pending_approvals` / `promote_pending_funding` / `run_batch`) but
left them with zero callers anywhere in the codebase -- guarding those
functions (pipeline-active checks, atomic claims) is not the same thing as
anything ever actually invoking them. This second pass closes that: there
are now two real, tested entry points, described below, plus the single
sequencing function both of them call, `worker.run_one_pass` (see its own
docstring in `worker.py`). **Neither entry point is scheduled anywhere by
this session's own work** -- see item 9 of the launch checklist. Running
either one right now, by hand, does not turn anything on by itself; it
just runs one pass, once, against whatever this shell's environment
already has configured (dry-run by default either way).

### Local: `worker_runner.py` (no FastAPI process needed)

A standalone script at the repo root. Needs the same environment variables
the pipeline always needed (`DATABASE_URL`, `FUNDING_MODE`, the letter-
provider `LETTER_PROVIDER_*` slots if you want a real/fake provider
consulted) but nothing else running:

```bash
python3 worker_runner.py                  # one pass, dry-run (default, safe)
python3 worker_runner.py --live           # one pass, allows a real provider
                                           # call IF a provider slot is also
                                           # configured -- this flag alone
                                           # still sends nothing by itself
python3 worker_runner.py --loop                          # repeat every 900s (default) until Ctrl-C, dry-run
python3 worker_runner.py --loop --interval 300 --live    # every 5 minutes, live
python3 worker_runner.py --worker-id my-machine-1         # identifies attempts made by this run
```

This is the mechanism to use for local testing, a one-off manual run, or
running the worker as a long-lived process on a box you control (a small
VM, a container with `--loop` as its entrypoint) -- see
`tests/test_worker_runner.py` for its own test coverage (argument parsing,
commit-on-success/rollback-on-exception, the no-op case).

### Deployed: the `/trigger-letter-fulfilment-worker` HTTP route

`main.py` exposes this the same way every other pipeline in this codebase
exposes its cron-facing entry point (see the existing `/trigger-domestic-
scan` etc. routes) -- a GET route, authenticated by `?secret=` matching
`TRIGGER_SECRET` (query-param only, since an external cron service can
only ever supply a URL, never an Authorization header):

```
GET https://<your-deployment>/trigger-letter-fulfilment-worker?secret=<TRIGGER_SECRET>
GET https://<your-deployment>/trigger-letter-fulfilment-worker?secret=<TRIGGER_SECRET>&live=true
```

This is the mechanism to point an external scheduler at once you've
decided on one -- a cron-job.org ping, a Render Cron Job hitting the URL,
or any other platform-level scheduled HTTP call, the same pattern this
codebase already uses for the scanning pipeline. **Nothing in this
session's work sets one of those up** -- the route existing is not the
same as it being scheduled anywhere (see launch checklist item 9). It
returns a small JSON summary (`status`, `is_dry_run`, `approvals`,
`funding`, `send_outcomes`) rather than a redirect, since it's meant to be
hit by a machine, not clicked by a person -- see
`tests/test_worker_trigger_routes.py` for coverage of the auth requirement,
the `live=` -> `is_dry_run` mapping, and the rollback-and-JSON-error
behaviour on a mid-pass exception (never silently commits a partial pass).

There's also `/admin/run-letter-fulfilment-worker` (Basic Auth or
`?secret=`, always dry-run) -- a button on `/admin/letter-dispatches` for
Nick to trigger one pass by hand from the dashboard without needing the
cron secret in a raw URL, the same relationship `/admin/process-letter-
dispatches` has to the legacy pipeline's manual trigger.

### What run_one_pass actually does, either way

Both entry points above call exactly one function, `worker.run_one_pass`,
which sequences the three stages in order and returns a combined report:

```python
import database, worker
conn = database.get_db_conn()
cur = conn.cursor()
try:
    report = worker.run_one_pass(cur, worker_id="manual-run-1", is_dry_run=True)
    conn.commit()
except Exception:
    conn.rollback()
    raise
finally:
    cur.close(); conn.close()

print(report.approvals)      # PromotionReport(checked=.., promoted_to_pending_funding=.., ...)
print(report.funding)        # PromotionReport(checked=.., promoted_to_ready=.., ...)
print(report.send_outcomes)  # list[SendOutcome]
```

Internally this is still promote -> promote -> send, exactly as before:
`promote_pending_approvals`, then `promote_pending_funding` (against a
`funding.FundingGate()`, defaulting to `FUNDING_MODE=hold` when the caller
doesn't supply one), then `run_batch` (against a provider registry built
by `letter_providers.registry.build_registry_from_env()` when the caller
doesn't supply one). Calling the three stage functions directly, as
separate steps, still works exactly as it always did -- `run_one_pass` is
a convenience wrapper, not a replacement API; each stage function still
independently refuses to do anything unless `LETTER_DISPATCH_PIPELINE=
fulfilment`.

`worker.estimated_letter_cost_pence()` (used by the funding-check stage
when a caller doesn't pass `estimated_cost_pence` explicitly) now reads
from `ESTIMATED_LETTER_COST_PENCE` (pence, integer; default 95 -- a rough
2nd-class-stamp-plus-paper placeholder) instead of a hardcoded literal --
see `.env.example.letter-fulfilment`.

**Deliberately NOT auto-started as an in-process background thread** the
way `main.py`'s `_autonomous_scheduler_loop` starts the scanning pipeline
on every app boot (a daemon thread checking every 20 minutes). Switching
`LETTER_DISPATCH_PIPELINE` to `fulfilment` to test something else must
never, by itself, start a background loop that begins attempting sends --
starting either entry point above requires a human explicitly doing so.

## 6. Known limitation: unstructured addresses

`leads.address` is one free-text field, not
line1/city/postcode/country. `worker.run_batch` currently passes the whole
string as `address_lines['line1']` and leaves the rest blank. A real
postal provider integration will very likely need proper address
components -- either an address-parsing step before submission, or
capturing structured fields earlier, at planning-data ingestion. Not solved
in this session's work; flagged in the launch checklist.

## 7. The address-release gate (`address_release.py`)

Separate from everything above. Funding, providers and pipeline state
govern whether a letter gets POSTED to the homeowner; this gate governs
whether the exact address is ever DISPLAYED to a contractor or a customer
-- through the web app, or in a transactional email -- and it is
deliberately blind to payment, funding and provider state. See
`address_release.py`'s own module docstring for the full reasoning and the
full list of routes it's wired into (letter/flyer previews, the Street
View redirect, the dashboard/my-leads/free-dashboard pages, and the two
purchase/free-grant confirmation emails).

`ADDRESS_RELEASE_LIVE` (env var, default unset/false): when false, every
one of those surfaces shows a fixed redacted placeholder instead of the
real address, even to a contractor who genuinely owns the lead. This is
not a bug to "fix" by setting it true -- it exists because
docs/launch_checklist.md item 3 (Article 14 disclosure timing) is an
unresolved legal question. Only set `ADDRESS_RELEASE_LIVE=true` once that
review concludes address disclosure to contractors is clear; it is a
separate decision from `LETTER_SENDING_LIVE` (section on the letter-promise
copy gate) -- neither flag implies the other.

The contractor-approval UI (`/letter-settings`, section 1a above) does not
interact with this gate at all -- it always previews and approves against
fixed sample lead data, never a real lead's address, and approves a
template-level fingerprint independent of any address -- see
`address_release.py`'s docstring (the "CONTRACTOR-APPROVAL UI -- BUILT"
note) for the full reasoning.

### 7a. Allocation-level eligibility -- 2026-09-18 review, Section 2 (second pass)

`ADDRESS_RELEASE_LIVE` used to be the WHOLE decision: on meant every lead's
address was shown to whoever owned it, off meant none was, with no way to
turn it on for leads bought going forward without also exposing every
address ever purchased historically, or vice versa. That's now been split
into three tiers, checked in this order for every address-showing call:

1. **Historical purchase** -- a lead claimed through `letter_dispatches`
   (TreeKey's original pipeline, before `lead_allocations`/
   `letter_obligations` existed -- the same table `fulfilment.
   get_lead_owner` already falls back to for ownership) always shows the
   real address, regardless of `ADDRESS_RELEASE_LIVE` or anything in
   `address_disclosure_decisions`. This is what "preserve authorised
   historical purchase access" means in practice: a contractor who already
   paid for a lead under the old flow never loses access to what they paid
   for because of this later change.
2. **New allocation, explicit eligibility decision** -- a lead claimed
   through the new pipeline (`lead_allocations`) shows the real address
   only if BOTH an operator has explicitly recorded that specific
   `lead_reference` as eligible (`address_disclosure_decisions.eligible =
   true`) AND `ADDRESS_RELEASE_LIVE` is also true. Neither is sufficient
   alone -- the global flag is now only an additional kill-switch, not the
   decision itself.
3. **Everything else** (an allocation nobody has recorded a decision for,
   or a `lead_reference` that can't be classified into either table at
   all) shows the redacted placeholder. There is no default-to-eligible
   path anywhere in this code -- `get_allocation_address_eligible` returns
   `False` for a lead with no row, on purpose, per the explicit instruction
   not to invent a legally sufficient release trigger.

**What decides eligibility for a new allocation is deliberately left
unresolved and configurable, not invented by this codebase.** There is no
UI or automated rule that sets `address_disclosure_decisions.eligible =
true` -- it is a manual, audited, one-row-at-a-time operator action via
`address_release.set_allocation_address_eligible(cur, lead_reference,
eligible=True, decided_by="<your email>", note="<why>")`, run directly
against the database (a short Python REPL/script using
`database.get_db_conn()`, or a `psql` INSERT matching that function's
shape) -- there is no admin HTTP route for it, matching the existing
precedent for `funding.FundingGate.confirm_budget` and
`suppression.add_suppression`, both of which are also direct-DB/script-only
today (see sections 4 and the suppression notes elsewhere in this guide).
`decided_by` is required (raises `ValueError` if blank) so every decision
is attributable to a specific human, and `note` is free text for why. This
was a deliberate choice, not an oversight: building an admin UI for this
would itself be a policy decision about who's authorised to approve
disclosure and under what process, which is exactly the unresolved legal
question this section is not supposed to settle on its own.

New table: `address_disclosure_decisions` (`lead_reference` primary key,
`eligible boolean`, `decided_by`, `note`, `decided_at`) -- created by
`address_release.init_address_release_schema`, wired into
`database.init_db()` alongside the other schema functions, and mirrored in
`migrations/0001_letter_fulfilment.sql`.

Two self-contained helper functions do the full three-tier check and open
their own DB connection, for call sites with no cursor already open
(`address_release.guarded_address_for_lead_reference(lead_reference,
real_address)` returns either the real address or the redacted
placeholder; `address_release.lead_address_release_allowed(lead_reference)`
returns a plain bool, for routes with no safe reduced version to show at
all, e.g. the street-flyer and Street View routes). Both fail safe
(redacted/denied) on any DB error. Callers that already have an open
cursor should use `address_release.guarded_address_for_lead(cur,
lead_reference, real_address)` directly instead, to avoid a redundant
connection.

Tested in `tests/test_address_release_allocation_eligibility.py` (24
tests, genuinely exercising all three tiers with an explicit queued
FakeCursor -- see that file's own docstring for why the older
`tests/test_address_release_gate.py` route-level "enabled" tests alone
weren't sufficient evidence: they use a blind `MagicMock()` cursor whose
default truthy `fetchone()` coincidentally reproduced the OLD single-flag
behaviour rather than genuinely exercising the new decision paths, until
this dedicated file was added).

## 8. The public posting-promise gate (`fulfilment.letter_sending_live()`)

Separate again from the address-release gate above -- this one controls
whether the customer-facing COPY ("includes a posted introduction
letter") is shown at all, not whether an address is visible. See
`payments.plan_description()`/`payments.plan_roi()` for where the copy
itself lives (a `letter_suffix`/`roi_letter_suffix` appended only when
this gate is True).

**2026-09-18 review, Section 3 (second pass):** originally this was a
single flag (`LETTER_SENDING_LIVE`). That was real progress over a
hardcoded sentence, but it was still only one control -- a deploy could
have `LETTER_SENDING_LIVE=true` set while `LETTER_DISPATCH_PIPELINE` was
still `legacy` (nothing processes the new pipeline's obligations at all)
or while no `LETTER_PROVIDER_*` slot was configured (nothing could ever
accept a send), and the public copy would still confidently promise a
posted letter. `letter_sending_live()` now requires all three of the
following, every call, fresh (no caching):

1. **`LETTER_SENDING_LIVE=true`** (or another truthy spelling) -- the
   explicit admin approval. Still required on its own even when the other
   two are ready -- an admin's deliberate go-live decision stays a
   separate fact from technical readiness. Default unset/false.
2. **`LETTER_DISPATCH_PIPELINE=fulfilment`** (see section 5 above and
   `fulfilment.active_pipeline()`) -- the pipeline that actually attempts
   provider sends. Left on `legacy` (the default), this is always False
   regardless of the other two.
3. **A real, enabled, configured provider slot.** Built via
   `letter_providers.registry.build_registry_from_env()` -- at least one
   of `LETTER_PROVIDER_PRIMARY` / `_BACKUP_1` / `_BACKUP_2` must name a
   provider kind that reports `is_configured() == True` (real credentials
   present, not just a recognised name) AND is not `fake_test`. The fake
   adapter is excluded on purpose: it exists so the pipeline/worker/
   reconciliation logic can be tested locally with no real vendor account
   (see `letter_providers/fake_provider.py`), and a deploy with only that
   configured has no way to actually post a letter, so the public promise
   must not imply one will be sent. Today `stannp` is the only adapter
   that can ever report itself configured (`STANNP_API_KEY` +
   `STANNP_TEMPLATE_ID` both set) -- `intelliprint`/`postworks` are
   unimplemented placeholders hard-coded to always report unconfigured
   (see their own module docstrings), and Stannp itself is an
   unverified-against-live-API placeholder (section 5/1 above), so no real
   deploy can make this condition true with a genuinely working provider
   today. That's expected, not a bug in this gate -- it correctly stays
   off until that's actually resolved.

All three are independent operator actions, exercisable in any order --
e.g. get the pipeline switched and a real provider configured and
soak-tested with `LETTER_SENDING_LIVE` still off, verify real sends work,
then flip the public promise on last, deliberately. Getting only part of
this configured (any two of the three) always leaves the promise off, not
half-on -- see `tests/test_letter_promise_gate.py`'s
`TestInvalidConfigurationCombinationsLeavePromiseOff` class (7 tests, one
per way to have exactly one condition missing, plus a positive control
proving all three together do turn it on).

## 9. Payment/allocation reconciliation (`payment_allocation_reconciliation`)

Separate from every gate above -- this is what happens when a Stripe
payment genuinely succeeded but the LOCAL write that should have followed
it (creating the lead allocation and letter obligation) failed, e.g. a
transient database problem at exactly the wrong moment.

**How you'll notice:** a CRITICAL "PAYMENT RECEIVED, ALLOCATION FAILED"
alert (via whatever `notifications.send_system_incident_alert` is wired to
in this deployment), naming the customer, the lead, and a reconciliation
issue id. Nothing is refunded and nothing is marked sold automatically --
the customer's payment and the lead's reservation are both still good;
only the local write failed.

**What happens automatically, no admin action required:**
- The failure is durably recorded in `payment_allocation_reconciliation`
  (`stripe_event_id`, `stripe_reference` = the checkout session/
  reservation token, `buyer_email`, `lead_reference`, `reason`,
  `resolved = FALSE`).
- The Stripe webhook event is deliberately left un-fulfilled, so Stripe's
  own retry mechanism (retries for up to ~3 days) keeps redelivering it --
  most of these self-resolve the moment the underlying DB problem clears,
  with no admin action ever needed.
- If a retry arrives AFTER the lead's reservation has since expired
  (`RESERVATION_RELEASE_MINUTES`, see the reservation flow in
  `database.py`) and been swept back to the marketplace, the system does
  NOT fall back to auto-refunding the customer just because the
  reservation itself is gone -- it checks for exactly this open,
  unresolved record first (matched on the durable Stripe event id/
  session id, not the lead's own mutable status -- see `fulfilment.
  has_unresolved_reconciliation_issue`) and, finding one, stays in the
  same "retry, don't refund" state instead. Refunding would contradict
  the still-open alert asking a human to look at it, and risks a double
  refund if a human has already acted on it by hand.

**What needs an admin, eventually, if it doesn't self-resolve:**
Query unresolved issues directly (`SELECT * FROM
payment_allocation_reconciliation WHERE resolved = FALSE;`) -- there is no
admin UI for this yet, same as the other direct-DB/script-only precedents
in this guide (section 2's `confirm_budget`, section 3's suppression
rows). For each: either fix the underlying problem and let Stripe's
natural retry complete the sale, or complete/refund it by hand and then
call `fulfilment.resolve_reconciliation_issue(cur, issue_id,
resolved_by="<your email>", note="<what you did>")` to close it out and
let the system return to its normal auto-refund behaviour for that
payment identity if a further retry ever arrives.

## 10. PostgreSQL concurrency verification (2026-09-22 review, Section 6)

`funding.py`'s `FundingGate.reserve()`/`release()`/`settle()` and
`fulfilment.py`'s `claim_for_submission()` rely on real PostgreSQL row
locking (`SELECT ... FOR UPDATE`, and plain `UPDATE ... WHERE status = ...`)
to stay safe when more than one worker runs at once. The rest of this
repo's tests mock the database, so they verify the Python logic calls the
right SQL, but cannot verify the SQL's locking actually holds up under real
concurrent transactions.

`tests/postgres_concurrency/run_concurrency_tests.py` closes that gap: it
starts a disposable local PostgreSQL 16 server, applies the real
`migrations/0001_letter_fulfilment.sql` file, and drives the exact
`reserve()`/`claim_for_submission()` SQL through concurrent `psql`
processes. It is a standalone script, not part of `unittest discover` --
see `tests/postgres_concurrency/README.md` for why (in short: `psycopg2`
could not be installed in the sandbox this was built in, so the real
Python call path can't be driven against Postgres there; only the literal
SQL can be).

Run it with:

```bash
python3 tests/postgres_concurrency/run_concurrency_tests.py
```

As of 2026-09-22, all five scenarios pass (simultaneous workers with
insufficient combined balance, a single worker with insufficient balance
from the start, a rolled-back transaction, an unreleased "unknown" outcome,
and a two-worker claim race) -- see `docs/launch_checklist.md` item 6a for
the full write-up and `tests/postgres_concurrency/README.md` for what each
scenario actually checks. This has never been run against a real or
production database -- only against a disposable server the script itself
creates and destroys.

## 11. ERROR_LOG.md — cross-session error/fix continuity (2026-09-22)

`ERROR_LOG.md` (project root, alongside `main.py`) is a plain-text,
version-controlled log of every error found in this codebase and every fix
applied to it, one entry per issue. It exists specifically so a fresh AI
session (or a new developer) with no memory of prior work can read one file
and see what's already been tried, what worked, and what's still blocked --
see that file's own header for the full reasoning and the format for new
entries. It complements, and does not replace, the `system_warnings`
database table / Daily Warning Digest (which already tracks live
scraper/lead-source warnings over time) -- this file's job is everything
*else*: what was actually done about an error, across the whole codebase,
readable without database access.

Add an entry to it whenever you find a real bug or ship a real fix. It is
expected maintenance, not optional.

## 12. Scraper incident/repair-attempt tracking and scan checkpointing (2026-09-22)

`scraper_resilience.py` adds `source_incident`/`repair_attempt` tracking
(a real lifecycle -- `open -> repair_attempted -> verifying -> resolved`,
reopened rather than duplicated if a resolved failure recurs) and
`council_scan_checkpoint`/`council_scan_pass_metrics` bookkeeping (so a
future backfill can recover leads missed during an outage, and so "zero
new leads today" can be told apart from "the scraper is actually broken").
This closes a real gap: the existing `system_warnings` table/daily digest
detects and alerts but never remembered whether a fix was tried or worked.

Origin: an external architecture review (ChatGPT/Astra, prompted by Nick
with Claude's own findings) recommended this design on 2026-09-22 -- see
`ERROR_LOG.md`'s entries from that date for the full reasoning and what
was deliberately left out.

**Not yet wired into any real scrape.** This is schema and bookkeeping
functions only -- `main.py` does not call any of it yet, and can't be
usefully wired in without `mesh_scrapers.py` (still absent from this repo
-- see `ERROR_LOG.md`). The same review's other recommendations (response
classification before parsing, tested fallback parser strategies, an
LLM-extraction quarantine) are correctly un-built for the same reason: all
three need real Idox page structure in hand, not guesswork.

No admin UI exists for this yet, same precedent as `confirm_budget`
(section 2) and manual reconciliation resolution (section 9) -- use
`scraper_resilience.get_open_incidents()` / `get_repair_attempts(id)` /
`resolve_incident(id, verified_by=..., note=...)` directly.

**2026-09-22 update (same day, Astra's follow-up review):**
`source_incident` gained `last_verification_outcome`/
`last_verification_failure_reason`/`reopen_count`, plus
`record_verification_result(incident_id, outcome=..., failure_reason=...)`
so a FAILED verification is recorded and reopens the incident instead of
leaving it stuck in `verifying` forever. `open_or_touch_incident`'s "no row
exists" path now uses an atomic `INSERT ... ON CONFLICT` (closing a real
race two concurrent callers could hit). `council_scan_checkpoint` is now
keyed by `(council, search_definition)`, not `council` alone, with
backward-movement protection so a slower concurrent scan can't drag a
checkpoint back in time.

## 13. Idox fixture format, response classifier, and capture hook (2026-09-22)

Companion infrastructure to section 12, from the same follow-up review,
building toward the "tested fallback parser strategies from real saved
pages" work that's still blocked on `mesh_scrapers.py`:

- **`tests/fixtures/idox/`** -- the saved-response fixture format
  (`body.html`/`meta.json`/`expected.json` per case; full schema in that
  directory's own `README.md`). Every fixture declares `provenance`:
  `"captured"` (a real response) or `"synthetic"` (hand-built, clearly
  labeled, never fabricated real page content). Currently contains 3
  synthetic fixtures (429, 503, Cloudflare `cf-mitigated: challenge`) --
  no real captures exist yet.
- **`net_utils.classify_response(status_code=..., headers=..., body_text=...)`**
  -- classifies a response into `PAGE_OK`/`VALID_EMPTY`/`RATE_LIMITED`/
  `CHALLENGED`/`AUTH_REQUIRED`/`SERVER_ERROR`/`UNRECOGNISED_PAGE`, using
  only response shape (status + a small header allowlist) -- it cannot and
  does not try to recognise real Idox page content. `VALID_EMPTY` is only
  ever returned via an explicit `known_no_results=True` hint from a future
  caller that actually has real page knowledge.
- **Capture hook** -- `net_utils.smart_get`/`smart_post(..., capture_context=
  {"council": ..., "platform": ..., "page_kind": ..., "search_parameters":
  ...})` saves the response (body + metadata, deliberately never
  `expected.json`) to `captured_responses/<council>/<case>/` for later
  human review. **Off by default**: omitting `capture_context` (every
  existing call site in this repo) changes nothing. `NET_UTILS_
  DISABLE_CAPTURE=1` forces it off regardless, as a second safeguard.

**Still not wired into any real scrape** -- same reason as section 12.
Once `mesh_scrapers.py` exists, its Idox calls can start passing
`capture_context=...` to begin bootstrapping real fixtures; a human still
has to review each capture and hand-write its `expected.json` before it
counts as a trusted regression fixture (see the README's own "Where real
fixtures will come from" section).

## 14. Buyer-facing reference substitution and the 72-hour post-dispatch personal-data purge (2026-09-23)

**Buyer-facing reference, not the raw council reference.** `address_release.
buyer_facing_reference(cur, lead_reference)` (built 2026-09-22, wired in
2026-09-23) returns a `lead_allocations.id` UUID for a new allocation, or
the real council reference unchanged for a historical claim. Every
buyer-facing display/link on `/dashboard`, `/my-leads`, `/free-dashboard`,
and both transactional emails now goes through this (or its self-contained
wrapper, `buyer_facing_reference_standalone`) instead of the raw
`lead_reference` -- the raw council reference is itself an indirect
identifier, pasteable into a council portal's own search box to recover
the exact application, address, and applicant name the address-release
gate exists to hide. `/generate-letter/{id}`, `/generate-street-flyer/{id}`,
and `/street-view/{reference}` accept EITHER shape in their URL path: each
now calls `address_release.resolve_buyer_facing_reference(_standalone)`
first thing, which resolves a `lead_allocations.id` back to the real
`lead_reference` (falling through unchanged for anything it can't
classify, including a historical claim's own reference) before any
existing ownership/address-release logic runs. **Operator implication:**
an OLD bookmarked/shared link using the raw reference still works exactly
as before (the resolve step just falls through unchanged) -- nothing was
invalidated by this change.

**Applicant name is now gated the same way as address.**
`address_release.guarded_applicant_name_for_lead(_reference)` mirrors
`guarded_address_for_lead`'s historical/new two-tier decision: a
historical claim's applicant name (if the council published one) still
shows; a new allocation's never does, full stop -- no config value can
change this, same posture as the address gate.

**The 72-hour post-dispatch personal-data purge (`retention_dispatch_
purge.py`).** Once a mailing is a genuine, provider-CONFIRMED dispatch
(`letter_obligations.status='dispatched'`/`dispatched_at`, or `letter_
dispatches.sent_at` for the legacy pipeline -- never merely 'accepted'),
`purge_dispatched_personal_data()` clears the homeowner's address/
applicant name and the frozen `approved_content_html` on that row, and the
`leads` row's own address/applicant name once nothing else for that
reference is still unresolved, 72 hours later. Runs automatically as part
of `run_full_autonomous_cycle` (same place `cleanup_stale_leads` runs) and
on demand at `/admin/dispatch-data-purge?secret=...` (two-step confirm,
same convention as `/admin/cleanup-stale-leads`). **Preserved,
indefinitely, with no expiry currently set:** every row's own id,
lead_reference, buyer_email, sale_context, status, every timestamp column,
provider_name/reference, content_fingerprint, template_version, attempts,
last_error -- plus `payments`, `lead_allocations`, and `postal_
suppressions` in full (never touched by this module at all). **What this
means for a real deploy:** a lead's personal data and letter content are
gone 72 hours after a real dispatch confirmation; the transaction/evidence
trail is not, and currently has no planned expiry -- that's an open policy
decision for Nick, not something this module invented a number for.

**`status='unknown'` obligations are a dead end, deliberately.** The purge
never selects one (no confirmed dispatch = the 72-hour clock never
starts), and nothing auto-resends one. The ONLY way one moves is `/admin/
dispatch-reconciliation?secret=...&confirm=yes`
(`retention_dispatch_purge.reconcile_unknown_outcome_obligations`), which
asks the SAME provider that produced the ambiguous result for its current
status via `check_status()` (never `.send()`) and upgrades via the
existing `fulfilment.mark_provider_result` only when the provider actually
answers. An obligation whose provider has no status-lookup capability, or
whose `provider_name` doesn't match a currently configured slot, stays
'unknown' -- surfaced by `count_unknown_outcome_obligations_awaiting_
reconciliation()`, not silently retried forever.

**Testing without a real provider.** `letter_providers/fake_provider.py`'s
`FakeLetterProvider` now supports `force_outcome="dispatched"` (an
immediate dispatch confirmation, for tests that don't need the
accepted-then-dispatched distinction) and `simulate_dispatch_confirmed
(provider_reference)` (advances a prior 'accepted' send to 'dispatched',
discoverable via a later `check_status()` call -- the realistic shape of
how a real provider would actually confirm dispatch). Neither is used by
any real send path; nothing here invents a live provider's dispatch
signal, it only ever answers for this fake adapter, which nothing in
production selects.

**Privacy notice.** `/privacy-policy`'s Data Retention section now states
the actual implemented figures (60-day unsold-lead deletion, 72-hour
post-dispatch personal-data purge) instead of the previous, code-unbacked
"24 months... anonymized or deleted" / "6 years" billing claim. See
`ERROR_LOG.md`'s 2026-09-23 entry for the specific decisions this still
needs from Nick (the evidence-record's own retention period, an actual
enforced billing-record retention policy, and a closed-account data
policy -- none of the three exist as code today).

## 15. Letter setup is now part of account setup, and gated before an already-logged-in buyer's purchase (2026-09-23)

**What changed.** The existing `/letter-settings` setup/preview/approve
journey (template selector, business details, the reusable approval/
fingerprint mechanism -- all pre-existing) is now surfaced directly from
`/account` (a "Letter Template" card showing Not started / Saved, not yet
approved / Approved & in use, with an Edit/Set Up link), and an amber
banner appears at the top of `/account` whenever setup is incomplete. The
business-introduction field on `/letter-settings` now shows "(this is what
customers will see on your introduction letter)" directly beside it.

**The checkout gate.** `GET /checkout/{plan_key}` -- both the single-lead-
purchase branch and the subscription area-selector branch, since every
plan includes a posted letter -- now checks `main._letter_setup_complete
(account_email)` for an ALREADY-LOGGED-IN contractor (valid session
cookie) before reserving any lead or creating a Stripe session. Incomplete
setup redirects to `/letter-settings?next=<the exact checkout URL>`;
approving on that detour sends them straight back to finish the purchase
via the `next` query param, validated by the same `_safe_next_url` the
pre-existing `/login` "sign in for your discount" flow already uses (never
an arbitrary or off-site redirect target). `POST /checkout/{plan_key}`
(the subscription area-form submit) carries the identical check as
defense-in-depth in case the GET-time redirect is ever bypassed.

**Deliberately not applied to an anonymous visitor.** A buyer with no
session cookie at all is never checked or redirected -- `_letter_setup_
complete` isn't even called for one. This preserves the existing, explicit
"login is never required to buy a lead" decision documented on
`payments.create_checkout_session`. For that buyer, the actual protection
against an unapproved letter going out is the pre-existing
`worker.promote_pending_approvals` gate, which has always refused to send
any letter without approved, fingerprint-current settings -- regardless of
whether the buyer was logged in at purchase time. See `ERROR_LOG.md`'s
2026-09-23 Request E entry for the open decision this leaves for Nick:
whether an anonymous first-time buyer should ALSO be required to log in
(or otherwise complete letter setup) before a mailed purchase, which would
mean revisiting that existing "no login required" decision rather than
just closing a gap in it.

**No new storage.** This is UI/flow integration over existing state
(`contractor_letter_settings`, the existing approval/fingerprint columns)
-- no new migration, no new columns.
