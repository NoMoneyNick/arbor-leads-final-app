import os
import logging
from typing import Optional, Dict, Any
import stripe
from dotenv import load_dotenv

import fulfilment

load_dotenv()
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "").strip()
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "").strip()
PUBLIC_APP_URL = os.getenv("PUBLIC_APP_URL", "").strip().rstrip("/")
logger = logging.getLogger("vector-data-labs")

# Best-effort in-process dedup for retried Stripe webhooks (Stripe redelivers the same
# event id on timeout/non-2xx — that's a normal retry, not a fraud/race signal). Doesn't
# survive a restart or a multi-instance deploy, but removes the common false-positive case.
#
# Aug 30 2026: this used to be one function that BOTH checked and marked an event id as
# processed in the same call, at the very top of handle_stripe_webhook -- before any
# actual fulfillment (database.burn_lead_inventory, etc.) had even been attempted. That
# meant a genuinely failed first attempt (e.g. a transient DB error while burning a lead)
# still marked the event id as "seen", so if Stripe retried the SAME webhook, the retry
# was wrongly classified as "just a duplicate delivery of an already-handled event" --
# silently skipping fulfillment a second time AND suppressing the CRITICAL "double sale"
# alert that exists specifically to catch a customer paying and not receiving their lead.
# Split into a peek (no side effect, used for the "is this worth alerting about" check)
# and an explicit mark-as-fulfilled call made ONLY after real success, so a failed first
# attempt is retried honestly instead of being swallowed.
_PROCESSED_STRIPE_EVENT_IDS: Dict[str, float] = {}


def _seen_stripe_event(event_id: str) -> bool:
    """Peek only -- does NOT mark the event as processed. Safe to call before
    fulfillment has been attempted."""
    import time
    now = time.time()
    for k in [k for k, t in _PROCESSED_STRIPE_EVENT_IDS.items() if now - t > 86400]:
        del _PROCESSED_STRIPE_EVENT_IDS[k]
    if not event_id:
        return False
    return event_id in _PROCESSED_STRIPE_EVENT_IDS


def _mark_stripe_event_fulfilled(event_id: str) -> None:
    """Call ONLY after the event's action has actually succeeded (lead burned,
    subscription registered, etc.) -- marks it so a Stripe redelivery of this
    same event id is correctly recognised as a harmless duplicate, not retried."""
    if event_id:
        import time
        _PROCESSED_STRIPE_EVENT_IDS[event_id] = time.time()

# ── Pricing Plans (5 Tailored Packages + Single Purchase Marketplace) ─────────
# All amounts in pence (GBP)
#
# Sep 12 2026, tier consolidation (Nick's go-ahead): the old 8-tier lineup
# had two overlapping families that grew separately -- a "tailored" set
# (Stump Pro, Climber Domestic, Arb Consultant, Commercial & Forestry,
# Elite) and a "homepage" set (Sole Trader, Commercial Pro, Regional Elite)
# that duplicated it with near-identical copy at the same price points.
# Retired: stump_pro (its one job type is just a filter inside any tier,
# not worth a dedicated £29 product -- confirmed too small a volume in the
# lead-volume report), climber_domestic + sole_trader (both £49/mo,
# functionally the same tier), commercial_pro (folded into
# commercial_forestry), regional_elite (folded into treekey_elite).
# "starter" and "growth" below are new, replacing the retired ones.
# arb_consultant/commercial_forestry/treekey_elite keys are KEPT (not
# renamed) so nothing else referencing them elsewhere breaks -- only their
# price/copy changed.
PLANS = {
    "starter": {
        "name": "TreeKey Starter",
        "description": "For 1-2 van operators. Domestic and small commercial jobs, every job type, plus 1-tap letter previews and Street View briefs.",
        # 2026-09-18 review, Section 4: the letter-posting promise is a
        # SUFFIX, appended by plan_description() only when
        # fulfilment.letter_sending_live() is True -- see that function
        # and fulfilment.py's own docstring on LETTER_SENDING_LIVE. Do not
        # read "description" directly for anything customer-facing;
        # call plan_description(plan_key) instead.
        "letter_suffix": " A posted introduction letter comes with every lead.",
        "amount": 3900,   # £39/month
        "mode": "subscription",
        "badge": "Most Popular",
        "real_world_roi": "Less than a tank of diesel (£39/mo). One £400 job every few months pays for the year many times over."
    },
    "growth": {
        "name": "TreeKey Growth",
        "description": "For established 2-3 man crews wanting more volume and a wider net across a bigger area.",
        "amount": 7900,   # £79/month
        "mode": "subscription",
        "badge": "Growing Crews",
        "real_world_roi": "One extra job a month at this volume comfortably covers the subscription."
    },
    "arb_consultant": {
        "name": "TreeKey Consultant (Planning & Survey)",
        # Aug 30 2026: dropped "direct developer company contacts" -- no code
        # path in this project actually looks up or delivers a developer's
        # contact details (that would need Companies House enrichment wired
        # to a lead's applicant, which doesn't exist here; bulk_contractor_
        # extractor.py's Companies House lookups are for a separate pipeline
        # that finds tree-surgery companies to sell subscriptions to, not
        # for enriching a lead's developer applicant). Only the two
        # deliverables the pipeline actually produces are listed.
        "description": "For qualified arborists (TechArb/MICFor). Developer condition 7 discharges and BS5837 impact assessment planning intelligence.",
        "amount": 9900,   # £99/month (was £89)
        "mode": "subscription",
        "badge": "Planning & Surveyors",
        "real_world_roi": "One £800 developer method statement report every 3 months gives a 3x ROI on pure desktop work."
    },
    "commercial_forestry": {
        "name": "TreeKey Commercial & Forestry",
        "description": "For heavy machinery operators & commercial outfits. Multi-tree site clearances (3+), Ash Dieback blocks, and B2B institutional tenders.",
        "amount": 15900,  # £159/month (was £139; also replaces retired commercial_pro)
        "mode": "subscription",
        "badge": "Heavy Commercial",
        "real_world_roi": "One commercial job won per year (£3,000–£15,000) covers your subscription for 2–5 years."
    },
    "treekey_elite": {
        "name": "TreeKey Elite (All-Access Partner)",
        # Sep 12 2026, Nick's explicit ask ("remove whatsapp feature and
        # letter sending feature off anything public until its built and
        # deployed... including any statements that are untrue"): this
        # description previously promised three things that don't exist in
        # the codebase at all -- "Zero-Minute Instant WhatsApp Alerts" (the
        # real mechanism is a forward-to-yourself link inside the normal
        # email, not push delivery, and isn't even Elite-exclusive --
        # notifications.py's own comments say so), "RAMS Legal Pack" (no
        # RAMS generator exists anywhere -- it's on the未-built backlog),
        # and "Automated Direct Mailouts" (no letter-sending code exists at
        # all -- it's on the not-yet-built backlog). Reworded to only claim
        # what this tier actually, verifiably does today: full category
        # access at the widest radius, and top-priority dispatch
        # (TIER_PRIORITY is real and does put Elite ahead of lower tiers in
        # the dispatch order). Add real features back to this line only
        # once they're actually built and deployed, never before.
        "description": "100% Unrestricted Access to ALL categories across 45 miles + top-priority lead dispatch and first look at Elite-value leads, ahead of every lower tier.",
        "amount": 24900,  # £249/month (was £179; also replaces retired regional_elite)
        "mode": "subscription",
        "badge": "VIP All-Access",
        "real_world_roi": "Complete business operating system. First look at every new lead in your category before lower tiers see it."
    },
    # Single Lead Pay-As-You-Go Purchases (Single-Sale Inventory Burn)
    # Aug 30 2026: all three single-lead tiers previously promised "homeowner
    # name" as a guaranteed instant unlock, and the large tier promised
    # "developer contact" outright. Neither is accurate: UK councils never
    # publish a phone number or email on a planning application (a privacy-
    # law limit, not a scraper gap -- confirmed by auditing what the
    # homeowner_contact field actually contained across 1,085 real leads:
    # only placeholder/test data), and the applicant name is only present
    # when the council itself chose to record and publish it -- it isn't on
    # every application. Reworded to promise only what's actually, reliably
    # delivered: the address and application details, with the applicant
    # name and agent status shown *when the council recorded them* (see
    # notifications.py's send_purchased_lead_email, which now says exactly
    # that on a per-lead basis rather than promising it here as a given).
    # Sep 12 2026 rename: these were previously named/described by job SIZE
    # ("Domestic Maintenance", "Standard Felling", "Commercial/Site
    # Clearance/TPO") but calculate_lead_freshness() (database.py) has never
    # actually selected between them by size -- only by how fresh the notice
    # is (flash_hot vs active/clearance) and, from today, by the lead's
    # value tier (scanners.classify_lead_value_tier). The old names were
    # never true; renamed to match what actually decides the price, so the
    # checkout page never claims a job category the lead may not match.
    # Sep 18 2026, this session, Section 8 of the bundled-lead-and-letter
    # brief: added "includes one printed & posted introduction letter" to
    # each single-lead description/real_world_roi below, and to the
    # marketplace/lead-detail/checkout templates in main.py that reference
    # these plans. This is a DELIBERATE, EXPLICIT reversal of the Sep 12
    # 2026 rule immediately above ("remove... letter sending feature off
    # anything public until its built and deployed... including any
    # statements that are untrue") -- Nick's own instructions this session
    # confirm the bundled model ("every purchased lead includes one
    # personalised introduction letter printed and posted") as the current,
    # agreed design, not a speculative feature.
    #
    # BUT the underlying caution that Sep 12 rule was protecting against
    # still applies just as much: as of this session, letter SENDING is
    # still dry-run only. No postal provider has real credentials
    # configured (see letter_providers/*_provider.py -- Stannp is
    # unverified against a live API, Intelliprint/Postworks are unbuilt
    # stubs), no funding has been confirmed through funding.FundingGate,
    # and no migration has been run against the production database (see
    # fulfilment.py). This copy describes the INTENDED, BUILT model, not a
    # currently-operational one -- it must not be deployed live until
    # real sending is actually possible end-to-end. See
    # docs/launch_checklist.md's "copy go-live gate", which exists
    # specifically to prevent a repeat of the exact problem the Sep 12
    # rule was written to fix.
    # 2026-09-18 review, Section 4: see the "starter" plan's comment above --
    # same rule applies to every plan below. "description" and
    # "real_world_roi" are base text with no letter-posting claim; the
    # letter claim lives only in "letter_suffix"/"roi_letter_suffix" and is
    # appended by plan_description()/plan_roi() when
    # fulfilment.letter_sending_live() is True. Do not read these dict
    # entries directly for customer-facing text.
    # 2026-09-24, mailed-introduction wording audit (Nick's ask: "audit and
    # update buyer-facing product wording to match the mailed-introduction
    # model"): "name" and "real_world_roi" below used to say "Unlock" and
    # "Instant unlocked property address ... plus a Street View brief" --
    # both wrong under the current model. TreeKey does not hand the buyer
    # the homeowner's exact address; it arranges an approved postal
    # introduction to the homeowner (see letter_suffix/roi_letter_suffix,
    # already correctly gated on fulfilment.letter_sending_live() -- left
    # untouched by this pass). Street View was never something a buyer
    # could rely on for a new purchase either: main.py's street_view_
    # redirect route 403s and shows the redacted placeholder unless
    # address_release.lead_address_release_allowed() is True for that
    # specific lead, which it is not for a newly-purchased, non-historical
    # lead -- so promising it here as a standard inclusion was never
    # accurate. "description" is left as-is: "100% Exclusive... never sold
    # again" describes TreeKey's own no-resale policy (a lead sold once,
    # never resold to another contractor), not a claim that nobody else in
    # the world is aware of the underlying public planning notice.
    "single_lead_small": {
        "name": "Single Lead Purchase (Entry)",
        "description": "100% Exclusive unshared planning lead. Once purchased, this lead is permanently deleted from all systems and never sold again.",
        "letter_suffix": " Includes one personalised introduction letter, printed and posted to the homeowner on your behalf.",
        "amount": 1900,   # £19 one-off -- Standard value, past its freshest window
        "mode": "payment",
        "badge": "Single Purchase",
        "real_world_roi": "Full public planning application details for this job, exclusively yours to pursue. Applicant name included when the council has published one.",
        "roi_letter_suffix": " Also includes one printed & posted introduction letter."
    },
    "single_lead_medium": {
        "name": "Single Lead Purchase (Standard)",
        "description": "100% Exclusive unshared planning lead. Permanently burned from inventory upon purchase.",
        "letter_suffix": " Includes one personalised introduction letter, printed and posted to the homeowner on your behalf.",
        "amount": 2900,   # £29 one-off -- Standard value fresh, or Priority value past its freshest window
        "mode": "payment",
        "badge": "Single Purchase",
        "real_world_roi": "Full public planning application details for this job, exclusively yours to pursue. Applicant name included when the council has published one.",
        "roi_letter_suffix": " Also includes one printed & posted introduction letter."
    },
    "single_lead_priority": {
        "name": "Single Lead Purchase (Priority)",
        "description": "100% Exclusive unshared planning lead with elevated statutory/legal weight or scale. Permanently burned from inventory upon purchase.",
        "letter_suffix": " Includes one personalised introduction letter, printed and posted to the homeowner on your behalf.",
        "amount": 3900,   # £39 one-off -- Priority value fresh, or Elite value past its freshest window
        "mode": "payment",
        "badge": "Single Purchase",
        "real_world_roi": "Full public planning application details for this job, exclusively yours to pursue. Applicant name included when the council has published one.",
        "roi_letter_suffix": " Also includes one printed & posted introduction letter."
    },
    "single_lead_large": {
        "name": "Single Lead Purchase (Elite)",
        "description": "100% Exclusive high-value planning lead -- statutory weight or genuine urgency. Burned from inventory immediately upon purchase.",
        "letter_suffix": " Includes one personalised introduction letter, printed and posted to the homeowner on your behalf.",
        "amount": 4900,   # £49 one-off -- Elite value, freshest window
        "mode": "payment",
        "badge": "Single Purchase",
        "real_world_roi": "Full public planning application details and complete planning specs for this job, exclusively yours to pursue. Applicant name included when the council has published one.",
        "roi_letter_suffix": " Also includes one printed & posted introduction letter."
    }
}


def plan_description(plan_key: str, plan: Optional[dict] = None) -> str:
    """2026-09-18 review, Section 4: the ONLY place customer-facing plan
    description text should be read from. Returns the plan's base
    "description" and, ONLY when fulfilment.letter_sending_live() is True
    at the moment of the call (read fresh every call -- never cached),
    appends that plan's "letter_suffix" if it has one. When the flag is
    False (the default), no plan ever mentions posting a letter, however
    its dict entry is written -- this is the executable gate the audit
    asked for, not just checklist/comment wording.

    `plan` lets a caller pass an already-looked-up dict (e.g. the
    synthesized "live" dict from _resolve_live_single_lead_price) instead
    of forcing a second PLANS lookup by plan_key; falls back to
    PLANS.get(plan_key) when omitted."""
    import fulfilment
    p = plan if plan is not None else PLANS.get(plan_key)
    if not p:
        return ""
    text = p.get("description", "")
    suffix = p.get("letter_suffix", "")
    if suffix and fulfilment.letter_sending_live():
        text = f"{text}{suffix}"
    return text


def plan_roi(plan_key: str, plan: Optional[dict] = None) -> str:
    """Same gate as plan_description(), for the "real_world_roi" /
    "roi_letter_suffix" pair."""
    import fulfilment
    p = plan if plan is not None else PLANS.get(plan_key)
    if not p:
        return ""
    text = p.get("real_world_roi", "")
    suffix = p.get("roi_letter_suffix", "")
    if suffix and fulfilment.letter_sending_live():
        text = f"{text}{suffix}"
    return text


def _resolve_live_single_lead_price(lead_id: str) -> Optional[dict]:
    """Sep 12 2026, Nick's explicit ask ("everything... adjusted
    automatically in real time... that way a price decay would work IF
    that's what we choose"): computes the exact amount to charge for a
    single-lead checkout directly from THAT lead's current row, via the
    same database.calculate_lead_freshness() the marketplace card itself
    uses to display a price. Previously the charged amount came from a
    static plan_key -> Stripe price_data lookup (the freshness/checkout
    mismatch bug fixed earlier today made those two numbers agree, but
    both were still frozen at whatever they were when the page rendered).
    This closes the gap all the way: the price is recalculated fresh at
    the literal moment someone clicks buy, straight from the database, so
    there's no snapshot anywhere to go stale, and it's also the one piece
    of plumbing a future genuine decay-price or value-tier-based pricing
    model needs -- once that's decided, it changes what this function
    returns, not any Stripe-side configuration.

    Deliberately fails CLOSED, not open: if the lead can't be found, has
    already been sold, or the DB is unreachable, this returns None and the
    caller refuses the whole checkout (existing "Payment System
    Unavailable" page) rather than falling back to a possibly-wrong static
    price -- a failed checkout the customer can retry is a far smaller
    problem than charging an amount that doesn't match what's actually for
    sale, which is the exact class of bug this whole pass exists to kill."""
    try:
        import database
        conn = database.get_db_conn()
        cur = conn.cursor()
        try:
            # Sep 15 2026 fix: this used to SELECT the `status` column (the
            # claim-state: new/claimed/reserved -- for a lead still on sale
            # this is always literally "new") and pass THAT into
            # calculate_lead_freshness()'s planning_status parameter. That
            # parameter is only ever checked for one thing: whether the
            # council has actually granted/approved the application (see
            # calculate_lead_freshness's "granted"/"approved" branch,
            # database.py ~line 5078), in which case the lead is always
            # priced at the fixed "granted" rate regardless of age. Passing
            # the claim-state column instead of the real planning_status
            # column meant that branch could never fire from here -- every
            # live single-lead checkout for a genuinely granted/approved
            # lead was silently mispriced using the ordinary age-decay
            # bands instead, and the Stripe product name/description shown
            # at checkout didn't say "Officially Approved" either. The
            # marketplace listing query (get_marketplace_leads_with_
            # freshness) already selects the real planning_status column
            # correctly -- it just confusingly reuses "status" as the
            # Python dict key for it, which is what hid this from a
            # side-by-side code read. Selecting the real column here now.
            cur.execute("""
                SELECT summary, planning_status, lead_source_type, discovered_at, registered_date
                FROM leads WHERE id = %s;
            """, (lead_id,))
            row = cur.fetchone()
        finally:
            cur.close()
            conn.close()
        if not row:
            logger.warning(f"[Stripe] Live price lookup: lead_id={lead_id} not found (deleted or already sold).")
            return None
        summary, planning_status, source_type, discovered_at, registered_date = row
        fresh = database.calculate_lead_freshness(
            discovered_at, planning_status=planning_status or "pending", summary=summary or "",
            source_type=source_type or "council_planning", registered_date=registered_date
        )
        price_pounds = fresh.get("price", 0) or 0
        if price_pounds <= 0:
            logger.warning(f"[Stripe] Live price lookup: lead_id={lead_id} is expired/zero-price -- refusing checkout.")
            return None
        # Sep 12 2026: also re-resolve which plan_key applies RIGHT NOW (not
        # whichever one was embedded in the checkout link at page-load
        # time), so the Stripe product name/description shown to the
        # customer can never disagree with the amount they're actually
        # charged, even if they sat on the page long enough to cross a
        # freshness-tier boundary (e.g. Flash Hot -> Active).
        live_plan_key = fresh.get("plan_key")
        live_plan = PLANS.get(live_plan_key) if live_plan_key else None
        return {
            "amount_pence": int(price_pounds) * 100,
            "plan_key": live_plan_key,
            "name": live_plan["name"] if live_plan else "Single Lead Purchase",
            # 2026-09-18 review, Section 4: gated through plan_description()
            # so the letter-posting sentence only appears when
            # fulfilment.letter_sending_live() is True -- never read
            # live_plan["description"] directly here.
            "description": plan_description(live_plan_key, live_plan) if live_plan else "Exclusive planning lead.",
        }
    except Exception as e:
        logger.error(f"[Stripe] Live price lookup failed for lead_id={lead_id}: {e}")
        return None


def create_checkout_session(plan_key: str, outcode: str = None, lead_id: str = None, radius: int = 15,
                             full_postcode: str = None, job_size: str = None,
                             account_email: str = None) -> Optional[str]:
    """
    Creates a Stripe Checkout session for the given plan or single lead purchase.
    Returns the checkout URL to redirect the customer to.

    Sep 15 2026, Nick's exclusive-purchase reservation spec: `account_email`
    must be an email ALREADY VERIFIED by the caller (main.py's
    _verify_session_cookie on the signed session cookie) -- never a raw form
    field, and never whatever Stripe's own checkout later collects. It is
    used for two things, both only for single-lead purchases: (1) looking up
    a subscriber discount server-side via database.get_subscriber_discount,
    and (2) recording who actually bought the lead on the audit-trail order
    row. Passing account_email=None here still works exactly as before (no
    subscriber discount applied, nothing recorded) -- this function itself
    is unchanged and does not enforce login.

    2026-09-23 UPDATE, Request E follow-up (Nick's explicit instruction):
    the "login is never required to buy a lead" decision this paragraph
    used to state is NO LONGER main.py's actual behaviour -- both of this
    function's real callers, checkout()/checkout_post(), now require a
    signed session cookie (and an approved letter template) before they
    will ever call this function at all, since every plan includes a
    posted letter. account_email=None therefore no longer occurs in
    practice from either of them; it is left supported here only because
    this function has no way to enforce a caller's login requirement
    itself, and removing the parameter would be a larger, unrequested
    change to this function's own contract.

    Single-lead purchases now go through the Available -> reserved -> sold
    state machine (database.reserve_lead_for_checkout /
    confirm_reserved_lead_sale) instead of only being checked for a valid
    live price: the lead is atomically reserved for THIS checkout attempt
    before Stripe is ever involved, so two customers racing for the same
    lead can no longer both reach Stripe (previously only the webhook's
    final burn_lead_inventory caught this, after one of them had already
    paid -- see the "DOUBLE SALE RACE CONDITION" alert this used to rely on
    for manual refunding). A reservation_token (not the Stripe session id,
    which doesn't exist yet at this point) is generated up front and
    threaded through Stripe metadata so the webhook can match this exact
    checkout attempt back to its reservation and audit-trail order row.
    """
    if not stripe.api_key:
        logger.error("[Stripe] STRIPE_SECRET_KEY is not set.")
        return None

    plan = PLANS.get(plan_key)
    if not plan:
        logger.error(f"[Stripe] Unknown plan: {plan_key}")
        return None

    import uuid
    import time
    import database
    reservation_token = None

    try:
        unit_amount = plan["amount"]
        product_name = plan["name"]
        # 2026-09-18 review, Section 4: gated -- see plan_description()'s
        # docstring. Do not read plan["description"] directly.
        product_description = plan_description(plan_key, plan)
        discount_pct = 0
        if lead_id:
            # Single-lead purchase: charge the live price (and use the live
            # product name/description), not whatever was static/embedded
            # in the checkout link at page-load time -- see
            # _resolve_live_single_lead_price's own docstring. Refuse the
            # whole checkout on any failure rather than silently falling
            # back to a possibly stale or wrong static amount.
            live = _resolve_live_single_lead_price(lead_id)
            if live is None:
                logger.error(f"[Stripe] Refusing checkout for lead_id={lead_id} -- no valid live price available.")
                return None
            unit_amount = live["amount_pence"]
            product_name = live["name"]
            product_description = live["description"]

            # Atomically reserve the lead for THIS checkout attempt before
            # Stripe is ever involved -- refuse the whole checkout (same
            # pattern as the price-unavailable case above) rather than let
            # a customer pay for a lead someone else is already buying.
            reservation_token = uuid.uuid4().hex
            reserved_ok = database.reserve_lead_for_checkout(
                lead_id, account_email or "anonymous", reservation_token
            )
            if not reserved_ok:
                logger.warning(f"[Stripe] Refusing checkout for lead_id={lead_id} -- could not reserve (already sold or reserved by another in-progress checkout).")
                return None

            # Server-side subscriber discount -- only ever computed from an
            # already-verified account_email, never a checkout-collected
            # email. Applied to the live price before Stripe ever sees it,
            # so Stripe always charges the final, correct amount directly
            # (no promo-code layer to keep in sync).
            if account_email:
                disc = database.get_subscriber_discount(account_email)
                if disc.get("eligible"):
                    discount_pct = disc.get("discount_pct", 0)
                    if discount_pct > 0:
                        unit_amount = max(1, round(unit_amount * (100 - discount_pct) / 100))
                        product_description = f"{product_description} ({discount_pct}% member discount applied)"

        price_data = {
            "currency": "gbp",
            "product_data": {"name": product_name, "description": product_description},
            "unit_amount": unit_amount,
        }
        if plan["mode"] == "subscription":
            price_data["recurring"] = {"interval": "month"}

        session_params = {
            "line_items": [{"price_data": price_data, "quantity": 1}],
            "mode": plan["mode"],
            "success_url": f"{PUBLIC_APP_URL}/payment/success?session_id={{CHECKOUT_SESSION_ID}}",
            "cancel_url": f"{PUBLIC_APP_URL}/pricing",
            "allow_promotion_codes": True,
            "metadata": {"plan_key": plan_key, "tier": plan_key}
        }

        if plan["mode"] == "subscription":
            # Carry plan_key on the Subscription object itself (not just the Checkout
            # Session), so later subscription-level webhook events still have it.
            session_params["subscription_data"] = {"metadata": {"plan_key": plan_key, "tier": plan_key}}

        if outcode:
            session_params["client_reference_id"] = outcode
            session_params["metadata"]["outcode"] = outcode
            session_params["metadata"]["radius_miles"] = str(radius)

        # Sep 8 2026, proximity-system rework: carry the customer's raw
        # postcode input (may be a full postcode, more precise than the
        # bare outcode above) and job-size preference through Stripe
        # metadata so the webhook can pass them straight to
        # database.register_or_update_subscription. Both optional --
        # nothing here changes for a customer who only gives an outcode.
        if full_postcode:
            session_params["metadata"]["full_postcode"] = full_postcode
        if job_size:
            session_params["metadata"]["job_size"] = job_size

        if lead_id:
            session_params["metadata"]["lead_id"] = lead_id
            session_params["metadata"]["reservation_token"] = reservation_token
            if account_email:
                session_params["metadata"]["account_email"] = account_email
            if discount_pct:
                session_params["metadata"]["discount_pct"] = str(discount_pct)

            # Give Stripe's own expiry a matching, explicit cutoff (its
            # default is 24h) so an abandoned checkout can't sit open far
            # longer than the reservation that's holding the lead for it --
            # see database.STRIPE_CHECKOUT_EXPIRY_MINUTES/RESERVATION_
            # RELEASE_MINUTES's own comment for why the reservation side is
            # deliberately a few minutes longer than this, not the same.
            session_params["expires_at"] = int(time.time()) + database.STRIPE_CHECKOUT_EXPIRY_MINUTES * 60

            # Audit-trail row, written now (before the Stripe redirect) so
            # there's a durable record even if the customer never completes
            # payment -- Nick's spec: "a record linking the buyer, lead,
            # checkout, payment, price and fulfilment outcome."
            database.record_order(
                reservation_token, account_email, unit_amount,
                lead_id=lead_id, plan=plan_key, status="pending"
            )

        session = stripe.checkout.Session.create(**session_params)
        logger.info(f"[Stripe] Checkout session created for plan '{plan_key}' outcode={outcode} radius={radius}mi (lead_id={lead_id}): {session.id}")
        return session.url

    except stripe.error.AuthenticationError:
        logger.error("[Stripe] Invalid API key.")
        # Sep 3 2026: found during the "predict future issues, even ones
        # that have never errored" audit -- this is the single most
        # expensive silent-failure path in the whole app. This function IS
        # the customer checkout button. If STRIPE_SECRET_KEY ever goes
        # invalid (revoked, rotated in Stripe but not updated in Render,
        # accidentally swapped for a test-mode key), every single customer
        # trying to pay gets a silently-failed checkout (this just returns
        # None) with nothing ever alerting a human -- revenue could stop
        # completely and the only symptom would be a customer complaining,
        # or nobody noticing at all. The webhook side of this file already
        # alerts on its own auth/signature failures; this is the matching
        # fix for the checkout-creation side.
        import notifications
        notifications.send_system_incident_alert(
            category="SECURITY & API KEYS",
            title="STRIPE API KEY INVALID -- CHECKOUT IS DOWN",
            description="CRITICAL: Stripe rejected checkout-session creation with an authentication error -- STRIPE_SECRET_KEY is invalid, revoked, or mismatched (e.g. a live key swapped for test, or vice versa).",
            impact="No customer can complete a purchase right now -- every checkout attempt is silently failing.",
            action_required="Check STRIPE_SECRET_KEY in Render against the current key in the Stripe Dashboard (API keys page). Confirm live/test mode matches.",
            severity="CRITICAL",
            throttle_hours=1.0
        )
    except stripe.error.StripeError as e:
        logger.error(f"[Stripe] API error: {e}")
    except Exception as e:
        logger.error(f"[Stripe] Unexpected error: {e}", exc_info=True)

    # Reached only on a failure AFTER the lead was reserved (Stripe itself
    # rejected session creation, or raised unexpectedly) -- never on the
    # success path above, which already returned. Without this, a Stripe-
    # side failure here would leave the lead reserved-and-unavailable in
    # the Marketplace for the full RESERVATION_RELEASE_MINUTES sweep window
    # even though no checkout was ever actually created for it.
    if reservation_token and lead_id:
        database.release_lead_reservation(lead_id, reservation_token)
        database.update_order_fulfillment(reservation_token, "failed", "stripe_session_creation_failed")
    return None


def handle_stripe_webhook(payload: bytes, sig_header: str) -> dict:
    """
    Verifies and processes an incoming Stripe webhook event.
    Returns a dict with the event type and relevant data.
    """
    import notifications

    if not STRIPE_WEBHOOK_SECRET:
        logger.error("[Stripe Webhook] STRIPE_WEBHOOK_SECRET is not set.")
        notifications.send_system_incident_alert(
            category="SECURITY & PAYMENTS",
            title="STRIPE_WEBHOOK_SECRET NOT SET IN ENVIRONMENT",
            description="CRITICAL: The Stripe Webhook listener received an event but STRIPE_WEBHOOK_SECRET is missing.",
            impact="Subscription activations and one-off lead credit purchases cannot be fulfilled automatically.",
            action_required="Add STRIPE_WEBHOOK_SECRET from your Stripe Dashboard (Developers > Webhooks) to Render Environment Settings.",
            severity="CRITICAL",
            throttle_hours=4.0
        )
        return {"error": "Webhook secret not configured"}

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
    except stripe.error.SignatureVerificationError:
        logger.warning("[Stripe Webhook] Invalid signature — possible spoofed request.")
        # Sep 4 2026: bumped from WARNING to CRITICAL. notifications.
        # send_system_incident_alert()'s WARNING tier now logs-and-waits-
        # for-recurrence instead of emailing immediately (see that
        # function's own Sep 4 comment) -- right for a benign, low-stakes
        # scraper quirk, wrong here: a broken STRIPE_WEBHOOK_SECRET means
        # every real payment silently fails to fulfil, and a genuine
        # spoofed request is a live security event. Neither should sit
        # unreported for up to 3 days waiting to "recur".
        notifications.send_system_incident_alert(
            category="SECURITY & PAYMENTS",
            title="STRIPE WEBHOOK SIGNATURE MISMATCH / INVALID SIGNATURE",
            description="An incoming webhook payload failed cryptographic signature verification against STRIPE_WEBHOOK_SECRET.",
            impact="The webhook was rejected to protect against spoofed transactions. If this was a legitimate Stripe event, webhook fulfillment failed.",
            action_required="1. Verify STRIPE_WEBHOOK_SECRET in Render matches the Signing Secret in Stripe Dashboard. 2. Check if a new webhook endpoint was created in Stripe.",
            severity="CRITICAL",
            throttle_hours=2.0
        )
        return {"error": "Invalid signature"}
    except Exception as e:
        logger.error(f"[Stripe Webhook] Parse error: {e}")
        return {"error": str(e)}

    # Sep 16 2026, production incident fix (the REAL root cause of the £19
    # purchase's webhook 500, found in Render's actual logs after the
    # lead_score fix above -- necessary but not sufficient -- still didn't
    # stop the crash): stripe.Webhook.construct_event() now returns a real
    # stripe.Event object, not a plain dict, on whatever stripe-python
    # version Render has installed. Bracket access (event["type"]) still
    # works, but EVERY .get(...) call on it -- and on every nested Stripe
    # object inside it, e.g. data.get(...) below -- raises AttributeError
    # ("'get' is a dict method, but a Event is not a dict. Use .to_dict()
    # to convert it.") because stripe's object wrapper intercepts attribute
    # lookups that collide with dict method names. This crashed BEFORE any
    # of this function's own code (including today's earlier lead_score
    # fix) was ever reached, on every single delivery/retry/resend, which
    # is why that fix alone never stopped the 500s. Converting to a plain,
    # fully-nested dict here once, immediately, means every existing
    # `.get(...)` call throughout this whole function (there are many)
    # keeps working exactly as written, with no other code changes needed.
    event = event.to_dict() if hasattr(event, "to_dict") else event

    event_type = event["type"]
    data = event["data"]["object"]
    event_id = event.get("id")
    is_retry = _seen_stripe_event(event_id)

    # GDPR Masking for logs
    mask = lambda e: f"{e[0]}***@{e.split('@')[1]}" if e and '@' in e else "unknown"

    if event_type == "checkout.session.completed":
        session_id = data.get("id")
        customer_email = data.get("customer_details", {}).get("email", "unknown")
        amount = data.get("amount_total", 0)
        metadata = data.get("metadata", {})
        outcode = data.get("client_reference_id") or metadata.get("outcode")
        lead_id = metadata.get("lead_id")
        reservation_token = metadata.get("reservation_token")

        import database
        import fulfilment
        # 1. If this was a single lead purchase, execute the Single-Sale Inventory Burn
        if lead_id and reservation_token:
            # Sep 15 2026: the reservation-based flow. This session was
            # created after the exclusive-purchase reservation spec shipped,
            # so a reservation was taken out atomically BEFORE Stripe was
            # ever involved (payments.create_checkout_session) -- confirm
            # THAT exact reservation now, rather than the old "first paid
            # webhook to arrive wins" burn_lead_inventory check.
            #
            # 2026-09-18 review, Section 3: confirm_reserved_lead_sale can
            # now RAISE fulfilment.AllocationPersistenceError instead of
            # returning None, specifically for the case where the payment
            # and reservation were both genuinely valid (the UPDATE matched)
            # but persisting the letter obligation then failed. That is a
            # transient DB-write problem, not "reservation lost" -- it must
            # NOT fall into the auto-refund branch below, which exists only
            # for a genuinely expired/stolen reservation. Caught separately,
            # before lead_data is ever assigned from a call that could raise.
            try:
                lead_data = database.confirm_reserved_lead_sale(lead_id, reservation_token, customer_email)
            except fulfilment.AllocationPersistenceError as e:
                issue_id = database.record_payment_reconciliation_issue(
                    reason=f"allocation_persistence_failed (reservation path): {e}",
                    stripe_event_id=event_id, stripe_reference=reservation_token,
                    buyer_email=customer_email, lead_reference=lead_id,
                )
                logger.error(f"[Stripe] Allocation persistence FAILED for lead {lead_id} / session "
                             f"{session_id} after a VALID reservation was confirmed ({mask(customer_email)}) "
                             f"-- not refunding, not marking fulfilled, leaving the event unmarked so "
                             f"Stripe's retry (or a manual Resend) can complete it once the underlying "
                             f"DB problem clears. Reconciliation issue: {issue_id}.")
                notifications.send_system_incident_alert(
                    category="REVENUE & BILLING",
                    title=f"PAYMENT RECEIVED, ALLOCATION FAILED: {mask(customer_email)} — lead {lead_id}",
                    description=(f"Customer {customer_email} paid £{amount / 100:.2f} for lead {lead_id}. "
                                  f"Stripe confirmed payment and the reservation was valid, but saving the "
                                  f"resulting letter obligation to the database failed: {e}"),
                    impact=("No refund was issued and the lead was NOT marked sold. This is a database "
                             "write failure, not a lost/stolen reservation -- the customer's payment and "
                             "reservation are both still good. Stripe will retry this webhook "
                             "automatically; it should self-resolve once the DB issue clears."),
                    action_required=(f"Check application/database health now. If unresolved after Stripe's "
                                       f"retry window (Stripe retries for up to ~3 days), resolve "
                                       f"reconciliation issue {issue_id} manually and complete the sale by hand."),
                    severity="CRITICAL",
                    throttle_hours=0.0,
                )
                return {"error": "allocation_persistence_failed", "retry": True,
                        "reconciliation_issue_id": issue_id, "lead_id": lead_id}
            if lead_data:
                logger.info(f"[Stripe] Lead {lead_id} sold to {mask(customer_email)} (reservation {reservation_token[:8]}...)")
                # Sep 16 2026, production incident fix: this used to send the
                # email FIRST, then mark the order/event fulfilled. A real
                # customer's payment succeeded, the lead was correctly burned
                # right above, but send_purchased_lead_email then raised an
                # unhandled exception (see notifications.py's matching Sep 16
                # comment) -- with fulfillment never marked, the 500 caused
                # Stripe to retry this exact webhook, and on retry
                # confirm_reserved_lead_sale correctly found nothing to
                # confirm (the lead was already 'claimed', not 'reserved'
                # anymore) and fell into the "reservation lost" branch below,
                # which AUTO-REFUNDED a payment for a lead the customer had
                # already legitimately received. The database write that
                # actually matters -- marking this sale settled -- now
                # happens immediately, before the (best-effort, now
                # self-contained/non-raising) email send, so a future email
                # failure of any kind can never again be mistaken for a lost
                # reservation or trigger a wrongful refund.
                database.update_order_fulfillment(reservation_token, "paid", "fulfilled")
                _mark_stripe_event_fulfilled(event_id)
                notifications.send_purchased_lead_email(customer_email, lead_data)
            elif is_retry:
                logger.info(f"[Stripe] Duplicate webhook delivery for already-processed lead {lead_id} ({mask(customer_email)}) — ignoring retry.")
            elif database.get_already_sold_lead_if_matching_session(lead_id, reservation_token):
                # Sep 16 2026, production incident fix: confirm_reserved_lead_sale
                # only matches a lead still in status='reserved' -- once THIS
                # exact reservation already sold it (an earlier delivery of
                # this same event), a second delivery (manual Resend, or
                # Stripe's own retry) finds nothing to confirm and used to
                # fall straight into the "reservation lost" branch below,
                # which auto-refunded an already-completed sale. Live
                # incident: the very first delivery correctly sold the lead
                # but then crashed on the confirmation email (unrelated bug,
                # fixed separately) before the event was marked fulfilled, so
                # the retry looked identical to a genuinely lost reservation.
                # This check catches exactly that case (same reservation,
                # lead already 'claimed') and re-sends the confirmation
                # instead of refunding -- see database.
                # get_already_sold_lead_if_matching_session's own docstring.
                already_sold = database.get_already_sold_lead_if_matching_session(lead_id, reservation_token)
                order_status = database.get_order_status(reservation_token)
                if order_status == "refunded":
                    # A refund already went out for this exact order (most
                    # likely from before this fix existed) -- don't silently
                    # re-mark it paid or re-send the lead as if nothing
                    # happened. Whether to still honour the lead for free
                    # after a refund is Nick's call, not an automatic one.
                    logger.warning(f"[Stripe] Lead {lead_id} already sold+claimed via this reservation, but the order shows REFUNDED -- not auto-recovering, needs manual review ({mask(customer_email)}).")
                else:
                    logger.info(f"[Stripe] Duplicate delivery for already-sold lead {lead_id} ({mask(customer_email)}) — re-sending confirmation email, no refund.")
                    database.update_order_fulfillment(reservation_token, "paid", "fulfilled")
                    notifications.send_purchased_lead_email(customer_email, already_sold)
                _mark_stripe_event_fulfilled(event_id)
            elif database.has_unresolved_payment_reconciliation_issue(
                stripe_event_id=event_id, stripe_reference=reservation_token,
            ):
                # 2026-09-18 review, Section 4 (second pass): "Test
                # successful Stripe payment followed by database failure
                # and then a delayed retry after reservation expiry.
                # Reconcile using durable purchase/payment identity."
                #
                # confirm_reserved_lead_sale found nothing to confirm
                # (same as the "genuinely lost reservation" branch below),
                # but there is ALREADY an open, admin-alerted
                # reconciliation record for this exact payment (matched by
                # the durable Stripe event id / checkout-session id, not
                # the lead's own mutable status) -- see
                # fulfilment.has_unresolved_reconciliation_issue's
                # docstring for the full scenario this catches: payment
                # succeeded, the local allocation write failed
                # (AllocationPersistenceError, handled above), and this
                # delivery is a DELAYED retry that arrived after
                # RESERVATION_RELEASE_MINUTES swept the reservation back
                # to 'new' -- at that point confirm_reserved_lead_sale can
                # no longer tell "delayed retry of a real failure" apart
                # from "reservation genuinely never confirmed" using lead
                # state alone. Auto-refunding here would contradict the
                # still-open alert asking a human to complete the sale by
                # hand, and risks a double-refund if that human already
                # acted differently. Instead: no refund, no fulfilment
                # mark, same retryable shape as the AllocationPersistenceError
                # branch above -- a human resolving the existing
                # reconciliation issue (or the DB problem clearing so a
                # genuine retry succeeds) is what ends this state, not an
                # automatic refund.
                logger.warning(f"[Stripe] Lead {lead_id} / session {session_id} has no live reservation to confirm, "
                                f"but an OPEN reconciliation issue already exists for this exact payment "
                                f"({mask(customer_email)}) -- not auto-refunding (would contradict a still-open "
                                f"manual reconciliation), leaving the event unmarked so a resolved issue or a "
                                f"successful retry can still complete it.")
                return {"error": "unresolved_reconciliation_issue_pending", "retry": True, "lead_id": lead_id}
            else:
                # Payment succeeded but this session's reservation is gone --
                # expired past RESERVATION_RELEASE_MINUTES before payment
                # completed, or (should be impossible, but treated the same
                # way defensively) stolen by another session. Nick's spec:
                # "automatically refund it without revealing the lead" --
                # unlike the old flow, this is no longer a manual-only alert.
                # Only reached once has_unresolved_payment_reconciliation_
                # issue (above) has confirmed there's no already-open
                # reconciliation record for this exact payment -- see that
                # branch's own comment.
                payment_intent_id = data.get("payment_intent")
                refunded = False
                refund_error = None
                if payment_intent_id:
                    try:
                        stripe.Refund.create(
                            payment_intent=payment_intent_id,
                            reason="requested_by_customer",
                            idempotency_key=f"tk_reservation_lost_{event_id}",
                        )
                        refunded = True
                    except Exception as e:
                        refund_error = str(e)
                        logger.error(f"[Stripe] Auto-refund FAILED for lead {lead_id} / session {session_id}: {e}")
                else:
                    refund_error = "no payment_intent on the completed session"
                database.update_order_fulfillment(
                    reservation_token,
                    "refunded" if refunded else "refund_failed",
                    "reservation_lost_auto_refunded" if refunded else "reservation_lost_refund_failed",
                )
                logger.warning(f"[Stripe] Lead {lead_id} reservation lost before payment completed ({mask(customer_email)}) -- auto-refund {'succeeded' if refunded else 'FAILED: ' + str(refund_error)}.")
                notifications.send_system_incident_alert(
                    category="REVENUE & BILLING",
                    title=(f"Lead reservation lost, auto-refunded {mask(customer_email)}" if refunded
                           else f"REFUND FAILED: {mask(customer_email)} paid for a lead that's no longer available!"),
                    description=(f"Customer {customer_email} paid £{amount / 100:.2f} for lead {lead_id}, but their reservation had "
                                  f"already expired or been superseded by the time payment completed. "
                                  + (f"An automatic Stripe refund was issued." if refunded
                                     else f"The automatic refund attempt FAILED ({refund_error}) -- this needs manual action.")),
                    impact=("Customer was refunded automatically; no lead was sent." if refunded
                            else "Customer paid for a lead but did not receive it, and was NOT automatically refunded."),
                    action_required=("No action required -- refunded automatically. Confirm in Stripe if you want to double check." if refunded
                                      else "Manually refund the payment in Stripe or email the customer offering a credit."),
                    severity="WARNING" if refunded else "CRITICAL",
                    throttle_hours=0.0
                )
                _mark_stripe_event_fulfilled(event_id)
        elif lead_id:
            # Legacy path: a checkout session created before this deploy
            # (no reservation_token in its metadata) may still be completing
            # payment now -- fall back to the original burn-on-payment
            # behaviour exactly as before, so an in-flight sale from the old
            # flow isn't broken by this release. Every NEW checkout always
            # carries a reservation_token (set unconditionally in
            # create_checkout_session whenever lead_id is set), so this
            # branch naturally stops being hit once old sessions expire.
            # 2026-09-18 review, Section 3: same distinction as the
            # reservation path above -- burn_lead_inventory can also raise
            # fulfilment.AllocationPersistenceError when the UPDATE genuinely
            # matched (a real lead WAS just claimed for this buyer) but
            # persisting the letter obligation then failed. Left uncaught,
            # this used to be indistinguishable from "lead already claimed
            # by someone else" below and would have wrongly fired the
            # DOUBLE SALE RACE CONDITION alert for what is actually a
            # transient DB-write problem on a legitimate, uncontested sale.
            try:
                lead_data = database.burn_lead_inventory(lead_id, customer_email)
            except fulfilment.AllocationPersistenceError as e:
                issue_id = database.record_payment_reconciliation_issue(
                    reason=f"allocation_persistence_failed (legacy burn path): {e}",
                    stripe_event_id=event_id, stripe_reference=session_id,
                    buyer_email=customer_email, lead_reference=lead_id,
                )
                logger.error(f"[Stripe] Allocation persistence FAILED for lead {lead_id} (legacy checkout, "
                             f"{mask(customer_email)}) after a valid claim -- not a double sale, a DB write "
                             f"failure. Not refunding, leaving the event unmarked for retry. "
                             f"Reconciliation issue: {issue_id}.")
                notifications.send_system_incident_alert(
                    category="REVENUE & BILLING",
                    title=f"PAYMENT RECEIVED, ALLOCATION FAILED: {mask(customer_email)} — lead {lead_id} (legacy path)",
                    description=(f"Customer {customer_email} paid £{amount / 100:.2f} for lead {lead_id} via "
                                  f"the legacy pre-reservation checkout path. The lead was genuinely claimed "
                                  f"for them, but saving the resulting letter obligation failed: {e}"),
                    impact=("No refund was issued. This is a database write failure, not a double sale -- "
                             "Stripe will retry this webhook automatically."),
                    action_required=(f"Check application/database health. If unresolved after Stripe's "
                                       f"retry window, resolve reconciliation issue {issue_id} manually."),
                    severity="CRITICAL",
                    throttle_hours=0.0,
                )
                return {"error": "allocation_persistence_failed", "retry": True,
                        "reconciliation_issue_id": issue_id, "lead_id": lead_id}
            if lead_data:
                logger.info(f"[Stripe] Lead {lead_id} burned from inventory for {mask(customer_email)} (legacy pre-reservation checkout)")
                notifications.send_purchased_lead_email(customer_email, lead_data)
                _mark_stripe_event_fulfilled(event_id)
            elif is_retry:
                logger.info(f"[Stripe] Duplicate webhook delivery for already-processed lead {lead_id} ({mask(customer_email)}) — ignoring retry.")
            else:
                logger.warning(f"[Stripe] Lead {lead_id} was already claimed or not found, but {mask(customer_email)} paid for it!")
                notifications.send_system_incident_alert(
                    category="REVENUE & BILLING",
                    title=f"DOUBLE SALE RACE CONDITION: {mask(customer_email)} paid for already-claimed lead!",
                    description=f"Customer {customer_email} paid £{amount / 100:.2f} for lead {lead_id}, but the lead was already claimed by someone else or does not exist.",
                    impact="Customer paid for a lead but did not receive it. They will be angry.",
                    action_required="Manually refund the payment in Stripe or email the customer offering a credit.",
                    severity="CRITICAL",
                    throttle_hours=0.0
                )

        # 2. If this was a subscription, register with seniority timestamp
        if not lead_id:
            sub_tier = metadata.get("tier", "starter")
            # Sep 8 2026: prefer the full postcode when the customer gave one
            # (metadata.full_postcode) -- register_or_update_subscription's
            # resolve_location geocodes that to an exact pin instead of just
            # the outcode centroid. Falls back to the outcode exactly as
            # before when no full postcode was captured.
            sub_location_input = metadata.get("full_postcode") or outcode or "GB"
            sub_radius = int(metadata.get("radius_miles", 15))
            sub_job_size = metadata.get("job_size", "all")
            reg_ok = database.register_or_update_subscription(
                customer_email=customer_email,
                outcode=sub_location_input,
                tier=sub_tier,
                stripe_sub_id=data.get("subscription", ""),
                radius=sub_radius,
                job_size_preference=sub_job_size
            )
            logger.info(f"[Stripe] Subscription registered for {mask(customer_email)} ({sub_tier} in {sub_location_input} ±{sub_radius}mi, job_size={sub_job_size}): {reg_ok}")
            if reg_ok:
                _mark_stripe_event_fulfilled(event_id)
                # Sep 11 2026, Nick's ask ("we should have an 'i agree to
                # terms and conditions' button"): checkout_post already
                # server-side rejected this checkout entirely if the
                # /checkout/{plan_key} form's checkbox wasn't ticked, so by
                # the time Stripe fires this webhook consent has already
                # happened -- this just stamps when the row it applies to
                # actually landed. COALESCE inside the function means a
                # later plan-change webhook re-running this never
                # overwrites the original acceptance timestamp.
                database.record_subscription_terms_acceptance(customer_email)

        logger.info(f"[Stripe] Payment complete — {mask(customer_email)} — £{amount / 100:.2f}")
        return {"event": "payment_complete", "email": customer_email,
                "session_id": session_id, "amount_pence": amount, "outcode": outcode, "lead_id": lead_id}

    elif event_type == "checkout.session.expired":
        # Sep 15 2026: releases the reservation immediately instead of
        # waiting out the full RESERVATION_RELEASE_MINUTES passive sweep --
        # only fires if this event type is enabled on the Stripe webhook
        # endpoint's configuration; the passive sweep (database.
        # release_expired_reservations, called opportunistically from
        # notifications.dispatch_lead_alerts) is what actually guarantees
        # an abandoned lead becomes available again, so nothing depends on
        # Stripe sending this.
        metadata = data.get("metadata", {})
        lead_id = metadata.get("lead_id")
        reservation_token = metadata.get("reservation_token")
        if lead_id and reservation_token:
            import database
            released = database.release_lead_reservation(lead_id, reservation_token)
            if released:
                database.update_order_fulfillment(reservation_token, "expired", "checkout_abandoned")
                logger.info(f"[Stripe] Checkout for lead {lead_id} expired unpaid -- reservation released immediately.")
        return {"event": "checkout_expired"}

    elif event_type == "customer.subscription.created":
        customer_id = data.get("customer")
        plan_id = data.get("items", {}).get("data", [{}])[0].get("plan", {}).get("id", "unknown")
        logger.info(f"[Stripe] New subscription — customer {customer_id} — plan {plan_id}")
        return {"event": "subscription_created", "customer_id": customer_id}

    elif event_type == "customer.subscription.updated":
        # Plan upgrade/downgrade via the Stripe Billing Portal fires this event, not
        # checkout.session.completed — previously nothing handled it at all, so a
        # contractor's tier/quota never changed on a self-service plan switch.
        subscription_id = data.get("id")
        items = data.get("items", {}).get("data", [])
        new_price = (items[0].get("price") or {}) if items else {}
        new_amount = new_price.get("unit_amount")
        import database
        # Best-effort reverse-match of the new Stripe price back to a PLANS tier by
        # amount. If a future price change ever makes two tiers share a point, an
        # ambiguous match is flagged for manual review rather than guessed at.
        matches = [k for k, v in PLANS.items() if v["mode"] == "subscription" and v["amount"] == new_amount]
        if len(matches) == 1:
            new_tier = matches[0]
            ok = database.update_subscription_tier_by_stripe_id(subscription_id, new_tier)
            logger.info(f"[Stripe] Subscription {subscription_id} plan change -> {new_tier} (£{(new_amount or 0) / 100:.2f}/mo): updated={ok}")
            return {"event": "subscription_updated", "subscription_id": subscription_id, "new_tier": new_tier}
        else:
            logger.warning(f"[Stripe] Subscription {subscription_id} updated to £{(new_amount or 0) / 100:.2f}/mo — {len(matches)} PLANS tiers match ({matches}), cannot auto-resolve.")
            notifications.send_system_incident_alert(
                category="REVENUE & BILLING",
                title=f"SUBSCRIPTION PLAN CHANGE NEEDS MANUAL REVIEW: {subscription_id}",
                description=f"Subscription {subscription_id} changed to a new price (£{(new_amount or 0) / 100:.2f}/mo) that could not be uniquely matched to a PLANS tier (candidates: {matches}).",
                impact="This contractor's tier/quota was NOT updated automatically and may now not match what they're paying for.",
                action_required="Check the Stripe subscription and update contractor_subscriptions.tier for this customer manually.",
                severity="WARNING",
                throttle_hours=1.0
            )
            return {"event": "subscription_updated", "subscription_id": subscription_id, "new_tier": None}

    elif event_type == "customer.subscription.deleted":
        customer_id = data.get("customer")
        subscription_id = data.get("id")
        logger.info(f"[Stripe] Subscription cancelled - customer {customer_id}")
        import database
        if subscription_id:
            database.deactivate_subscription_on_cancellation(subscription_id)
        return {"event": "subscription_cancelled", "customer_id": customer_id}

    elif event_type == "invoice.payment_failed":
        customer_email = data.get("customer_email", "unknown")
        amount_due = data.get("amount_due", 0) / 100
        logger.warning(f"[Stripe] Payment failed — {mask(customer_email)}")
        notifications.send_system_incident_alert(
            category="REVENUE & BILLING",
            title=f"CUSTOMER PAYMENT FAILED (£{amount_due:.2f} — {mask(customer_email)})",
            description=f"A recurring subscription renewal charge failed for customer {mask(customer_email)}.",
            impact="Customer's card was declined. If uncollected, their territory subscription will lapse.",
            action_required="Log into Stripe Dashboard (Payments > Failed) to check decline reason or contact the contractor directly.",
            metric_details={"Customer": customer_email, "Amount": f"£{amount_due:.2f}"},
            severity="WARNING",
            throttle_hours=12.0
        )
        return {"event": "payment_failed", "email": customer_email}

    logger.info(f"[Stripe] Unhandled event type: {event_type}")
    return {"event": event_type, "status": "unhandled"}

