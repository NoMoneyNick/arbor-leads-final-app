"""
address_release.py -- 2026-09-18 review, Section 5: "Confirm that the
separate address-release policy gate was implemented, including protection
against alternative routes revealing the address. Do not treat payment,
funding or provider acceptance as legal approval to disclose."

WHAT THIS IS NOT:
- It is not `require_lead_ownership` (main.py) / fulfilment.get_lead_owner.
  Ownership answers "did THIS contractor pay for THIS lead" -- a commercial
  question. This module answers a different, independent question: "has a
  human confirmed it is legally OK for TreeKey to show anyone the exact
  street address at all, right now." A contractor can legitimately own a
  lead and still not be shown the address, if this gate is off.
- It is not `funding.py` (has money been reserved/spent) or provider
  acceptance (did a postal provider agree to post a letter). Money moving
  and a provider agreeing to carry mail are commercial/operational facts,
  not a legal basis to disclose someone's home address. Per Nick's explicit
  instruction this section responds to, none of those three facts is ever
  read by this module or should ever substitute for it elsewhere.
- It is not `suppression.py` (postal_suppressions) -- that is a per-address
  opt-out for whether a LETTER gets physically posted TO that address. This
  module is about whether the address is ever rendered into an HTTP
  response TO A CONTRACTOR (or anyone else via the web app). The two are
  orthogonal: an address can be release-blocked here and still get a
  posted letter (the letter goes to the homeowner, not to a viewer of this
  app), and an address can be release-live here while still suppressed
  from posting (a homeowner who objected to receiving mail but whose
  address a paying contractor is still allowed to see, if that's ever the
  policy -- this module doesn't decide that either way, it only gates
  on/off).

WHY IT EXISTS:
docs/launch_checklist.md item 3 (Article 14 disclosure timing) is an
explicitly UNRESOLVED legal question, requiring a UK data-protection
adviser -- not something this session can decide in code. Until that's
resolved, the only safe default is that the literal address of a real
person is not shown to anyone (beyond TreeKey's own admin/ops staff, who
already have a separate, existing trust boundary -- see
require_lead_ownership's "Admin ... always passes" and the various
DASHBOARD_USER/PASS-gated /admin/* routes) through the web app, no matter
who paid for the lead, whether funding was reserved, or whether a postal
provider has confirmed it will carry a letter to it. Ownership/payment
still gates WHO may attempt to view a lead's page at all -- this gate,
checked on top of and after that, decides whether the actual street
address is rendered into the response, or a redacted placeholder is shown
instead.

DEFAULT: OFF (address never released) -- same "fail closed / missing
config fails safely and visibly" posture as fulfilment.letter_sending_live()
(Section 4) and every other gate this session added. Flipping it on is a
deliberate, informed human decision (per the docstring above, expected to
follow the outstanding legal review), not a side effect of a customer
paying, a budget being confirmed, or a provider accepting a job.

USAGE:
Call guarded_address(real_address) at the LAST possible point before an
address string is interpolated into an HTTP response (HTML, a redirect
URL, a WhatsApp share link, an email body rendered for on-screen display,
etc.) -- never earlier, so a route that reads the real address for some
other purpose (e.g. worker.py/letter_providers actually posting a real
physical letter, which must keep using the true address regardless of this
flag -- the letter goes to the homeowner, this flag is about what a
VIEWER of the app sees) never has to route through here at all.

Every known contractor/customer-facing route that renders a specific
lead's exact address is wired to this gate (see docs/launch_checklist.md
and tests/test_address_release_gate.py for the full, current list):
  - /generate-letter/{lead_id}      (letter preview)
  - /generate-street-flyer/{lead_id} (neighbor flyer -- includes the exact
    address in its body text, not just the street name)
  - /street-view/{reference}        (redirect URL itself encodes the
    address -- the single easiest "alternative route" to leak it via a
    shared/bookmarked link)
  - /dashboard                      (contractor_dashboard -- both the
    on-page address text and the WhatsApp-forward link built from it)
  - /my-leads                       (both the paid and free-tier branches)
  - /free-dashboard                 (free-tier claimed-lead address row)
Admin-only views (basic-auth-gated /admin/* routes, cron-secret-gated
scanner endpoints) are a separate, pre-existing trust boundary and are
deliberately NOT redacted by this gate -- TreeKey's own ops staff need the
real address to run the business; the concern this gate addresses is
disclosure to contractors/customers/the public, not to TreeKey itself.

CONTRACTOR-APPROVAL UI -- BUILT, 2026-09-18 review, Section 1 (second
pass): main.py's /letter-settings/preview and /letter-settings/approve
routes now exist. This gate turned out not to interact with them at all,
by construction, for two independent reasons:

  1. The preview a contractor approves is rendered against fixed,
     illustrative SAMPLE lead data (letter_content.PREVIEW_ADDRESS etc,
     via letter_content.render_preview_letter) -- never a real lead's
     address, so this gate's redaction is never in the render path being
     approved at all. contractor_letter_settings is per-contractor, not
     per-lead; there is no specific real lead to redact at setup time.
  2. Even setting that aside, approval no longer fingerprints the full
     rendered HTML (which would have included whatever address text was
     on screen, real or redacted) -- it fingerprints only the
     contractor-controlled fields (business name, phone, notes, template
     version) via letter_content.template_fingerprint, deliberately
     independent of any address. See that function's own docstring for
     why (a full-render fingerprint would make an approval match only the
     ONE lead/address it happened to be computed against, defeating
     "reusable template approval").

The original caution here (kept for the historical record of what this
review flagged and then closed): a future approval UI must compute its
fingerprint from a real server-side render, never from whatever HTML this
gate redacted for on-screen display -- otherwise a contractor approving
while ADDRESS_RELEASE_LIVE is off could fingerprint placeholder text that
worker.promote_pending_approvals's real re-render could never match,
silently stranding every obligation in 'pending_approval' forever. The
route as built sidesteps this entirely (points 1-2 above) rather than
merely avoiding it by convention -- see main.py's own comments on
/letter-settings/approve and tests/test_letter_settings_routes.py's
TestApproveRouteAuthAndFingerprintIntegrity for the tests proving the
fingerprint is always server-computed, from the row actually stored under
the authenticated session's own contractor_email.
"""
import logging
import os
from typing import Optional

# Module-level (not per-call) on purpose -- 2026-09-18 review, Section 2
# (second pass). guarded_address_for_lead_reference/lead_address_release_
# allowed below need to open their own DB connection, and this binds
# "database" ONCE, at address_release.py's own first-import time -- the
# same moment main.py's own `import database` (main.py line ~13) runs,
# since main.py imports this module shortly after (main.py line ~23) in
# the same synchronous import chain. That makes this module's `database`
# reference and main.py's `database` reference the SAME object for the
# rest of the process.
#
# A per-call `import database` (what this used to be) re-resolves
# sys.modules["database"] fresh on every call instead -- which sounds more
# "up to date" but is actually the bug: several test files (e.g.
# test_payments_webhook.py, test_letter_promise_gate.py) deliberately
# replace sys.modules["database"] with a brand-new stub object partway
# through the test run, for their own isolation reasons. `unittest
# discover` imports every test file (running that replacement) before
# running any test, so by the time tests execute, a per-call import here
# would resolve to whichever stub was swapped in LAST -- a different
# object than the one main.database still points to, and a different
# object than whatever @patch("main.database.xxx")/@patch("database.xxx")
# in a given test actually patched. That mismatch silently made every
# route-level "enabled" test in test_address_release_gate.py fall through
# to the fail-safe (redacted/denied) branch instead of exercising the
# eligibility logic under test. Binding once, at import time, avoids the
# whole class of problem -- don't reintroduce a lazy per-call import here.
import database

logger = logging.getLogger("treekey-address-release")

ADDRESS_RELEASE_LIVE_ENV = "ADDRESS_RELEASE_LIVE"
_TRUTHY_ENV_VALUES = ("1", "true", "yes", "on")

# Deliberately generic -- never hints at what the redacted text would have
# said (no partial address, no "on X Street", nothing derived from the
# real value), and never distinguishes "this lead doesn't exist" from
# "the address is being withheld" (same 404-not-403-style caution
# require_lead_ownership already uses, applied here to content instead of
# access).
REDACTED_ADDRESS_PLACEHOLDER = (
    "Address release pending. TreeKey is finalising the legal review "
    "required before exact addresses are shown -- contact support if you "
    "believe this is blocking a job you've already paid for."
)


def address_release_live() -> bool:
    """Read fresh from the environment on every call -- no caching, no
    per-process memoisation -- matching fulfilment.letter_sending_live()'s
    established pattern so flipping this in production takes effect
    immediately without a restart. Default (unset, or any non-truthy
    value): False -- addresses stay redacted."""
    return os.getenv(ADDRESS_RELEASE_LIVE_ENV, "").strip().lower() in _TRUTHY_ENV_VALUES


def guarded_address(real_address) -> str:
    """The single chokepoint every contractor/customer-facing route must
    call immediately before putting a lead's address into a response.
    Returns `real_address` unchanged only when address_release_live() is
    True; otherwise returns the fixed placeholder, regardless of who is
    asking, whether they paid, whether funding was reserved, or whether a
    provider has accepted anything -- none of those are consulted here.

    2026-09-18 review, Section 2: kept as-is for callers with no specific
    lead to key a per-allocation decision against (e.g. letter_content's
    sample preview, which never touches a real lead at all). For any real,
    specific lead, prefer guarded_address_for_lead below -- see its own
    docstring for why a single global flag is no longer the whole
    decision for a real purchased lead."""
    if real_address and address_release_live():
        return real_address
    return REDACTED_ADDRESS_PLACEHOLDER


# ---------------------------------------------------------------------------
# 2026-09-18 review, Section 2: "Review ADDRESS_RELEASE_LIVE. Preserve
# authorised historical purchase access. For new allocations, implement and
# test eligibility at allocation/order level, with the global flag serving
# only as an additional control. Do not invent a legally sufficient release
# trigger; leave that policy configurable and explicitly unresolved."
#
# Before this section, `guarded_address` above was the ONLY decision this
# module made, and it was a single global switch applied identically to
# EVERY lead, regardless of when or how it was claimed. Two problems with
# that as the sole mechanism, once it started actually being flipped for
# real leads: (1) a contractor whose lead was claimed BEFORE this whole
# gate (and the pipeline it belongs to) existed already had that address
# legitimately shown to them -- on their dashboard, in an email already
# sent -- under whatever rules were in force at the time; retroactively
# redacting it the moment ADDRESS_RELEASE_LIVE happens to be off provides
# no protection (the disclosure already happened) and just breaks their
# access to data they already have. (2) Once the global flag IS eventually
# turned on, it would instantly release EVERY lead's address at once, with
# no way to release access more narrowly (e.g. a pilot with one contractor,
# or leads bought under a specific, reviewed sale flow) -- an all-or-
# nothing switch is a blunt instrument for what should be a considered,
# auditable, per-allocation decision.
#
# guarded_address_for_lead below fixes both: a HISTORICAL claim (resolved
# only via letter_dispatches, fulfilment.get_lead_owner's own pre-existing
# "claimed before this module existed" fallback -- see that function's
# docstring) always keeps its address, full stop, regardless of
# ADDRESS_RELEASE_LIVE or anything else. A NEW allocation (has a
# lead_allocations row -- the table this session's fulfilment pipeline
# introduced) needs BOTH an explicit, operator-recorded, per-lead
# eligibility decision (set_allocation_address_eligible -- audited, who/
# when/why) AND the global flag still being on -- the global flag is now
# an ADDITIONAL control layered on top of the per-allocation decision,
# never a substitute for one. Nothing here decides WHAT makes a specific
# allocation eligible or invents a legally sufficient trigger for that
# decision -- set_allocation_address_eligible just records that a named
# human made a call, for auditing; the actual policy for when to call it
# remains entirely with the operator, explicitly unresolved by this code.

ADDRESS_DISCLOSURE_DECISIONS_TABLE = "address_disclosure_decisions"


def init_address_release_schema(cur) -> None:
    cur.execute(f"""
        CREATE TABLE IF NOT EXISTS {ADDRESS_DISCLOSURE_DECISIONS_TABLE} (
            lead_reference TEXT PRIMARY KEY,
            eligible BOOLEAN NOT NULL,
            decided_by TEXT NOT NULL,
            note TEXT,
            decided_at TIMESTAMPTZ DEFAULT NOW()
        );
    """)


def set_allocation_address_eligible(cur, lead_reference: str, *, eligible: bool,
                                     decided_by: str, note: str = "") -> None:
    """Records an explicit, audited, per-allocation disclosure decision.
    This is a MANUAL admin action -- nothing in this codebase calls it
    automatically, and it deliberately does not validate `eligible` against
    any rule (payment, funding, time elapsed, or otherwise). `decided_by`
    and `note` exist so the decision is attributable and explainable later,
    not so this function can second-guess it. See this section's own
    module-level comment for why the actual eligibility POLICY is left
    entirely to the operator."""
    if not decided_by or not decided_by.strip():
        raise ValueError("decided_by is required -- an eligibility decision must be attributable to a named human.")
    cur.execute(f"""
        INSERT INTO {ADDRESS_DISCLOSURE_DECISIONS_TABLE} (lead_reference, eligible, decided_by, note, decided_at)
        VALUES (%s, %s, %s, %s, NOW())
        ON CONFLICT (lead_reference) DO UPDATE SET
            eligible = EXCLUDED.eligible, decided_by = EXCLUDED.decided_by,
            note = EXCLUDED.note, decided_at = NOW();
    """, (lead_reference.strip(), bool(eligible), decided_by.strip(), (note or "").strip()))


def get_allocation_address_eligible(cur, lead_reference: str) -> bool:
    """False (not eligible) when no decision has ever been recorded -- an
    allocation with no explicit decision is never treated as eligible by
    default; see set_allocation_address_eligible's docstring."""
    cur.execute(f"SELECT eligible FROM {ADDRESS_DISCLOSURE_DECISIONS_TABLE} WHERE lead_reference = %s;",
                (lead_reference.strip(),))
    row = cur.fetchone()
    return bool(row and row[0])


def _lead_allocation_kind(cur, lead_reference: str) -> Optional[bool]:
    """True: this lead has a lead_allocations row -- a NEW allocation
    (this session's fulfilment pipeline, whichever dispatch pipeline is
    actually active -- see fulfilment.py's own MIGRATION NOTES). False:
    found only via letter_dispatches -- a HISTORICAL claim, predating the
    table/gate entirely (the exact same distinction fulfilment.
    get_lead_owner already makes for ownership resolution, reused here for
    disclosure eligibility). None: found in neither -- can't be positively
    classified, so callers must fail toward the strict (new-allocation)
    path, never toward historical."""
    cur.execute("SELECT 1 FROM lead_allocations WHERE lead_reference = %s LIMIT 1;", (lead_reference,))
    if cur.fetchone():
        return True
    cur.execute("SELECT 1 FROM letter_dispatches WHERE lead_reference = %s LIMIT 1;", (lead_reference,))
    if cur.fetchone():
        return False
    return None


def is_historical_purchase(cur, lead_reference: str) -> bool:
    """True only when this lead resolves EXCLUSIVELY via the historical
    letter_dispatches fallback -- never for a new lead_allocations row,
    and never for a lead found in neither table (fails toward 'not
    historical', i.e. the stricter path)."""
    return _lead_allocation_kind(cur, lead_reference) is False


def guarded_address_for_lead(cur, lead_reference: str, real_address) -> str:
    """THE combined, per-lead disclosure decision -- see this section's own
    module-level comment for the full reasoning. Checked in this order:

      1. HISTORICAL (is_historical_purchase) -- the real address, always,
         regardless of ADDRESS_RELEASE_LIVE or any recorded eligibility
         decision. Preserves access that was already legitimately granted
         before this gate (or the new allocation pipeline) existed.
      2. NEW allocation, WITH an explicit eligible=TRUE decision recorded
         (get_allocation_address_eligible) AND address_release_live() also
         true -- the real address. Both are required; the global flag
         alone, or an eligible decision alone, is never sufficient.
      3. Everything else -- REDACTED_ADDRESS_PLACEHOLDER. Includes: a new
         allocation with no decision yet, a new allocation marked eligible
         but the global flag currently off, and a lead_reference this
         function cannot find in either table at all (fails safe, not
         toward disclosure).

    Requires an open `cur` -- callers with one already open (most routes,
    mid-request) should pass it through rather than opening a second
    connection; see main.py's call sites for the established pattern."""
    if not real_address:
        return REDACTED_ADDRESS_PLACEHOLDER
    if is_historical_purchase(cur, lead_reference):
        return real_address
    if get_allocation_address_eligible(cur, lead_reference) and address_release_live():
        return real_address
    return REDACTED_ADDRESS_PLACEHOLDER


def guarded_address_for_lead_reference(lead_reference: str, real_address) -> str:
    """Self-contained convenience wrapper around guarded_address_for_lead:
    opens and closes its own short-lived connection (same established
    pattern as database.get_dispatched_lead_address_for_contractor), for
    the common case of a caller with no cursor already open at the point
    an address is about to be interpolated into a response -- most of
    main.py's rendering call sites (see this module's own docstring for
    the list). Prefer guarded_address_for_lead directly when the caller
    already has an open cursor (e.g. a batch admin script), to avoid a
    redundant connection.

    Fails safe (redacted) on any DB error, including a lead_reference this
    function cannot find at all -- never raises out to the caller, since a
    rendering route failing to show an address should degrade to the
    placeholder, not to a 500."""
    if not real_address:
        return REDACTED_ADDRESS_PLACEHOLDER
    try:
        conn = database.get_db_conn()
        cur = conn.cursor()
        try:
            return guarded_address_for_lead(cur, lead_reference, real_address)
        finally:
            cur.close()
            conn.close()
    except Exception as e:
        logger.error(f"[AddressRelease] Could not determine allocation-level eligibility for "
                      f"{lead_reference!r} -- failing safe (redacted): {e}")
        return REDACTED_ADDRESS_PLACEHOLDER


def lead_address_release_allowed(lead_reference: str) -> bool:
    """For routes with no safe reduced version to show at all (e.g.
    generate_street_flyer, street_view_redirect -- the whole point of the
    response IS the address) -- the same three-tier decision as
    guarded_address_for_lead, as a plain yes/no, without needing a real
    address string on hand to test with. Self-contained (opens its own
    connection, same as guarded_address_for_lead_reference). Fails safe
    (False -- not allowed) on any DB error."""
    try:
        conn = database.get_db_conn()
        cur = conn.cursor()
        try:
            if is_historical_purchase(cur, lead_reference):
                return True
            return get_allocation_address_eligible(cur, lead_reference) and address_release_live()
        finally:
            cur.close()
            conn.close()
    except Exception as e:
        logger.error(f"[AddressRelease] Could not determine allocation-level eligibility for "
                      f"{lead_reference!r} -- failing safe (denied): {e}")
        return False
