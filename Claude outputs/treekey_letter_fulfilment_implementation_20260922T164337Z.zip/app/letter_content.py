"""
letter_content.py -- The ONE letter-rendering function, used by both the
contractor-facing preview and the provider submission path. Extracted from
main.py's generate_homeowner_letter (main.py:3225-3340 in the inspected
working copy), which is kept as a thin wrapper calling into here (see the
main.py diff) so the preview a contractor sees is provably the same content
that gets submitted -- not a second, potentially-diverging copy.

CONFIGURATION, NOT GUESSING (section 5): the previous version of this letter
had two different privacy-contact addresses in two different places --
main.py's letter footer said contact@treekey.co.uk, privacy_policy_draft.md
said contact@treekey.uk. This file reads ONE value,
TREEKEY_PRIVACY_CONTACT_EMAIL, and uses it everywhere the letter needs a
privacy contact. If that env var is unset, render_letter() raises rather
than guessing -- see PRIVACY_CONTACT_EMAIL_ENV below. Set it once the
correct operational address is confirmed; do not treat either historical
value as authoritative without checking which inbox is actually read.

WHAT THIS FILE DOES NOT CLAIM:
render_letter() produces a letter that INCLUDES a privacy notice section.
It does not claim, anywhere, that sending it establishes GDPR compliance --
see the "legal_status_note" constant, which is deliberately descriptive
("this letter includes..."), not a compliance assertion. Whether the
combined letter + linked privacy policy actually satisfies Article 14, and
whether the timing of disclosure is compliant, remains explicitly
unresolved -- see the corrected assessment from earlier this session and
docs/launch_checklist.md.
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from typing import Optional

PRIVACY_CONTACT_EMAIL_ENV = "TREEKEY_PRIVACY_CONTACT_EMAIL"
PRIVACY_POLICY_URL_ENV = "TREEKEY_PRIVACY_POLICY_URL"


class LetterConfigError(RuntimeError):
    """Raised when required, non-guessable configuration is missing.
    Deliberately loud -- 'missing configuration must fail safely and
    visibly' (brief, Authorisation and boundaries)."""


def init_letter_content_schema(cur) -> None:
    cur.execute("""
        CREATE TABLE IF NOT EXISTS contractor_letter_settings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            contractor_email TEXT NOT NULL UNIQUE,
            business_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            service_area_note TEXT,
            insurance_note TEXT,             -- freeform, contractor-supplied; never invented by TreeKey
            qualifications_note TEXT,        -- freeform, contractor-supplied; never invented by TreeKey
            template_version INT NOT NULL DEFAULT 1,
            approved BOOLEAN NOT NULL DEFAULT FALSE,
            approved_fingerprint TEXT,
            approved_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );
    """)


@dataclass
class ContractorLetterSettings:
    contractor_email: str
    business_name: str
    phone: str
    service_area_note: str = ""
    insurance_note: str = ""
    qualifications_note: str = ""
    template_version: int = 1
    approved: bool = False
    approved_fingerprint: Optional[str] = None

    def validate(self) -> list[str]:
        """Returns a list of problems (empty = valid). Does not invent
        anything -- a contractor who hasn't supplied insurance/qualification
        details simply gets a letter without those claims, never a
        TreeKey-fabricated one (section 5: 'Do not invent qualifications,
        insurance, approvals or testimonials')."""
        problems = []
        if not self.business_name or not self.business_name.strip():
            problems.append("business_name is required")
        if not self.phone or not self.phone.strip():
            problems.append("phone is required")
        return problems


def get_contractor_settings(cur, contractor_email: str) -> Optional[ContractorLetterSettings]:
    cur.execute("""
        SELECT contractor_email, business_name, phone, service_area_note, insurance_note,
               qualifications_note, template_version, approved, approved_fingerprint
        FROM contractor_letter_settings WHERE contractor_email = %s;
    """, (contractor_email.strip().lower(),))
    row = cur.fetchone()
    if not row:
        return None
    return ContractorLetterSettings(
        contractor_email=row[0], business_name=row[1], phone=row[2],
        service_area_note=row[3] or "", insurance_note=row[4] or "", qualifications_note=row[5] or "",
        template_version=row[6], approved=row[7], approved_fingerprint=row[8],
    )


def upsert_contractor_settings(cur, settings: ContractorLetterSettings) -> None:
    """Saving new/changed details always resets approved=FALSE -- a material
    change requires renewed approval (section 5). Approval itself is a
    separate call (approve_template) so a contractor can't approve-by-accident
    while just saving a draft."""
    problems = settings.validate()
    if problems:
        raise ValueError(f"Invalid contractor letter settings: {'; '.join(problems)}")
    cur.execute("""
        INSERT INTO contractor_letter_settings
            (contractor_email, business_name, phone, service_area_note, insurance_note, qualifications_note,
             template_version, approved, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, FALSE, NOW())
        ON CONFLICT (contractor_email) DO UPDATE SET
            business_name = EXCLUDED.business_name,
            phone = EXCLUDED.phone,
            service_area_note = EXCLUDED.service_area_note,
            insurance_note = EXCLUDED.insurance_note,
            qualifications_note = EXCLUDED.qualifications_note,
            template_version = contractor_letter_settings.template_version + 1,
            approved = FALSE,
            approved_fingerprint = NULL,
            approved_at = NULL,
            updated_at = NOW();
    """, (settings.contractor_email.strip().lower(), settings.business_name.strip(), settings.phone.strip(),
          settings.service_area_note.strip(), settings.insurance_note.strip(), settings.qualifications_note.strip(),
          settings.template_version))


def template_fingerprint(settings: ContractorLetterSettings) -> str:
    """2026-09-18 review, Section 1 (second pass -- 'reusable-template
    approval'): fingerprints ONLY the fields the contractor actually
    controls (business name, phone, service-area/insurance/qualifications
    notes, template version) -- never lead_reference/address/summary/
    council, which render_letter also bakes into the full letter HTML and
    which are different for every single lead a contractor buys.

    This is deliberately NOT the same thing as content_fingerprint(html)
    of a full render. If approval matching used the full-render
    fingerprint, an approval could only ever match the ONE specific lead
    it happened to be computed against -- making 'approve once, reuse for
    every future lead' (the whole point of a reusable template) impossible
    in practice: every subsequent obligation, having a different address/
    summary/council baked into its render, would produce a different
    fingerprint and stay stuck in pending_approval forever, regardless of
    whether the contractor's own details had changed at all. See
    worker.promote_pending_approvals, which checks eligibility against
    THIS fingerprint (while still separately rendering + freezing the real
    per-lead HTML via content_fingerprint for the actual obligation, an
    entirely separate guarantee -- see that function's own comments and
    tests/test_content_freezing.py)."""
    material = "\x1f".join([
        settings.business_name.strip(), settings.phone.strip(),
        settings.service_area_note.strip(), settings.insurance_note.strip(),
        settings.qualifications_note.strip(), str(settings.template_version),
    ])
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


# Fixed, clearly-fictional sample lead data used ONLY for the contractor-
# facing template preview/approval UI (main.py's /letter-settings/preview
# and /letter-settings/approve routes) -- contractor_letter_settings is
# per-contractor, not per-lead, so there is no real specific lead to show
# at setup time. Approving this preview approves the REUSABLE parts of the
# letter (see template_fingerprint above); a real purchased lead's actual
# letter is rendered separately, per-obligation, by
# worker.promote_pending_approvals using the real lead's own data.
PREVIEW_LEAD_REFERENCE = "SAMPLE-PREVIEW"
PREVIEW_ADDRESS = "123 Sample Street, Sample Town, ST1 2AB"
PREVIEW_SUMMARY = "Fell one silver birch and crown-reduce one oak (illustrative example only -- not a real planning application)"
PREVIEW_COUNCIL = "Sample District Council"


def render_preview_letter(settings: ContractorLetterSettings) -> str:
    """The exact same render_letter function a real send uses, against the
    fixed sample data above -- so what a contractor approves here is
    provably rendered by the same code path as a real letter, not a
    second, potentially-diverging preview template."""
    return render_letter(settings, lead_reference=PREVIEW_LEAD_REFERENCE, address=PREVIEW_ADDRESS,
                          summary=PREVIEW_SUMMARY, council=PREVIEW_COUNCIL)


def approve_template(cur, contractor_email: str, *, preview_fingerprint: str) -> None:
    """The contractor (or, in a test, whoever is asserting approval)
    confirms the exact previewed content by its fingerprint. Storing the
    fingerprint (not just an 'approved' boolean) is what lets later code
    detect drift: if the rendered content ever changes without a fresh
    approval, approved_fingerprint will no longer match, and
    obligation creation must fall back to pending_approval (see
    fulfilment.create_allocation_and_obligation's template_approved param,
    which callers compute via is_approval_current below).

    CALLER MUST PASS template_fingerprint(settings) here (computed
    server-side, from the settings row actually stored under
    contractor_email -- never a client-supplied value; see main.py's
    /letter-settings/approve route and the 'CAUTION FOR A FUTURE
    CONTRACTOR-APPROVAL UI' note in address_release.py's module
    docstring, which this route follows)."""
    cur.execute("""
        UPDATE contractor_letter_settings
        SET approved = TRUE, approved_fingerprint = %s, approved_at = NOW(), updated_at = NOW()
        WHERE contractor_email = %s RETURNING id;
    """, (preview_fingerprint, contractor_email.strip().lower()))
    if cur.fetchone() is None:
        raise LetterConfigError(f"No contractor_letter_settings row for {contractor_email!r} -- save settings before approving.")


def is_approval_current(settings: ContractorLetterSettings, current_fingerprint: str) -> bool:
    return bool(settings.approved and settings.approved_fingerprint == current_fingerprint)


def _privacy_contact_email() -> str:
    val = os.getenv(PRIVACY_CONTACT_EMAIL_ENV, "").strip()
    if not val:
        raise LetterConfigError(
            f"{PRIVACY_CONTACT_EMAIL_ENV} is not set. The letter template previously used two DIFFERENT "
            f"addresses in different places (contact@treekey.co.uk in main.py's letter, contact@treekey.uk "
            f"in privacy_policy_draft.md) -- refusing to guess which inbox is actually read. Set this "
            f"explicitly once confirmed."
        )
    return val


def _privacy_policy_url() -> str:
    return os.getenv(PRIVACY_POLICY_URL_ENV, "").strip() or "treekey.co.uk/privacy-policy"


def render_letter(settings: ContractorLetterSettings, *, lead_reference: str, address: str,
                   summary: str, council: str) -> str:
    """Pure function: same inputs always produce the same output (needed for
    fingerprinting to mean anything). No network, no DB. Raises
    LetterConfigError if required config is missing rather than silently
    substituting a guess -- see _privacy_contact_email above."""
    contact_email = _privacy_contact_email()
    policy_url = _privacy_policy_url()

    insurance_html = f'<p style="font-size:14px;">{settings.insurance_note}</p>' if settings.insurance_note.strip() else ""
    qualifications_html = f'<p style="font-size:14px;">{settings.qualifications_note}</p>' if settings.qualifications_note.strip() else ""

    return f"""<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta charset="UTF-8">
<title>Homeowner Notice Letter | {lead_reference}</title>
<style>
body {{ font-family: "Georgia", serif; padding: 40px; color: #111; max-width: 650px; margin: auto; line-height: 1.6; background: #fff; }}
.header {{ border-bottom: 2px solid #044332; padding-bottom: 15px; margin-bottom: 25px; }}
.title {{ font-size: 20px; font-weight: bold; color: #044332; }}
</style>
</head>
<body>
<div class="header">
    <div class="title">{settings.business_name}</div>
    <div style="font-size:12px; color:#666;">Tel: {settings.phone}</div>
</div>
<p style="font-size:14px;"><b>To the Property Owner / Occupier:</b><br>{address}</p>
<p style="font-size:14px;">Dear Homeowner,</p>
<p style="font-size:14px; text-align:justify;">
We are writing to introduce our local arboricultural team in relation to your recent statutory planning
notification registered with <b>{council}</b> (Application Reference: <b>{lead_reference}</b>).
</p>
<div style="background:#f8fafc; border-left:3px solid #044332; padding:12px 16px; margin:15px 0; font-size:13px;">
    <b>Proposed Arboricultural Specification:</b><br><i>"{summary}"</i>
</div>
{insurance_html}
{qualifications_html}
<p style="font-size:14px; text-align:justify;">
We would be pleased to provide a complimentary, no-obligation on-site quotation.
</p>
<div style="margin-top:30px; font-size:14px;">
Yours sincerely,<br><br><b>{settings.business_name}</b><br>Direct Line: <b>{settings.phone}</b>
</div>
<div style="margin-top:28px; padding-top:14px; border-top:1px solid #cbd5e1; font-size:10.5px; line-height:1.5; color:#64748b;">
<b>How we found your details.</b> This letter was prepared using information from your planning
application <b>{lead_reference}</b>, a public record held by {council}. TreeKey (operated by Vector Data
Labs) processed this information on the basis of its legitimate interest in connecting relevant local
contractors with published planning notices. You have the right to object to this processing, to ask what
information is held about you, or to request its removal from future matching &mdash; contact
<b>{contact_email}</b>, or see the full privacy notice at <b>{policy_url}</b>, which includes our data
retention periods and your right to complain to the ICO. Objecting to this processing does not affect this
contractor's ability to assist with your project if you choose to contact them directly, and does not
retract the postal notice already provided to you.
</div>
</body>
</html>"""


def content_fingerprint(html: str) -> str:
    return hashlib.sha256(html.encode("utf-8")).hexdigest()
