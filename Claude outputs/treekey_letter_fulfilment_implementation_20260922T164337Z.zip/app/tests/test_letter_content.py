"""
test_letter_content.py -- letter_content.py's shared render function,
template approval, and fingerprint consistency. Run with:
    python -m unittest tests.test_letter_content -v
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import letter_content


class FakeCursor:
    def __init__(self, fetchone_results=None):
        self.executed = []
        self._fetchone_results = list(fetchone_results or [])

    def execute(self, sql, params=None):
        self.executed.append((sql.strip(), params))

    def fetchone(self):
        return self._fetchone_results.pop(0) if self._fetchone_results else None


def _settings(**overrides):
    base = dict(contractor_email="contractor@example.com", business_name="Apex Tree Care",
                phone="0113 000 0000")
    base.update(overrides)
    return letter_content.ContractorLetterSettings(**base)


class TestConfigIsNeverGuessed(unittest.TestCase):
    def test_missing_privacy_contact_email_raises_loudly(self):
        """Section 5: 'Verify configuration rather than guessing which
        email address is operational.' The letter must refuse to render
        rather than pick one of the two historical, inconsistent addresses
        found this session (contact@treekey.co.uk vs contact@treekey.uk)."""
        os.environ.pop(letter_content.PRIVACY_CONTACT_EMAIL_ENV, None)
        with self.assertRaises(letter_content.LetterConfigError):
            letter_content.render_letter(_settings(), lead_reference="PLANIT-001",
                                          address="1 Test St", summary="Fell one oak", council="Leeds")

    def test_renders_once_configured(self):
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"
        html = letter_content.render_letter(_settings(), lead_reference="PLANIT-001",
                                             address="1 Test St", summary="Fell one oak", council="Leeds")
        self.assertIn("privacy@treekey.co.uk", html)
        self.assertIn("Apex Tree Care", html)


class TestNoInventedClaims(unittest.TestCase):
    def test_no_insurance_note_means_no_insurance_claim_in_output(self):
        """Section 5: 'Do not invent qualifications, insurance, approvals
        or testimonials.' A contractor who left insurance_note blank must
        get a letter with NO insurance claim, not a TreeKey-fabricated
        default like the old hardcoded '£5,000,000 Public Liability
        Insurance' line."""
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"
        html = letter_content.render_letter(_settings(insurance_note=""), lead_reference="PLANIT-001",
                                             address="1 Test St", summary="Fell one oak", council="Leeds")
        self.assertNotIn("5,000,000", html)
        self.assertNotIn("Public Liability", html)

    def test_contractor_supplied_insurance_note_is_included_verbatim(self):
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"
        html = letter_content.render_letter(
            _settings(insurance_note="Insured up to £2,000,000 (policy on request)."),
            lead_reference="PLANIT-001", address="1 Test St", summary="Fell one oak", council="Leeds")
        self.assertIn("Insured up to £2,000,000", html)


class TestFingerprintConsistency(unittest.TestCase):
    def test_same_inputs_produce_same_fingerprint(self):
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"
        html1 = letter_content.render_letter(_settings(), lead_reference="PLANIT-001",
                                              address="1 Test St", summary="Fell one oak", council="Leeds")
        html2 = letter_content.render_letter(_settings(), lead_reference="PLANIT-001",
                                              address="1 Test St", summary="Fell one oak", council="Leeds")
        self.assertEqual(letter_content.content_fingerprint(html1), letter_content.content_fingerprint(html2))

    def test_different_settings_produce_different_fingerprint(self):
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"
        html1 = letter_content.render_letter(_settings(business_name="Apex Tree Care"), lead_reference="PLANIT-001",
                                              address="1 Test St", summary="Fell one oak", council="Leeds")
        html2 = letter_content.render_letter(_settings(business_name="Different Tree Co"), lead_reference="PLANIT-001",
                                              address="1 Test St", summary="Fell one oak", council="Leeds")
        self.assertNotEqual(letter_content.content_fingerprint(html1), letter_content.content_fingerprint(html2))


class TestApprovalTracksFingerprint(unittest.TestCase):
    def test_settings_with_no_saved_row_cannot_be_approved(self):
        cur = FakeCursor(fetchone_results=[None])
        with self.assertRaises(letter_content.LetterConfigError):
            letter_content.approve_template(cur, "contractor@example.com", preview_fingerprint="abc123")

    def test_is_approval_current_true_only_when_fingerprint_matches(self):
        approved = _settings(approved=True, approved_fingerprint="abc123")
        self.assertTrue(letter_content.is_approval_current(approved, "abc123"))
        self.assertFalse(letter_content.is_approval_current(approved, "different-fingerprint"))

    def test_unapproved_settings_are_never_current(self):
        not_approved = _settings(approved=False, approved_fingerprint=None)
        self.assertFalse(letter_content.is_approval_current(not_approved, "abc123"))

    def test_saving_settings_always_resets_approval(self):
        """Section 5: a material change requires renewed approval. Asserts
        the SQL literally forces approved=FALSE on every save, so a
        contractor editing their phone number can't silently keep
        'approved' status against genuinely different content."""
        cur = FakeCursor()
        letter_content.upsert_contractor_settings(cur, _settings())
        sql, params = cur.executed[0]
        self.assertIn("approved = FALSE", sql)


class TestValidation(unittest.TestCase):
    def test_missing_business_name_is_invalid(self):
        problems = _settings(business_name="").validate()
        self.assertIn("business_name is required", problems)

    def test_missing_phone_is_invalid(self):
        problems = _settings(phone="").validate()
        self.assertIn("phone is required", problems)

    def test_upsert_raises_on_invalid_settings(self):
        cur = FakeCursor()
        with self.assertRaises(ValueError):
            letter_content.upsert_contractor_settings(cur, _settings(business_name=""))


if __name__ == "__main__":
    unittest.main()
