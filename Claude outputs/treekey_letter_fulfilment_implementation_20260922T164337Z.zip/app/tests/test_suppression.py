"""
test_suppression.py -- suppression.py's address/person matching. Run with:
    python -m unittest tests.test_suppression -v
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import suppression


class FakeCursor:
    def __init__(self, fetchone_results=None):
        self.executed = []
        self._fetchone_results = list(fetchone_results or [])

    def execute(self, sql, params=None):
        self.executed.append((sql.strip(), params))

    def fetchone(self):
        return self._fetchone_results.pop(0) if self._fetchone_results else None


class TestNormalizeAddress(unittest.TestCase):
    def test_formatting_variants_normalise_the_same(self):
        a = suppression.normalize_address("1 Test Street, Leeds, LS1 1AA")
        b = suppression.normalize_address("1  test street  leeds  ls1 1aa")
        self.assertEqual(a, b)

    def test_empty_address_is_empty_string(self):
        self.assertEqual(suppression.normalize_address(""), "")
        self.assertEqual(suppression.normalize_address(None), "")


class TestIsSuppressed(unittest.TestCase):
    def test_not_suppressed_when_no_row_matches(self):
        cur = FakeCursor(fetchone_results=[None])
        match = suppression.is_suppressed(cur, address="1 Test St, Leeds", applicant_name="J Bloggs")
        self.assertFalse(match.suppressed)

    def test_suppressed_when_row_matches(self):
        cur = FakeCursor(fetchone_results=[("row-1", "objected by letter reply", "this_person")])
        match = suppression.is_suppressed(cur, address="1 Test St, Leeds", applicant_name="J Bloggs")
        self.assertTrue(match.suppressed)
        self.assertEqual(match.reason, "objected by letter reply")

    def test_address_scope_and_person_scope_are_both_passed_to_the_query(self):
        """Section 7: 'Consider multiple applications at the same property
        without assuming all residents are the same person.' This test
        locks in that BOTH match rules are present in the query -- a
        scope='this_person' row must only match the SAME applicant_name,
        not anyone else applying at that address later."""
        cur = FakeCursor(fetchone_results=[None])
        suppression.is_suppressed(cur, address="1 Test St, Leeds", applicant_name="Different Person")
        sql, params = cur.executed[0]
        self.assertIn("this_address_anyone", sql)
        self.assertIn("this_person", sql)
        self.assertIn("different person", params)  # normalised lowercase


class TestAddSuppression(unittest.TestCase):
    def test_rejects_invalid_scope(self):
        cur = FakeCursor()
        with self.assertRaises(ValueError):
            suppression.add_suppression(cur, address="1 Test St", applicant_name="J Bloggs",
                                         reason="objected", scope="everyone_everywhere",
                                         recorded_by="admin@treekey.co.uk")

    def test_records_who_added_it(self):
        cur = FakeCursor(fetchone_results=[("row-1",)])
        row_id = suppression.add_suppression(cur, address="1 Test St", applicant_name="J Bloggs",
                                              reason="objected by email", scope="this_person",
                                              recorded_by="admin@treekey.co.uk")
        self.assertEqual(row_id, "row-1")
        self.assertIn("admin@treekey.co.uk", cur.executed[0][1])


class TestResolveSuppression(unittest.TestCase):
    def test_resolve_only_affects_unresolved_rows(self):
        cur = FakeCursor(fetchone_results=[("row-1",)])
        self.assertTrue(suppression.resolve_suppression(cur, "row-1", resolved_by="admin", note="confirmed handled"))

    def test_resolve_returns_false_when_nothing_matched(self):
        cur = FakeCursor(fetchone_results=[None])
        self.assertFalse(suppression.resolve_suppression(cur, "row-does-not-exist", resolved_by="admin", note="n/a"))


if __name__ == "__main__":
    unittest.main()
