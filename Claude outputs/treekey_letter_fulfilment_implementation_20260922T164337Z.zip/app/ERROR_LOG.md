# ERROR_LOG.md — recurring-issue and fix continuity log

## What this file is for

This is a plain, version-controlled log of every error found in this
codebase and every fix applied to it — one entry per issue, written the
moment it's found or fixed. It exists specifically as a failsafe against
an AI assistant's own memory resetting between sessions: a fresh Claude
session (or a new developer) has no memory of what was tried before, what
worked, and what didn't. This file is how that continuity survives anyway.

**This is not the same thing as `system_warnings` (the production
database table behind the Daily Warning Digest email).** That table
already tracks live scraper/lead-source warnings over time and is the
right place for automated runtime detection — it's working, and this file
doesn't replace it. What that table does NOT do is record what anyone
*did* about a warning, or track anything outside the scraper/lead-source
system (letter-fulfilment bugs, payment bugs, test-infrastructure bugs,
deploy issues, anything at all). This file is the general-purpose,
human-and-AI-readable complement: every error, anywhere in this project,
plus the fix (or the honest lack of one) — so recurring patterns and
fixes-that-didn't-actually-work become visible just by reading this file
top to bottom, without needing database access.

## Format for every new entry

Add new entries at the **top** of the "Entries" section below (most recent
first). Each entry:

```
### YYYY-MM-DD — <short title>
**Error:** <one sentence — what was actually wrong>
**Fix:** <one sentence — what was changed, OR "NOT FIXED — <why: blocked
on X, needs a decision, out of reach from this environment, etc.>">
**Where:** <file(s)/function(s) touched, or "n/a" if nothing was fixed>
```

Keep each line to one sentence. If a previous fix for the same issue
turned out not to work, say so explicitly in the new entry ("previous fix
on YYYY-MM-DD did not resolve this — see below") rather than silently
replacing the old entry — the point of this file is to make that kind of
pattern visible, not to hide it.

Any Claude session (or human) working on this codebase should add an entry
here whenever it finds a real bug or ships a real fix — this is expected
maintenance, not optional.

---

## Entries

### 2026-09-22 — No fixture format, classifier, or way to bootstrap real fixtures for the Idox scraper work (Astra's second-review fixture spec)
**Error:** following on from the entry below, the tracking layer had no companion fixture-testing infrastructure at all: no defined format for saving a real council response for later regression testing, no shared way to classify a response's shape (rate-limited vs. challenged vs. server error vs. a normal page) before deciding how to handle it, and no way to actually collect real fixtures without `mesh_scrapers.py` (still absent from this repo).
**Fix:** built `tests/fixtures/idox/` (format documented in its own `README.md` -- `body.html`/`meta.json`/`expected.json` per fixture, `provenance: captured|synthetic`, real captures never auto-promoted with a guessed `expected.json`) with 3 hand-built, clearly-labeled *synthetic* fixtures (429, 503, Cloudflare `cf-mitigated: challenge`) — never fabricated real Idox page content. Built `net_utils.classify_response()` (`PAGE_OK`/`VALID_EMPTY`/`RATE_LIMITED`/`CHALLENGED`/`AUTH_REQUIRED`/`SERVER_ERROR`/`UNRECOGNISED_PAGE`), deliberately limited to response-shape signals (status + headers) it can actually know without real Idox markup; `VALID_EMPTY` only reachable via an explicit caller-supplied hint, never inferred. Built an optional capture hook (`net_utils.smart_get/smart_post(..., capture_context=...)`) that saves real responses (body + metadata, no `expected.json`) to `captured_responses/` for later human review — off by default (no behaviour change unless a caller explicitly opts in) with an env-var kill switch (`NET_UTILS_DISABLE_CAPTURE`) as a second safeguard. 30 new tests (`tests/test_net_utils_classifier.py`, `tests/test_net_utils_capture.py`), full suite 345/345.
**Where:** `net_utils.py` (classifier + capture hook), `tests/fixtures/idox/` (new), `tests/test_net_utils_classifier.py` (new), `tests/test_net_utils_capture.py` (new).
**Scope note, stated plainly:** per Astra's own "stop there for this pass" instruction, this deliberately does NOT include LLM extraction, known-layout parser fallbacks, or a wider schema redesign. The classifier is response-shape only; nothing here can classify or parse real Idox page *content* until `mesh_scrapers.py` exists and real fixtures are captured/reviewed.

### 2026-09-22 — scraper_resilience.py's first version had a real (if narrow) race condition and three gaps Astra's second review caught
**Error:** `open_or_touch_incident`'s "no row exists" branch was SELECT-then-INSERT — two concurrent callers could both see no row and both INSERT, and the second would violate `idx_source_incident_open_unique` and be silently swallowed by the generic except (an incident-open lost, no error surfaced to a human). Also missing: no way to record a FAILED verification (an incident could sit in `verifying` forever with no trace), no count of how often the same failure recurs after being marked resolved, `council_scan_checkpoint` was keyed by council alone (one search definition's progress could overwrite another's), and its upsert had no protection against a slower concurrent scan dragging the checkpoint backwards.
**Fix:** the "no row" branch now uses an atomic `INSERT ... ON CONFLICT (council, failure_type) WHERE status != 'resolved' DO UPDATE ...`, closing that specific race (the rarer resolved-row-reopen race is left as-is, recorded as an accepted smaller gap, not silently claimed fixed). Added `record_verification_result` (failure reopens the incident and records why; success just records the outcome, doesn't force a resolution). Added `reopen_count` (incremented on every reopen). `council_scan_checkpoint` now keyed by `(council, search_definition)` with a `WHERE` guard so the upsert only advances when the new window is actually later. 27 tests passing (`tests/test_scraper_resilience.py`), migration re-synced (`migrations/0002_scraper_resilience.sql`), full suite 322/322.
**Where:** `scraper_resilience.py`, `migrations/0002_scraper_resilience.sql`, `tests/test_scraper_resilience.py`.
**Scope note:** still bookkeeping/schema only, not wired into any real scrape — same standing limitation as the entry below.

### 2026-09-22 — No tracking of whether a fix for a recurring scraper issue actually worked, and no way to recover leads missed during an outage
**Error:** the existing `system_warnings`/daily-digest infrastructure logs every warning occurrence but has no memory of what fix (if any) was tried, whether it worked, or whether a "resolved" issue later recurred — and even a same-day parser fix does nothing to recover leads already missed while a source was broken. Nick asked ChatGPT/Astra (a separate AI, prompted with the two findings directly above) for architecture advice on this; that review recommended an incident/repair-attempt lifecycle table and per-council scan checkpointing with backfill, among other things — full advice relayed into this conversation 2026-09-22, kept out of this file for length (see the conversation itself, or `docs/operator_guide.md` section 12).
**Fix:** built `scraper_resilience.py` — `source_incident`/`repair_attempt` tables with an `open → repair_attempted → verifying → resolved` lifecycle (idempotent open, reopens instead of duplicating if a resolved failure recurs, a repair attempt alone never resolves an incident), plus `council_scan_checkpoint` (per-council last-completed-window, advanced only after a fully successful pass) and `council_scan_pass_metrics` (separates "scraper is healthy" from "produced zero new leads today," which can be entirely normal). 19 tests passing (`tests/test_scraper_resilience.py`, `tests/test_migration_consistency_scraper_resilience.py`). Migration: `migrations/0002_scraper_resilience.sql`.
**Where:** `scraper_resilience.py` (new), `database.py::init_db` (Phase 1c wiring), `migrations/0002_scraper_resilience.sql`.
**Scope note, stated plainly:** this is bookkeeping/schema only — NOT wired into any real scrape yet, and cannot be, without `mesh_scrapers.py` (still absent, see the entry below). Nothing in `main.py` calls any of this yet. The advice's other recommendations (response classification before parsing, tested fallback parser strategies from real saved pages, LLM-extraction quarantine) remain correctly un-built for the same reason — see the review's own text for why guessing at those without real Idox HTML in hand would be worse than not building them.

### 2026-09-22 — `net_utils.py` asserted a specific cause for TLS certificate failures it can't actually determine
**Error:** the TLS-fallback alert's description said a portal's certificate was "likely expired, self-signed, or missing an intermediate certificate" — the same external review pointed out an `SSLError` can't actually distinguish those from a hostname mismatch, a TLS-version negotiation failure, or (not provably absent) a machine-in-the-middle, and that content fetched via this fallback is currently trusted exactly like any normal fetch with no extra scrutiny before it can become a sellable lead.
**Fix:** softened the alert text to stop asserting a specific cause. Did NOT implement quarantining fallback-fetched content — that's a real change to the lead-acceptance pipeline, which lives in `mesh_scrapers.py` (absent from this repo), so it's recorded here as an open, deliberately-deferred item rather than silently built or silently ignored.
**Where:** `net_utils.py::_alert_tls_fallback`.

### 2026-09-22 — Council health-check reported one-off network blips as "council is down"
**Error:** `_run_council_health_check` (behind `/system-health-check`) called each council's scrape function once and reported "error" on any exception, with no retry — a single transient timeout looked identical to a genuinely dead council, even though `net_utils.smart_get` already retries transient failures for every *real* scan.
**Fix:** Added one retry after a short pause before concluding a council has failed; the report now also says `attempts` and `recovered_on_retry` so a flaky-but-working council is visibly distinguished from one that failed twice. Tested in `tests/test_council_health_check_retry.py` (3 tests, passing) against a stubbed fake `mesh_scrapers` module.
**Where:** `main.py::_run_council_health_check`.
**Scope note:** this only improves the on-demand `/system-health-check` endpoint (Nick manually triggers it). It does not change the daily digest's three warning categories (TLS fallback, page structure, silent source failure) — those are generated elsewhere (`net_utils.py` and a DB query), not by this function.

### 2026-09-22 — The "auto-fix failsafe" Nick asked for was never actually built, only detection
**Error:** at least three separate verbatim asks in this codebase's own comments (`main.py` Sep 3 2026: "build failsafe auto check auto fixes... even if they have never shown an error"; `main.py` Sep 11 2026: "fail safe systems" that "put the whole thing back on track automatically"; `notifications.py` Sep 8 2026, same wording again) were each answered with detection-and-alert infrastructure only (`system_warnings` table, the daily digest, `/system-health-check`, `/lead-source-health`, `/scheduler-heartbeat`) — none of it edits a parser, retries with a different selector, or adapts to a page-layout change. Every alert's own `action_required` text says "manually check" — confirmed by reading the code directly, not assumed.
**Fix:** NOT FIXED — this file's own creation, and the retry fix directly above, are the first real steps toward the "adapts automatically" half of that ask. The actual parser-adaptation work (fallback selector chains, an LLM-extraction fallback with validation) needs `mesh_scrapers.py`, which is the next entry.
**Where:** n/a (finding, not a fix).

### 2026-09-22 — `mesh_scrapers.py` does not exist anywhere in this dev environment
**Error:** every actual Idox/Northgate/Agile Applications/Arcus scraping function, council registry, and the page-layout-change/TLS-fallback detection logic itself lives in a module called `mesh_scrapers.py`, imported dynamically throughout `main.py` (`import mesh_scrapers` inside each function that needs it) — this file is not present anywhere in this checkout (confirmed via a full filesystem search, not assumed).
**Fix:** NOT FIXED — cannot be fixed from this environment. No scraper-parsing-level change (fallback selectors, adaptive extraction, anything inside the actual Idox parser) can be written or tested here until this file is provided. Flagged directly to Nick in conversation on 2026-09-22.
**Where:** n/a — this is a blocker, not a bug in existing code.

### (Historical, found while reading `net_utils.py` — exact date not recorded, before this file existed) — A shared bot User-Agent header silently broke previously-working councils
**Error:** an earlier version of `net_utils.py`'s shared HTTP layer always built and passed an explicit `headers` dict, which (per `requests`' own session-vs-per-call header merge rules) overrode `mesh_scrapers.py`'s `IdoxScraper`'s own realistic browser User-Agent with the bot-identifying string `"TreeKeyBot/1.0"` on every single Idox request — council WAFs/bot-protection then saw obvious bot traffic. Confirmed live: Cornwall and Nottingham (previously-working councils) immediately started throwing false `SCRAPER PAGE STRUCTURE`/`SCRAPER TLS FALLBACK` alerts on their very first request after that version deployed.
**Fix:** only inject the default `TreeKeyBot/1.0` UA when neither the call's own headers nor the session's headers already set one, so `IdoxScraper`'s browser UA is left untouched — real fix already live in `net_utils.py::_request`.
**Where:** `net_utils.py::_request`. Recorded here retroactively on 2026-09-22 as a reference example: this is exactly the "recurring issue that looked like 15 unrelated council portals breaking, but was actually one bug in the shared fetch layer" pattern this file exists to make visible sooner next time.

### 2026-09-18 — Cross-module `sys.modules["database"]` identity desync silently disabled real test coverage
**Error:** under the full `unittest discover` run, test files that legitimately reassign `sys.modules["database"]` for isolation could desync any OTHER module's own earlier-bound `database` reference — `address_release.py`'s per-call lazy `import database` resolved to a stale/different object than what tests were patching, so several "enabled" tests in `test_address_release_gate.py` were silently falling through to the fail-safe path instead of exercising real logic, passing "by coincidence" rather than by actually testing anything.
**Fix:** `address_release.py` now binds `database` once at module-import time (same early, stable binding `main.py` already relies on) instead of per-call — full suite went from passing-but-not-really to 270/270 genuinely passing after the fix.
**Where:** `address_release.py`, `tests/test_address_release_gate.py`, `tests/test_migration_consistency.py`. Full detail: `docs/launch_checklist.md` item 6.

### 2026-09-18 — `ADDRESS_RELEASE_LIVE` was a single all-or-nothing flag with no way to preserve historical access
**Error:** the one flag controlled every lead's address disclosure at once — no way to keep showing addresses for leads already purchased under the old flow while deciding new allocations case-by-case.
**Fix:** three-tier eligibility — historical purchases (via `letter_dispatches`) always show the real address regardless of the flag; new allocations need an explicit per-lead operator decision (new `address_disclosure_decisions` table) *and* the flag; everything else stays redacted. No automatic eligibility rule was invented (deliberately left unresolved, per instruction).
**Where:** `address_release.py`. Full detail: `docs/launch_checklist.md` item 6.

### 2026-09-18 — The public letter-posting promise could be true with no real provider configured
**Error:** `letter_sending_live()` only checked the `LETTER_SENDING_LIVE` flag — it could report "live" even with the wrong pipeline active or no real (non-`fake_test`) provider configured/enabled.
**Fix:** now requires all three: the flag, `active_pipeline() == "fulfilment"`, and a real, enabled, configured provider — checked fresh every call, all invalid combinations tested.
**Where:** `fulfilment.py::letter_sending_live`. Full detail: `docs/launch_checklist.md` item 5.

### 2026-09-18 — A payment could be auto-refunded even while an open reconciliation issue was already being worked by a human
**Error:** a delayed Stripe webhook retry, arriving after a reservation had already expired, looked identical to "this reservation was never confirmed" and fell through to auto-refund — even if an earlier delivery of the same event had already raised an open, unresolved reconciliation record for a human to act on.
**Fix:** added a durable-identity check (`stripe_event_id` OR `stripe_reference` against unresolved `payment_allocation_reconciliation` rows), checked before the auto-refund branch; also covers the case where writing that reconciliation record itself fails (still retryable, still not marked fulfilled either way).
**Where:** `payments.py::handle_stripe_webhook`, `database.py::has_unresolved_payment_reconciliation_issue`, `fulfilment.py::has_unresolved_reconciliation_issue`. Full detail: `docs/launch_checklist.md` item 2a.

### 2026-09-22 — `FundingGate.reserve()`'s row-locking design was unverified against real PostgreSQL concurrency
**Error:** the SQL behind concurrent budget reservations (`SELECT ... FOR UPDATE`) had only ever been read, never exercised against a real Postgres server under actual concurrent transactions — `psycopg2` cannot be installed in this dev sandbox, so the real Python call path can't be driven against Postgres here at all.
**Fix:** built `tests/postgres_concurrency/run_concurrency_tests.py`, which starts a disposable local Postgres 16 server and drives the exact SQL through concurrent `psql` subprocesses instead. 5/5 scenarios passing (simultaneous workers over insufficient balance, insufficient balance from the start, transaction rollback, an unreleased "unknown" outcome, a claim race).
**Where:** `tests/postgres_concurrency/run_concurrency_tests.py`. Full detail: `docs/launch_checklist.md` item 6a.
