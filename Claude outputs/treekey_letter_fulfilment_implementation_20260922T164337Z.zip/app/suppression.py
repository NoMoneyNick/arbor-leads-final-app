"""
suppression.py -- Address/person-keyed suppression for the letter pipeline.

Deliberately separate from database.email_suppressions (database.py:426),
which is email-only and belongs to the marketing/teaser-email system. This
table exists because a postal letter has no email address to key on, and
because a suppression here must never be confused with -- or silently
control -- unrelated email marketing suppression.

Checked at three points, per the brief's section 7 ("during selection,
allocation, queue creation and immediately before submission"):
  1. is_suppressed() can be called wherever a lead is being selected/priced
     for a marketplace listing (not wired into scanners.py/marketplace
     listing in this pass -- see docs/launch_checklist.md; this module
     provides the primitive, main.py's marketplace route would need one
     call added).
  2. fulfilment.create_allocation_and_obligation does NOT itself call this
     (kept decoupled -- allocation is "who bought the lead", suppression is
     "should a letter go out"), but the letter worker (letter_providers.registry)
     checks it again right before claiming a row for submission -- so a
     suppression added AFTER queueing still blocks the send. See
     test_suppression.py's test_suppression_added_after_queueing_still_blocks.
  3. Checked a third time inside attempt_send itself, immediately before the
     provider call, closing the gap where time passed between the worker's
     claim and the actual network call.

WHAT THIS FILE DOES NOT DECIDE:
It does not decide whether unsold leads are in-scope for Article 14 notices,
and it does not create any mass-mailing of unsold records. That policy
question is explicitly left open -- see docs/launch_checklist.md. This file
only provides the mechanism to honour an objection once one exists, for
whichever leads the business ends up needing to notify.

MULTIPLE APPLICATIONS AT THE SAME ADDRESS:
Suppression is keyed on a normalised address AND, where known, the
applicant's name -- not address alone. A property with multiple owners/
occupants over time (e.g. a later planning application for the same address
made by a different person) must not be silently treated as "the same
person already objected". See match logic in is_suppressed() below and its
tests.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger("treekey-suppression")


def init_suppression_schema(cur) -> None:
    cur.execute("""
        CREATE TABLE IF NOT EXISTS postal_suppressions (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            normalized_address TEXT NOT NULL,
            applicant_name TEXT,             -- NULL = applies to the address regardless of named person
            reason TEXT NOT NULL,
            scope TEXT NOT NULL DEFAULT 'this_person',  -- 'this_person' | 'this_address_anyone'
            recorded_by TEXT NOT NULL,
            source_contact TEXT,             -- how the objection arrived (email address, phone note, etc.) -- never logged elsewhere
            created_at TIMESTAMPTZ DEFAULT NOW(),
            resolved BOOLEAN NOT NULL DEFAULT FALSE,
            resolved_by TEXT,
            resolved_at TIMESTAMPTZ,
            resolution_note TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_postal_suppressions_address ON postal_suppressions(normalized_address) WHERE resolved = FALSE;
    """)


def normalize_address(address: str) -> str:
    """Lowercase, collapse whitespace/punctuation -- good enough to catch
    the common formatting variants of the same address without a full
    postal-address-parsing dependency. Deliberately conservative: this is
    used to WIDEN a match (catch near-duplicates), never to narrow one, so
    a false positive here means 'checked an extra suppression row', not
    'missed a real suppression'."""
    if not address:
        return ""
    a = address.lower().strip()
    a = re.sub(r"[,\.]", " ", a)
    a = re.sub(r"\s+", " ", a)
    return a.strip()


@dataclass
class SuppressionMatch:
    suppressed: bool
    reason: Optional[str] = None
    scope: Optional[str] = None
    row_id: Optional[str] = None


def add_suppression(cur, *, address: str, applicant_name: Optional[str], reason: str,
                     scope: str, recorded_by: str, source_contact: Optional[str] = None) -> str:
    if scope not in ("this_person", "this_address_anyone"):
        raise ValueError("scope must be 'this_person' or 'this_address_anyone'.")
    cur.execute("""
        INSERT INTO postal_suppressions (normalized_address, applicant_name, reason, scope, recorded_by, source_contact)
        VALUES (%s, %s, %s, %s, %s, %s) RETURNING id;
    """, (normalize_address(address), (applicant_name or "").strip().lower() or None, reason, scope,
          recorded_by, source_contact))
    row_id = str(cur.fetchone()[0])
    logger.info(f"[Suppression] Added by {recorded_by}: scope={scope} address_hash_len={len(normalize_address(address))} -> {row_id}")
    return row_id


def resolve_suppression(cur, row_id: str, *, resolved_by: str, note: str) -> bool:
    cur.execute("""
        UPDATE postal_suppressions SET resolved = TRUE, resolved_by = %s, resolved_at = NOW(), resolution_note = %s
        WHERE id = %s AND resolved = FALSE RETURNING id;
    """, (resolved_by, note, row_id))
    return cur.fetchone() is not None


def is_suppressed(cur, *, address: str, applicant_name: Optional[str]) -> SuppressionMatch:
    """Two independent match rules, both active:
      - scope='this_address_anyone' rows match on address alone (the
        occupant asked TreeKey to leave the property alone regardless of
        who the applicant is).
      - scope='this_person' rows match on address AND applicant_name (a
        named person objected; a different person later applying at the
        same address is NOT suppressed by this row)."""
    norm = normalize_address(address)
    name = (applicant_name or "").strip().lower() or None

    cur.execute("""
        SELECT id, reason, scope FROM postal_suppressions
        WHERE resolved = FALSE AND normalized_address = %s
          AND (scope = 'this_address_anyone' OR (scope = 'this_person' AND applicant_name = %s))
        LIMIT 1;
    """, (norm, name))
    row = cur.fetchone()
    if row:
        return SuppressionMatch(suppressed=True, reason=row[1], scope=row[2], row_id=str(row[0]))
    return SuppressionMatch(suppressed=False)
