"""
letter_providers/registry.py -- Orders providers, health-tracks them, and is
the ONLY place that decides whether to fall back to the next provider.

Fallback rule (section 6, load-bearing -- read before changing):
  Falls back to the next provider ONLY when the current attempt's outcome is
  OUTCOME_REJECTED (a confirmed non-acceptance) or when a prior 'unknown'
  attempt has since been reconciled via check_status() into a confirmed
  rejection. It NEVER falls back on OUTCOME_UNKNOWN directly -- an unknown
  outcome stops the obligation at status='unknown' for human reconciliation,
  full stop. This is the single most important invariant in this file:
  timeouts/crashes/ambiguous responses must never cause a second provider to
  be tried for the same obligation, because the first attempt may already
  have been accepted.
"""
from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import fulfilment
import suppression
from letter_providers.base import (
    LetterProviderAdapter, LetterRequest, ProviderResult, fingerprint_content,
    OUTCOME_ACCEPTED, OUTCOME_DISPATCHED, OUTCOME_REJECTED, OUTCOME_UNKNOWN,
)

logger = logging.getLogger("treekey-provider-registry")

# How many consecutive rejections/unknowns before a provider is temporarily
# suspended from automatic selection (still selectable by an explicit admin
# override, not implemented in this pass -- see launch checklist).
DEFAULT_UNHEALTHY_THRESHOLD = 3


@dataclass
class ProviderSlot:
    adapter: LetterProviderAdapter
    enabled: bool = True
    cost_ceiling_pence: Optional[int] = None
    consecutive_failures: int = 0
    suspended: bool = False

    def record_outcome(self, outcome: str) -> None:
        if outcome in (OUTCOME_REJECTED, OUTCOME_UNKNOWN):
            self.consecutive_failures += 1
            if self.consecutive_failures >= DEFAULT_UNHEALTHY_THRESHOLD:
                self.suspended = True
                logger.warning(f"[Registry] Provider {self.adapter.name!r} suspended after "
                                f"{self.consecutive_failures} consecutive non-accept outcomes.")
        else:
            self.consecutive_failures = 0
            self.suspended = False

    def usable(self, estimated_cost_pence: Optional[int]) -> bool:
        if not self.enabled or self.suspended or not self.adapter.is_configured():
            return False
        if self.cost_ceiling_pence is not None and estimated_cost_pence is not None:
            if estimated_cost_pence > self.cost_ceiling_pence:
                return False
        return True


class ProviderRegistry:
    def __init__(self, slots: list[ProviderSlot]):
        self.slots = slots  # order = priority; first usable slot wins

    def usable_slots(self, estimated_cost_pence: Optional[int] = None):
        return [s for s in self.slots if s.usable(estimated_cost_pence)]


@dataclass
class SendOutcome:
    obligation_id: str
    final_status: str
    provider_name: Optional[str] = None
    attempts_made: int = 0
    note: str = ""


def attempt_send(cur, registry: ProviderRegistry, obligation_id: str, *, worker_id: str,
                  content_html: str, address_lines: dict, applicant_name: Optional[str],
                  lead_reference: str, idempotency_key: str, is_dry_run: bool,
                  estimated_cost_pence: Optional[int] = None) -> SendOutcome:
    """The one function that actually tries to send a letter. Call sequence:
      1. Re-check suppression (checkpoint 3 -- see suppression.py's docstring).
      2. Atomically claim the obligation (skip cleanly if already claimed).
      3. Compute + record the content fingerprint BEFORE calling any
         provider, so a retry can never silently submit different content.
      4. Walk usable providers in order; stop at the first ACCEPTED/
         DISPATCHED result, or at the first UNKNOWN result (never continue
         past an unknown -- see module docstring), or after all usable
         providers have confirmed REJECTED.
    """
    match = suppression.is_suppressed(cur, address=address_lines.get("line1", ""), applicant_name=applicant_name)
    if match.suppressed:
        fulfilment.mark_suppressed(cur, obligation_id, match.reason or "suppressed")
        return SendOutcome(obligation_id=obligation_id, final_status="suppressed",
                            note=f"Blocked at pre-submission suppression check: {match.reason}")

    if not fulfilment.claim_for_submission(cur, obligation_id, worker_id):
        return SendOutcome(obligation_id=obligation_id, final_status="skipped",
                            note="Not claimable (already claimed by another worker, or not 'ready').")

    fingerprint = fingerprint_content(content_html)

    if is_dry_run:
        fulfilment.mark_provider_result(cur, obligation_id, outcome="dry_run", is_dry_run=True,
                                         provider_name="dry_run", content_fingerprint=fingerprint)
        return SendOutcome(obligation_id=obligation_id, final_status="dry_run",
                            provider_name="dry_run", attempts_made=0,
                            note="Dry-run: no provider called, no real timestamp set.")

    request = LetterRequest(
        idempotency_key=idempotency_key, lead_reference=lead_reference, address_lines=address_lines,
        applicant_name=applicant_name, content_html=content_html, content_fingerprint=fingerprint,
    )

    attempts = 0
    for slot in registry.usable_slots(estimated_cost_pence):
        attempts += 1
        try:
            result = slot.adapter.send(request)
        except Exception as exc:
            # A raising adapter (e.g. the unimplemented Intelliprint/Postworks
            # stubs, or a real crash) is treated as UNKNOWN, never as
            # rejected -- we do not know what happened on the provider's side.
            logger.error(f"[Registry] Provider {slot.adapter.name!r} raised during send(): {exc}")
            slot.record_outcome(OUTCOME_UNKNOWN)
            fulfilment.mark_provider_result(cur, obligation_id, outcome="unknown", is_dry_run=False,
                                             provider_name=slot.adapter.name, error=str(exc),
                                             content_fingerprint=fingerprint)
            return SendOutcome(obligation_id=obligation_id, final_status="unknown",
                                provider_name=slot.adapter.name, attempts_made=attempts,
                                note="Provider raised an exception -- ambiguous, held for reconciliation, no fallback attempted.")

        slot.record_outcome(result.outcome)

        if result.outcome in (OUTCOME_ACCEPTED, OUTCOME_DISPATCHED):
            outcome_key = "accepted" if result.outcome == OUTCOME_ACCEPTED else "dispatched"
            fulfilment.mark_provider_result(cur, obligation_id, outcome=outcome_key, is_dry_run=False,
                                             provider_name=result.provider_name,
                                             provider_reference=result.provider_reference,
                                             content_fingerprint=fingerprint)
            return SendOutcome(obligation_id=obligation_id, final_status=outcome_key,
                                provider_name=result.provider_name, attempts_made=attempts,
                                note=result.message)

        if result.outcome == OUTCOME_UNKNOWN:
            fulfilment.mark_provider_result(cur, obligation_id, outcome="unknown", is_dry_run=False,
                                             provider_name=result.provider_name, error=result.message,
                                             content_fingerprint=fingerprint)
            return SendOutcome(obligation_id=obligation_id, final_status="unknown",
                                provider_name=result.provider_name, attempts_made=attempts,
                                note="Ambiguous provider response -- held for reconciliation, no automatic fallback.")

        # OUTCOME_REJECTED: confirmed non-acceptance -- the ONLY case that
        # is allowed to continue the loop and try the next provider.
        logger.info(f"[Registry] Provider {slot.adapter.name!r} confirmed rejection for {lead_reference!r}: "
                     f"{result.message} -- trying next provider if any.")
        continue

    # Every usable provider confirmed rejection (or there were none usable).
    fulfilment.mark_provider_result(cur, obligation_id, outcome="failed", is_dry_run=False,
                                     provider_name=(registry.slots[0].adapter.name if registry.slots else None),
                                     error="All usable providers confirmed rejection, or none were usable/configured.",
                                     content_fingerprint=fingerprint)
    return SendOutcome(obligation_id=obligation_id, final_status="failed", attempts_made=attempts,
                        note="No usable provider accepted this letter.")
