"""
fulfilment.py -- The one letter-fulfilment pipeline for TreeKey's bundled
lead-and-letter model: "one purchased lead includes one personalised
introduction letter printed and posted by TreeKey."

WHY THIS FILE EXISTS (read this before touching allocation code elsewhere):
Before this file, four different call sites (database.burn_lead_inventory,
database.confirm_reserved_lead_sale, database.record_lead_dispatch_and_burn,
database.redeem_free_lead_code) each called _queue_letter_dispatch directly,
and there was no single authoritative record of *who owns a claimed lead* --
the `leads` table itself has no buyer/contractor column. The only place
buyer_email was ever recorded was letter_dispatches.buyer_email, a queue
table never designed to double as an ownership registry.

This file introduces two new tables:

  lead_allocations   -- the authoritative "who owns this lead, and what
                         payment/entitlement produced that ownership" record.
                         One row per successful allocation. This is what
                         main.py's ownership checks query.

  letter_obligations -- supersedes letter_dispatches for anything allocated
                         through this module. letter_dispatches is NOT
                         touched, dropped, or migrated -- existing rows stay
                         exactly as they are (see MIGRATION NOTES below).

Both tables are created with CREATE TABLE IF NOT EXISTS, following the exact
idiom database.py already uses for every other table -- see database.py's
init_db(). Nothing here runs automatically against a live database: these
functions only execute when something explicitly calls them (init_fulfilment_schema,
or one of the allocation functions below) against a real connection, exactly
like every other function in database.py. No production migration has been
run by this work.

MIGRATION NOTES (ownership lookup over historical data):
Because lead_allocations only has rows for allocations made through this new
module, get_lead_owner() below falls back to letter_dispatches.buyer_email
(matched on lead_reference) for any lead claimed before this change shipped.
This preserves authorised access to historical purchases without requiring a
backfill migration. See docs/launch_checklist.md for the one-time backfill
that *would* let us retire that fallback later (optional, not required for
correctness).

STATE MODEL (section 4 of the brief -- separate fields, not one mega-enum):
  letter_obligations.status         -- coarse lifecycle, one of LETTER_STATUSES
  letter_obligations.is_dry_run     -- bool, independent of status
  letter_obligations.provider_accepted_at  -- set only on real provider acceptance
  letter_obligations.dispatched_at         -- set only on real dispatch confirmation
  letter_obligations.delivered_at          -- set only if a provider supplies delivery evidence
  letter_obligations.failed_at             -- confirmed rejection/failure
  letter_obligations.content_fingerprint   -- sha256 of the exact rendered letter used
  letter_obligations.idempotency_key       -- unique; stable business key for crash-safe retries

Acceptance != dispatch != delivery. A dry-run row must never get a real
dispatched_at/provider_accepted_at, and must never count toward a "sent"
total -- see mark_provider_result() below, which is the ONLY function
allowed to write those fields.
"""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger("treekey-fulfilment")


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

LETTER_STATUSES = (
    "blocked_missing_data",   # can't queue at all -- no address/reference
    "pending_approval",       # waiting on contractor template/business-detail approval
    "pending_funding",        # approved, held by the funding gate
    "ready",                  # eligible for submission, not yet attempted
    "submitting",             # a worker has claimed it and is calling a provider now
    "provider_accepted",      # provider confirmed acceptance (not yet "dispatched")
    "dispatched",             # provider confirmed the physical item left their system
    "delivered",              # only ever set if a provider gives delivery evidence
    "failed",                 # confirmed rejection/non-acceptance by the provider
    "unknown",                # ambiguous outcome (timeout/crash/malformed response) -- needs reconciliation, NOT auto-retry
    "suppressed",             # blocked by the suppression/objection registry
    "cancelled",              # administratively cancelled (e.g. refund before submission)
    "dry_run",                # completed in dry-run/test mode; never a real send
)

# Statuses from which an automatic fallback-to-next-provider or safe retry is
# allowed. Deliberately excludes "unknown" and "submitting" -- see
# providers.registry.attempt_send's docstring for why.
RETRYABLE_STATUSES = ("ready", "failed")


def init_fulfilment_schema(cur) -> None:
    """Idempotent CREATE TABLE IF NOT EXISTS block, called once from
    database.init_db() (see the one-line addition there). Never called
    automatically against a live/production database by anything in this
    session's work -- it only runs when init_db() itself runs, exactly like
    every other table in the app."""
    cur.execute("""
        CREATE TABLE IF NOT EXISTS lead_allocations (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            lead_reference TEXT NOT NULL,
            lead_id TEXT,
            buyer_email TEXT NOT NULL,
            allocation_type TEXT NOT NULL,   -- single_purchase | subscription_dispatch | free_lead | admin_grant
            source_payment_ref TEXT,         -- Stripe session/payment_intent id, subscription id, free-code, or admin note
            stripe_event_id TEXT,            -- the specific webhook event that caused this, when applicable (idempotency)
            idempotency_key TEXT NOT NULL UNIQUE,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_lead_allocations_reference ON lead_allocations(lead_reference);
        CREATE INDEX IF NOT EXISTS idx_lead_allocations_buyer ON lead_allocations(buyer_email);

        CREATE TABLE IF NOT EXISTS letter_obligations (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            allocation_id UUID REFERENCES lead_allocations(id),
            lead_reference TEXT NOT NULL,
            address TEXT NOT NULL,
            applicant_name TEXT,
            buyer_email TEXT NOT NULL,
            sale_context TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending_approval',
            is_dry_run BOOLEAN NOT NULL DEFAULT TRUE,
            content_fingerprint TEXT,
            template_version INT,
            idempotency_key TEXT NOT NULL UNIQUE,
            provider_name TEXT,
            provider_reference TEXT,
            attempts INT NOT NULL DEFAULT 0,
            last_error TEXT,
            provider_accepted_at TIMESTAMPTZ,
            dispatched_at TIMESTAMPTZ,
            delivered_at TIMESTAMPTZ,
            failed_at TIMESTAMPTZ,
            suppressed_at TIMESTAMPTZ,
            suppressed_reason TEXT,
            claimed_by_worker TEXT,          -- set atomically when a worker begins submission, cleared on completion
            claimed_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_letter_obligations_status ON letter_obligations(status);
        CREATE INDEX IF NOT EXISTS idx_letter_obligations_reference ON letter_obligations(lead_reference);

        CREATE TABLE IF NOT EXISTS payment_allocation_reconciliation (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            stripe_event_id TEXT,
            stripe_reference TEXT,
            buyer_email TEXT,
            lead_reference TEXT,
            reason TEXT NOT NULL,
            resolved BOOLEAN NOT NULL DEFAULT FALSE,
            resolved_by TEXT,
            resolved_at TIMESTAMPTZ,
            resolution_note TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_reconciliation_unresolved ON payment_allocation_reconciliation(resolved) WHERE resolved = FALSE;
    """)


# ---------------------------------------------------------------------------
# Allocation + obligation creation (the transactional core)
# ---------------------------------------------------------------------------

@dataclass
class AllocationResult:
    ok: bool
    allocation_id: Optional[str] = None
    obligation_id: Optional[str] = None
    obligation_status: Optional[str] = None
    reason: Optional[str] = None


def make_idempotency_key(*parts: str) -> str:
    """A stable, deterministic key from the parts that uniquely identify one
    allocation event -- e.g. (allocation_type, lead_reference, source_payment_ref).
    Same inputs always produce the same key, so calling the allocation
    function twice for the same real-world event (a retried webhook, a
    re-run admin action) is safe and produces exactly one row -- the second
    call hits the UNIQUE constraint and is treated as "already done", not as
    a new allocation. This mirrors standalone_mailer.mailer's request_key
    pattern (see that file's Mailer.send docstring)."""
    joined = "|".join(p.strip().lower() for p in parts if p)
    return hashlib.sha256(joined.encode()).hexdigest()[:40]


def get_lead_owner(cur, lead_reference: str) -> Optional[str]:
    """The single source of truth for 'who owns this claimed lead'. Checks
    the new authoritative table first, then falls back to
    letter_dispatches.buyer_email for leads claimed before this module
    existed (see MIGRATION NOTES at the top of this file). Returns the
    lower-cased buyer email, or None if no owner can be established --
    callers must treat None as 'deny', never as 'allow'."""
    cur.execute(
        "SELECT buyer_email FROM lead_allocations WHERE lead_reference = %s ORDER BY created_at DESC LIMIT 1;",
        (lead_reference,),
    )
    row = cur.fetchone()
    if row and row[0]:
        return row[0].strip().lower()

    # Historical fallback -- see MIGRATION NOTES.
    cur.execute(
        "SELECT buyer_email FROM letter_dispatches WHERE lead_reference = %s AND buyer_email IS NOT NULL "
        "ORDER BY created_at ASC LIMIT 1;",
        (lead_reference,),
    )
    row = cur.fetchone()
    if row and row[0]:
        return row[0].strip().lower()
    return None


def create_allocation_and_obligation(
    cur,
    *,
    lead_reference: str,
    lead_id: Optional[str],
    address: Optional[str],
    applicant_name: Optional[str],
    buyer_email: str,
    allocation_type: str,
    sale_context: str,
    source_payment_ref: Optional[str],
    stripe_event_id: Optional[str] = None,
    template_approved: bool = False,
    template_version: Optional[int] = None,
) -> AllocationResult:
    """The one place a new allocation + its letter obligation get created.
    Call this on the SAME cursor/transaction as the sale itself, before the
    caller's own conn.commit() -- exactly the discipline database.py's
    existing _queue_letter_dispatch already documents (database.py:5303-5306)
    and this function preserves.

    Idempotent: if idempotency_key already exists, returns the EXISTING
    allocation/obligation instead of raising or duplicating -- this is what
    makes "handle repeat and out-of-order Stripe events without duplicate
    allocations" (section 2) actually true, not just documented.

    Missing address/reference produces a 'blocked_missing_data' obligation
    row (loud, queryable, admin-visible) instead of _queue_letter_dispatch's
    current behaviour of only logging and returning nothing durable."""
    idem_key = make_idempotency_key(allocation_type, lead_reference, source_payment_ref or buyer_email)

    cur.execute("SELECT id FROM lead_allocations WHERE idempotency_key = %s;", (idem_key,))
    existing = cur.fetchone()
    if existing:
        cur.execute(
            "SELECT id, status FROM letter_obligations WHERE allocation_id = %s LIMIT 1;",
            (existing[0],),
        )
        ob = cur.fetchone()
        logger.info(f"[Fulfilment] Allocation for {lead_reference!r} ({allocation_type}) already exists "
                    f"(idempotency_key={idem_key}) -- returning existing record, not duplicating.")
        return AllocationResult(
            ok=True, allocation_id=str(existing[0]),
            obligation_id=str(ob[0]) if ob else None,
            obligation_status=ob[1] if ob else None,
            reason="already_allocated",
        )

    cur.execute("""
        INSERT INTO lead_allocations (lead_reference, lead_id, buyer_email, allocation_type,
                                       source_payment_ref, stripe_event_id, idempotency_key)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        RETURNING id;
    """, (lead_reference, lead_id, buyer_email.strip().lower(), allocation_type,
          source_payment_ref, stripe_event_id, idem_key))
    allocation_id = cur.fetchone()[0]

    if not address or not lead_reference:
        # Loud AND durable: an admin can query letter_obligations for
        # status='blocked_missing_data' -- this is what "actionable
        # blocked/error state, not an apparently completed sale with only a
        # log message" (section 2) means in practice.
        logger.error(f"[Fulfilment] Allocation {allocation_id} for reference={lead_reference!r} has no "
                      f"address -- creating a BLOCKED letter obligation for manual follow-up.")
        obligation_status = "blocked_missing_data"
    elif template_approved:
        obligation_status = "pending_funding"
    else:
        obligation_status = "pending_approval"

    ob_idem_key = make_idempotency_key("obligation", allocation_type, lead_reference, source_payment_ref or buyer_email)
    cur.execute("""
        INSERT INTO letter_obligations (allocation_id, lead_reference, address, applicant_name, buyer_email,
                                         sale_context, status, template_version, idempotency_key)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id;
    """, (allocation_id, lead_reference, address or "", applicant_name, buyer_email.strip().lower(),
          sale_context, obligation_status, template_version, ob_idem_key))
    obligation_id = cur.fetchone()[0]

    return AllocationResult(ok=True, allocation_id=str(allocation_id), obligation_id=str(obligation_id),
                             obligation_status=obligation_status)


def record_reconciliation_issue(cur, *, reason: str, stripe_event_id: Optional[str] = None,
                                 stripe_reference: Optional[str] = None, buyer_email: Optional[str] = None,
                                 lead_reference: Optional[str] = None) -> str:
    """Stripe charged, but local allocation failed (DB error, app crash,
    whatever). This is the durable, admin-visible record of that gap --
    section 2's 'do not automatically charge again' means this is the ONLY
    thing that happens automatically; a human resolves it via
    resolve_reconciliation_issue below."""
    cur.execute("""
        INSERT INTO payment_allocation_reconciliation (stripe_event_id, stripe_reference, buyer_email, lead_reference, reason)
        VALUES (%s, %s, %s, %s, %s) RETURNING id;
    """, (stripe_event_id, stripe_reference, buyer_email, lead_reference, reason))
    issue_id = str(cur.fetchone()[0])
    logger.error(f"[Fulfilment] RECONCILIATION NEEDED ({issue_id}): {reason} "
                 f"(stripe_event={stripe_event_id}, buyer={buyer_email}, lead={lead_reference})")
    return issue_id


def resolve_reconciliation_issue(cur, issue_id: str, *, resolved_by: str, note: str) -> bool:
    cur.execute("""
        UPDATE payment_allocation_reconciliation
        SET resolved = TRUE, resolved_by = %s, resolved_at = NOW(), resolution_note = %s
        WHERE id = %s AND resolved = FALSE
        RETURNING id;
    """, (resolved_by, note, issue_id))
    return cur.fetchone() is not None


# ---------------------------------------------------------------------------
# Provider-result recording -- the ONLY functions allowed to move an
# obligation between submitting/accepted/dispatched/failed/unknown, and the
# only place dry-run vs real outcomes are told apart.
# ---------------------------------------------------------------------------

def claim_for_submission(cur, obligation_id: str, worker_id: str) -> bool:
    """Atomic claim: only succeeds if the row is 'ready' and not already
    claimed. This is what section 6's 'atomic worker claims' means --
    replaces the old process_pending_letter_dispatches' unprotected SELECT.
    Returns False if another worker already has it (or it isn't ready),
    which the caller must treat as 'skip, not an error'."""
    cur.execute("""
        UPDATE letter_obligations
        SET status = 'submitting', claimed_by_worker = %s, claimed_at = NOW(), updated_at = NOW()
        WHERE id = %s AND status = 'ready'
        RETURNING id;
    """, (worker_id, obligation_id))
    return cur.fetchone() is not None


def mark_provider_result(cur, obligation_id: str, *, outcome: str, is_dry_run: bool,
                          provider_name: Optional[str] = None, provider_reference: Optional[str] = None,
                          error: Optional[str] = None, content_fingerprint: Optional[str] = None) -> None:
    """outcome is one of: 'accepted', 'dispatched', 'failed', 'unknown', 'dry_run'.
    This function is deliberately the ONLY writer of provider_accepted_at /
    dispatched_at / delivered_at, and it is the only place that decides
    whether a real timestamp gets set -- is_dry_run=True NEVER sets
    provider_accepted_at or dispatched_at, regardless of what outcome says,
    closing the exact gap in the old process_pending_letter_dispatches
    (database.py:5381-5388) where a dry-run 'ok=True' result set a real
    sent_at and incremented a 'sent' counter."""
    if outcome not in ("accepted", "dispatched", "failed", "unknown", "dry_run"):
        raise ValueError(f"Unknown outcome {outcome!r}")

    fields = {"attempts": "attempts + 1", "updated_at": "NOW()"}
    params = []
    sets = ["attempts = attempts + 1", "updated_at = NOW()", "provider_name = %s", "provider_reference = %s",
            "last_error = %s"]
    params.extend([provider_name, provider_reference, error])

    if content_fingerprint:
        sets.append("content_fingerprint = %s")
        params.append(content_fingerprint)

    if is_dry_run:
        sets.append("status = 'dry_run'")
        sets.append("is_dry_run = TRUE")
    elif outcome == "accepted":
        sets += ["status = 'provider_accepted'", "provider_accepted_at = NOW()"]
    elif outcome == "dispatched":
        sets += ["status = 'dispatched'", "dispatched_at = NOW()"]
    elif outcome == "failed":
        sets += ["status = 'failed'", "failed_at = NOW()"]
    elif outcome == "unknown":
        # Deliberately does NOT flip back to 'ready'. An unknown outcome
        # must be reconciled by a human/admin action, never auto-retried --
        # see letter_providers.registry for the enforcement of this.
        sets.append("status = 'unknown'")

    sql = f"UPDATE letter_obligations SET {', '.join(sets)} WHERE id = %s;"
    params.append(obligation_id)
    cur.execute(sql, params)


def mark_suppressed(cur, obligation_id: str, reason: str) -> None:
    cur.execute("""
        UPDATE letter_obligations
        SET status = 'suppressed', suppressed_at = NOW(), suppressed_reason = %s, updated_at = NOW()
        WHERE id = %s;
    """, (reason, obligation_id))


def mark_cancelled(cur, obligation_id: str, reason: str) -> bool:
    """Section 3: 'a refund does not automatically cancel a letter already
    submitted.' Only cancellable from states that haven't reached the
    provider yet."""
    cur.execute("""
        UPDATE letter_obligations
        SET status = 'cancelled', last_error = %s, updated_at = NOW()
        WHERE id = %s AND status IN ('pending_approval', 'pending_funding', 'ready', 'blocked_missing_data')
        RETURNING id;
    """, (reason, obligation_id))
    return cur.fetchone() is not None
