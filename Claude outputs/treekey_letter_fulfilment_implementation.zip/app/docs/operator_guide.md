# TreeKey letter-fulfilment: operator guide

This covers the system built this session (2026-09-18): the pipeline that
turns "a lead was purchased" into "a personalised introduction letter is
printed and posted to the homeowner". It assumes you're an admin/operator,
not a developer -- for the code-level design, read fulfilment.py's,
worker.py's, and letter_providers/registry.py's module docstrings, which
this guide summarises and cross-references rather than duplicates.

**Nothing described here is live.** No production migration has been run,
no provider has real credentials, and no code in this session's work calls
this pipeline from a scheduler or cron job. This guide describes how to
operate it once those decisions are made -- see
[`launch_checklist.md`](launch_checklist.md) for exactly what's still
outstanding.

## 1. The lifecycle, in plain terms

Every purchased/dispatched/free-granted lead gets one row in
`letter_obligations`, moving through these states in order:

1. **`blocked_missing_data`** -- the lead had no address on file. Dead end;
   needs manual investigation (why did a lead with no address get sold?).
2. **`pending_approval`** -- waiting for the buying contractor to have
   approved their current letter content (business name, phone, insurance
   note) via `letter_content.approve_template`. Nothing moves past this
   without a genuine, current approval -- editing settings after approving
   resets `approved=FALSE` and drops any obligation still at this stage
   back to needing re-approval.
3. **`pending_funding`** -- template approved, waiting on the funding gate
   (see section 2).
4. **`ready`** -- eligible for submission. Not yet attempted.
5. **`submitting`** -- a worker has atomically claimed it and is (or, in
   dry-run, is pretending to be) calling a provider right now.
6. Terminal states: **`provider_accepted`**, **`dispatched`**,
   **`delivered`** (real success, in increasing order of confirmation),
   **`failed`** (every usable provider confirmed rejection), **`unknown`**
   (ambiguous -- see section 4, the most important one to understand),
   **`suppressed`** (blocked by an objection), **`cancelled`** (refund
   before submission), **`dry_run`** (completed in test mode, never a real
   send).

Query `letter_obligations` directly (`SELECT status, COUNT(*) FROM
letter_obligations GROUP BY status;`) to see where everything sits. There
is no admin UI for this yet -- see the launch checklist.

## 2. The funding gate (`funding.py`)

Controls whether any obligation can move from `pending_funding` to `ready`.
Set via the `FUNDING_MODE` environment variable (see
`.env.example.letter-fulfilment`):

- **`hold`** (default): nothing is eligible until an admin has run
  `FundingGate.confirm_budget(cur, amount_pence=..., confirmed_by=...,
  note=...)` -- there is currently no admin UI for this either; it must be
  called from a Python shell/admin script against the real database.
  Recommended starting mode.
- **`simulate`**: for local testing. `FundingGate.simulate_budget(pence)`
  sets an in-process budget that's never written to the database. Resets
  every time the process restarts.
- **`working_capital`**: always eligible, no confirmation needed at all.
  Not recommended without a real reconciliation process behind it -- this
  is "spend now, reconcile against the bank later."

`gate.spend(cur, pence)` debits the oldest active budget confirmation
first. **Nothing in this session's work calls `spend()` automatically** --
no code path currently decrements a budget after a real send. Wiring that
up (spend on confirmed acceptance, not on `ready`) is outstanding -- see
the launch checklist.

## 3. Suppression (`suppression.py`)

A homeowner who's objected (by any channel -- letter reply, email, phone)
gets a row in `postal_suppressions`, added via `suppression.add_suppression`.
Two scopes:

- **`this_person`**: blocks only that named applicant at that address.
- **`this_address_anyone`**: blocks the address regardless of who applies
  next (use when the objection was clearly about the property, not one
  individual -- e.g. "stop sending planning-related mail to this house").

Checked automatically at send time (`letter_providers.registry.attempt_send`,
step 1, before the obligation is even claimed) -- no manual step needed
once a suppression row exists. **There is no admin UI to add a suppression
row yet** -- this must be done via direct DB access or a small admin
script. Building that UI is outstanding work, not something this session
implemented (Section 7 of the original brief asked for the mechanism, not
a full admin surface).

## 4. `unknown` outcomes -- read this before touching anything

An obligation lands in `status = 'unknown'` when a provider's response was
genuinely ambiguous: a timeout, a crash mid-request, a malformed response,
or any exception raised by the adapter. **This is deliberately a dead end,
not a retry queue.** `worker.run_batch` only ever selects `status =
'ready'` rows -- an `unknown` row is never picked up again automatically,
and `letter_providers.registry.attempt_send` never falls back to a second
provider after an unknown outcome (see that function's own module
docstring for exactly why: the first attempt may already have been
accepted, and trying a second provider risks a duplicate physical letter).

**Handling an `unknown` row is a manual, human decision**: check the
provider's own dashboard/support channel for what actually happened to
that specific submission (`provider_reference` may or may not be populated
-- it often isn't, for a genuinely unknown outcome), then either:
- confirm it was actually accepted -- manually update the row's status and
  `provider_accepted_at`/`dispatched_at` to match reality, or
- confirm it was never received -- manually reset it to `ready` (or
  `pending_funding` if you want the gate re-checked) so the worker will
  retry it, or
- give up and mark it `cancelled` with a note explaining why.

There is currently no tooling to do this other than direct SQL -- an admin
reconciliation screen for `unknown` and `blocked_missing_data` rows is
outstanding work (see launch checklist).

## 5. Running the pipeline manually (no scheduler is wired up)

```python
import database, worker, funding
from letter_providers.registry import ProviderRegistry, ProviderSlot
from letter_providers.fake_provider import FakeLetterProvider

conn = database.get_db_conn()
cur = conn.cursor()

# Step 1: promote anything whose contractor has approved their template.
report = worker.promote_pending_approvals(cur)
print(report)  # PromotionReport(checked=.., promoted_to_pending_funding=.., ...)

# Step 2: promote anything the funding gate says is eligible.
gate = funding.FundingGate()  # reads FUNDING_MODE from env
report = worker.promote_pending_funding(cur, gate, estimated_cost_pence=95)
print(report)

# Step 3: attempt to send (or dry-run) whatever's now 'ready'.
registry = ProviderRegistry([ProviderSlot(adapter=FakeLetterProvider())])  # swap for real providers when ready
outcomes = worker.run_batch(cur, registry, worker_id="manual-run-1", is_dry_run=True)
for o in outcomes:
    print(o)

conn.commit()
cur.close(); conn.close()
```

Run this on a schedule (cron, a background worker process, whatever your
deployment platform supports) once you've decided on a cadence -- see the
launch checklist for why this session didn't pick one for you.

## 6. Known limitation: unstructured addresses

`leads.address` is one free-text field, not
line1/city/postcode/country. `worker.run_batch` currently passes the whole
string as `address_lines['line1']` and leaves the rest blank. A real
postal provider integration will very likely need proper address
components -- either an address-parsing step before submission, or
capturing structured fields earlier, at planning-data ingestion. Not solved
in this session's work; flagged in the launch checklist.
