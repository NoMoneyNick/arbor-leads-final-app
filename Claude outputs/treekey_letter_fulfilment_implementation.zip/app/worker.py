"""
worker.py -- turns letter_obligations rows into actual (or dry-run) provider
attempts. This is the piece connecting fulfilment.create_allocation_and_obligation
(which creates a 'pending_approval' / 'pending_funding' / 'blocked_missing_data'
row at sale time -- see database.py's four allocation call sites) to
letter_providers.registry.attempt_send (which sends/dry-runs a single
already-'ready' obligation -- see that function's own docstring for the
fallback/unknown-outcome rules).

Three responsibilities, kept as separate functions so each can be tested,
scheduled, and reasoned about independently:

  promote_pending_approvals -- pending_approval -> pending_funding, only
    when the CURRENT contractor_letter_settings for the obligation's buyer
    are approved AND re-rendering the letter right now produces the exact
    fingerprint that was approved (section 5: "a material change requires
    renewed approval"). Re-checked at promotion time, not trusted from
    obligation-creation time -- a contractor editing their settings after a
    sale but before their letter is promoted cannot result in stale,
    unapproved content moving forward. An obligation that cannot be
    positively confirmed (no settings saved yet, lead row missing,
    fingerprint mismatch) is left exactly where it is; nothing here ever
    promotes on absence of information.

  promote_pending_funding -- pending_funding -> ready, gated by the funding
    gate (funding.py; default mode 'hold' -- see that file's docstring).
    Checked once per obligation, not once for the whole batch, so a
    partially funded budget promotes only as many obligations as it can
    actually cover rather than either over-promoting or blocking the whole
    batch on one insufficiently funded obligation.

  run_batch -- claims and attempts to send a batch of already-'ready'
    obligations via letter_providers.registry.attempt_send. This is the
    only function in this file that can result in a real provider call, and
    only when both (a) is_dry_run=False is explicitly passed, AND (b) the
    registry passed in contains a provider slot whose is_configured() is
    True. Neither is true by default in this codebase: no caller in this
    session's work passes is_dry_run=False, and none of the shipped
    provider adapters (fake/Stannp/Intelliprint/Postworks) read real
    credentials unless an operator explicitly sets them -- see
    docs/operator_guide.md.

KNOWN GAP, DELIBERATELY NOT PAPERED OVER: `leads.address` is a single
free-text field (e.g. "14 Elm Grove, Leeds, LS6 3AB"), not structured
line1/city/postcode/country components. run_batch below passes the whole
string as address_lines['line1'] and leaves city/postcode blank rather than
guessing a parse -- a real postal provider integration will likely need a
proper address-parsing step (or capturing structured fields at the planning-
data ingestion stage) before any real letter is submitted. Flagged in
docs/launch_checklist.md; not solved here.

Nothing in this file is wired to a scheduler, cron job, or FastAPI route --
see docs/handoff.md's "remaining decisions" list for what operating this in
production would require (a process supervisor or polling loop, a chosen
interval, alerting on 'unknown'/'blocked_missing_data' rows accumulating).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import fulfilment
import letter_content
import funding as funding_module
from letter_providers.registry import ProviderRegistry, attempt_send, SendOutcome

logger = logging.getLogger("treekey-fulfilment-worker")


@dataclass
class PromotionReport:
    checked: int = 0
    promoted_to_pending_funding: int = 0
    promoted_to_ready: int = 0
    left_pending_approval: int = 0
    left_pending_funding_ineligible: int = 0
    errors: int = 0


def _fetch_lead_content_fields(cur, lead_reference: str):
    """Returns (summary, council) for re-rendering, or (None, None) if the
    lead row can't be found -- callers must treat that as 'cannot verify,
    do not promote/send', never as empty strings standing in for real data."""
    cur.execute("SELECT summary, council_source FROM leads WHERE reference = %s;", (lead_reference,))
    row = cur.fetchone()
    if not row:
        return None, None
    return row[0], row[1]


def promote_pending_approvals(cur, batch_limit: int = 100) -> PromotionReport:
    report = PromotionReport()
    cur.execute("""
        SELECT id, lead_reference, address, applicant_name, buyer_email
        FROM letter_obligations WHERE status = 'pending_approval'
        ORDER BY created_at ASC LIMIT %s;
    """, (batch_limit,))
    rows = cur.fetchall()
    for obligation_id, lead_reference, address, applicant_name, buyer_email in rows:
        report.checked += 1
        try:
            settings = letter_content.get_contractor_settings(cur, buyer_email)
            if not settings or not settings.approved:
                report.left_pending_approval += 1
                continue
            summary, council = _fetch_lead_content_fields(cur, lead_reference)
            if summary is None:
                report.left_pending_approval += 1
                continue
            html = letter_content.render_letter(settings, lead_reference=lead_reference,
                                                  address=address, summary=summary, council=council)
            fingerprint = letter_content.content_fingerprint(html)
            if not letter_content.is_approval_current(settings, fingerprint):
                # Settings or the underlying lead content have drifted since
                # the contractor last approved -- correctly stays in
                # pending_approval (they need to re-preview and re-approve),
                # never silently promoted on stale consent.
                report.left_pending_approval += 1
                continue
            cur.execute("""
                UPDATE letter_obligations SET status = 'pending_funding', content_fingerprint = %s, updated_at = NOW()
                WHERE id = %s AND status = 'pending_approval' RETURNING id;
            """, (fingerprint, obligation_id))
            if cur.fetchone() is not None:
                report.promoted_to_pending_funding += 1
            else:
                report.left_pending_approval += 1
        except letter_content.LetterConfigError as e:
            logger.error(f"[Worker] Cannot re-render obligation {obligation_id} for approval check "
                         f"(configuration incomplete): {e}")
            report.errors += 1
    return report


def promote_pending_funding(cur, gate: funding_module.FundingGate, *, estimated_cost_pence: int,
                             batch_limit: int = 100) -> PromotionReport:
    report = PromotionReport()
    cur.execute("""
        SELECT id FROM letter_obligations WHERE status = 'pending_funding'
        ORDER BY created_at ASC LIMIT %s;
    """, (batch_limit,))
    rows = cur.fetchall()
    for row in rows:
        obligation_id = row[0]
        report.checked += 1
        decision = gate.check(cur, estimated_cost_pence=estimated_cost_pence)
        if not decision.eligible:
            report.left_pending_funding_ineligible += 1
            continue
        cur.execute("""
            UPDATE letter_obligations SET status = 'ready', updated_at = NOW()
            WHERE id = %s AND status = 'pending_funding' RETURNING id;
        """, (obligation_id,))
        if cur.fetchone() is not None:
            report.promoted_to_ready += 1
        else:
            report.left_pending_funding_ineligible += 1
    return report


def run_batch(cur, registry: ProviderRegistry, *, worker_id: str, is_dry_run: bool = True,
              batch_limit: int = 25, estimated_cost_pence: Optional[int] = None) -> list:
    """Returns the list of SendOutcome results actually produced (skipped-
    before-claim cases -- unrenderable content, missing settings/lead --
    are logged loudly and excluded from the returned list rather than
    silently retried, since retrying an obligation this function couldn't
    even render would just fail identically every time)."""
    cur.execute(
        "SELECT id, lead_reference, address, applicant_name, buyer_email, idempotency_key "
        "FROM letter_obligations WHERE status = 'ready' ORDER BY created_at ASC LIMIT %s;",
        (batch_limit,),
    )
    rows = cur.fetchall()
    outcomes: list[SendOutcome] = []
    for obligation_id, lead_reference, address, applicant_name, buyer_email, idem_key in rows:
        settings = letter_content.get_contractor_settings(cur, buyer_email)
        if not settings:
            logger.error(f"[Worker] Obligation {obligation_id} reached 'ready' with no contractor_letter_settings "
                         f"row for {buyer_email!r} -- skipping rather than sending unrenderable content.")
            continue
        summary, council = _fetch_lead_content_fields(cur, lead_reference)
        if summary is None:
            logger.error(f"[Worker] Obligation {obligation_id}: lead {lead_reference!r} not found -- skipping.")
            continue
        try:
            html = letter_content.render_letter(settings, lead_reference=lead_reference, address=address,
                                                  summary=summary, council=council)
        except letter_content.LetterConfigError as e:
            logger.error(f"[Worker] Obligation {obligation_id}: cannot render letter ({e}) -- skipping.")
            continue

        outcome = attempt_send(
            cur, registry, obligation_id, worker_id=worker_id, content_html=html,
            # See module docstring's "KNOWN GAP" note -- address is not
            # structured at the source, so only line1 is populated here.
            address_lines={"line1": address, "city": "", "postcode": "", "country": "GB"},
            applicant_name=applicant_name, lead_reference=lead_reference, idempotency_key=idem_key,
            is_dry_run=is_dry_run, estimated_cost_pence=estimated_cost_pence,
        )
        outcomes.append(outcome)
    return outcomes
