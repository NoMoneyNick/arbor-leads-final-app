"""
test_funding.py -- funding.py's FundingGate. Run with:
    python -m unittest tests.test_funding -v
"""
import os
import sys
import unittest
from unittest.mock import MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import funding


class FakeCursor:
    def __init__(self, fetchone_results=None, fetchall_results=None):
        self.executed = []
        self._fetchone_results = list(fetchone_results or [])
        self._fetchall_results = list(fetchall_results or [])

    def execute(self, sql, params=None):
        self.executed.append((sql.strip(), params))

    def fetchone(self):
        return self._fetchone_results.pop(0) if self._fetchone_results else None

    def fetchall(self):
        return self._fetchall_results.pop(0) if self._fetchall_results else []


class TestDefaultMode(unittest.TestCase):
    def test_default_mode_is_hold(self):
        os.environ.pop("FUNDING_MODE", None)
        gate = funding.FundingGate()
        self.assertEqual(gate.mode, "hold")

    def test_unknown_mode_falls_back_to_hold(self):
        gate = funding.FundingGate(mode="please_just_send_it")
        self.assertEqual(gate.mode, "hold")

    def test_hold_mode_with_no_confirmed_budget_is_not_eligible(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(fetchone_results=[(0,)])
        decision = gate.check(cur, estimated_cost_pence=50)
        self.assertFalse(decision.eligible)

    def test_hold_mode_with_sufficient_confirmed_budget_is_eligible(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(fetchone_results=[(5000,)])
        decision = gate.check(cur, estimated_cost_pence=50)
        self.assertTrue(decision.eligible)
        self.assertEqual(decision.available_pence, 5000)


class TestSimulateMode(unittest.TestCase):
    def test_simulate_mode_fails_safe_if_never_configured(self):
        gate = funding.FundingGate(mode="simulate")
        cur = FakeCursor()
        decision = gate.check(cur, estimated_cost_pence=50)
        self.assertFalse(decision.eligible)

    def test_simulate_mode_respects_configured_budget(self):
        gate = funding.FundingGate(mode="simulate")
        gate.simulate_budget(1000)
        cur = FakeCursor()
        self.assertTrue(gate.check(cur, estimated_cost_pence=50).eligible)
        self.assertFalse(gate.check(cur, estimated_cost_pence=5000).eligible)

    def test_simulate_budget_rejected_outside_simulate_mode(self):
        gate = funding.FundingGate(mode="hold")
        with self.assertRaises(RuntimeError):
            gate.simulate_budget(1000)


class TestWorkingCapitalMode(unittest.TestCase):
    def test_working_capital_mode_is_always_eligible_but_must_be_explicit(self):
        gate = funding.FundingGate(mode="working_capital")
        cur = FakeCursor()
        self.assertTrue(gate.check(cur, estimated_cost_pence=50).eligible)

    def test_working_capital_is_not_the_default(self):
        os.environ.pop("FUNDING_MODE", None)
        gate = funding.FundingGate()
        self.assertNotEqual(gate.mode, "working_capital")


class TestConfirmBudget(unittest.TestCase):
    def test_confirm_budget_writes_a_row_and_returns_id(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(fetchone_results=[("budget-uuid-1",)])
        budget_id = gate.confirm_budget(cur, amount_pence=10000, confirmed_by="admin@treekey.co.uk",
                                         note="Bank balance checked 18 Sep")
        self.assertEqual(budget_id, "budget-uuid-1")
        self.assertIn("INSERT INTO mailing_budget_confirmations", cur.executed[0][0])

    def test_confirm_budget_rejects_non_positive_amounts(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor()
        with self.assertRaises(ValueError):
            gate.confirm_budget(cur, amount_pence=0, confirmed_by="admin@treekey.co.uk", note="oops")


class TestSpend(unittest.TestCase):
    def test_spend_debits_oldest_budget_first(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(fetchall_results=[[("budget-1", 1000, 900), ("budget-2", 1000, 0)]])
        gate.spend(cur, 150)
        updates = [e for e in cur.executed if e[0].startswith("UPDATE")]
        # First budget only has 100 headroom (1000-900) -- expect it topped
        # up by 100, then the remaining 50 taken from budget-2.
        self.assertEqual(updates[0][1], (100, "budget-1"))
        self.assertEqual(updates[1][1], (50, "budget-2"))


if __name__ == "__main__":
    unittest.main()
