"""
test_reconciliation.py -- Section 9's three failure-case tests not covered
by test_fulfilment.py/test_worker.py/test_providers.py, because these need
to be driven through database.py's actual allocation call sites (not
fulfilment.py in isolation) to prove the WHOLE transaction behaves
correctly, not just the fulfilment half of it:

  1. Successful payment, then a database failure while recording the
     allocation -- must roll back the ENTIRE sale (lead stays unclaimed),
     not leave a lead marked 'claimed'/'reserved-gone' with no allocation
     record and a customer who was charged.
  2. Subscription quota interaction -- a dispatch that creates an
     allocation+obligation but is then rejected by the quota-enforcing
     UPDATE (delivered_this_month < monthly_quota) must roll back that
     allocation too, not leave an orphaned allocation for a lead that was
     actually released back to the pool.
  3. Migration compatibility -- the new fulfilment pipeline must never read
     or requeue rows from the pre-existing letter_dispatches table (which
     may contain historically dry-run-marked rows from the OLD
     process_pending_letter_dispatches bug -- see fulfilment.py's module
     docstring's MIGRATION NOTES). Asserted by inspecting the actual SQL
     text of every promotion/send function.

Uses the same "load database.py under a private module name, stub psycopg2
only" technique test_database.py already established (see that file's own
long comment on why) -- this avoids depending on import order relative to
other test files in the same `unittest discover` run, several of which
install their own sys.modules["database"] stub.

Run with:
    python -m unittest tests.test_reconciliation -v
"""
import importlib.util
import inspect
import os
import sys
import types
import unittest
from unittest.mock import MagicMock, patch

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_DIR = os.path.dirname(_THIS_DIR)
sys.path.insert(0, _APP_DIR)

if "psycopg2" not in sys.modules:
    sys.modules["psycopg2"] = types.ModuleType("psycopg2")

_DATABASE_PATH = os.path.join(_APP_DIR, "database.py")
_spec = importlib.util.spec_from_file_location("_database_under_test_reconciliation", _DATABASE_PATH)
database = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(database)

import fulfilment
import worker
import letter_providers.registry as registry_module


def _conn_with_cursor():
    conn = MagicMock()
    cur = MagicMock()
    conn.cursor.return_value = cur
    return conn, cur


class TestPaymentThenDatabaseFailureRollsBackWholeSale(unittest.TestCase):
    """Section 9: 'successful payment followed by database failure.'
    confirm_reserved_lead_sale is the Stripe-webhook-driven path where this
    matters most -- real money has already moved by the time this function
    runs (see that function's own docstring: 'the caller treats None here
    as payment succeeded but we can't honour it, and must auto-refund')."""

    def test_confirm_reserved_lead_sale_rolls_back_if_fulfilment_insert_fails(self):
        conn, cur = _conn_with_cursor()
        # The reservation UPDATE...RETURNING succeeds (payment was real,
        # reservation was real, row is fetched) --
        cur.fetchone.return_value = (
            "lead-uuid-1", "PLANIT-001", "1 Test St", "Fell one oak", "Leeds",
            "medium", 4500, "J Bloggs", None, None, False, None,
        )
        with patch.object(database, "get_db_conn", return_value=conn), \
             patch.object(database, "SURL", "postgres://fake-for-test"), \
             patch.object(database, "_queue_letter_dispatch"), \
             patch.object(database.fulfilment, "create_allocation_and_obligation",
                           side_effect=Exception("simulated DB write failure (disk full / connection drop)")):
            result = database.confirm_reserved_lead_sale("lead-uuid-1", "cs_test_123", "buyer@example.com")

        # Must NOT report a completed sale.
        self.assertIsNone(result)
        # Must NOT have committed -- a commit here, followed by the
        # exception, would leave status='claimed' permanently with no
        # allocation record and a charged customer.
        conn.commit.assert_not_called()
        # Connection is still cleaned up either way.
        conn.close.assert_called_once()

    def test_confirm_reserved_lead_sale_commits_normally_on_success(self):
        """Sanity check for the test above: proves the mock setup itself is
        capable of reaching a commit, so the assertNotCalled above is
        actually testing something rather than passing vacuously."""
        conn, cur = _conn_with_cursor()
        cur.fetchone.return_value = (
            "lead-uuid-1", "PLANIT-001", "1 Test St", "Fell one oak", "Leeds",
            "medium", 4500, "J Bloggs", None, None, False, None,
        )
        with patch.object(database, "get_db_conn", return_value=conn), \
             patch.object(database, "SURL", "postgres://fake-for-test"), \
             patch.object(database, "_queue_letter_dispatch"), \
             patch.object(database.fulfilment, "create_allocation_and_obligation",
                           return_value=fulfilment.AllocationResult(ok=True, allocation_id="a1", obligation_id="o1")):
            result = database.confirm_reserved_lead_sale("lead-uuid-1", "cs_test_123", "buyer@example.com")
        self.assertIsNotNone(result)
        conn.commit.assert_called_once()

    def test_burn_lead_inventory_also_rolls_back_on_fulfilment_failure(self):
        """burn_lead_inventory is the free-lead-grant / legacy single-sale
        path -- no Stripe refund is relevant here, but the same atomicity
        guarantee (no half-burned lead with no allocation record) must
        still hold, since it got the identical fulfilment wiring this
        session."""
        conn, cur = _conn_with_cursor()
        cur.fetchone.return_value = (
            "lead-uuid-2", "PLANIT-002", "2 Test St", "Fell one ash", "Leeds",
            "medium", 4500, "A Homeowner", None, None, False, None,
        )
        with patch.object(database, "get_db_conn", return_value=conn), \
             patch.object(database, "SURL", "postgres://fake-for-test"), \
             patch.object(database, "_queue_letter_dispatch"), \
             patch.object(database.fulfilment, "create_allocation_and_obligation",
                           side_effect=Exception("simulated DB write failure")):
            result = database.burn_lead_inventory("lead-uuid-2", "buyer@example.com")
        self.assertIsNone(result)
        conn.commit.assert_not_called()


class TestSubscriptionQuotaRollsBackAllocation(unittest.TestCase):
    """Section 9: 'subscription quota / legacy entitlement interaction.'
    record_lead_dispatch_and_burn creates the fulfilment allocation BEFORE
    the quota-enforcing UPDATE runs (both must happen inside the same
    reserved-vs-burned transaction as the lead burn itself). If the quota
    UPDATE then finds the subscriber already at their monthly_quota, the
    function calls conn.rollback() and returns False -- this test proves
    that rollback genuinely undoes the allocation too (as it must, being
    the same transaction), not just the lead-burn UPDATE, so a subscriber
    who is over quota never ends up with a real allocation/obligation row
    for a lead they don't legitimately hold."""

    def test_quota_exceeded_releases_lead_and_rolls_back_allocation(self):
        conn, cur = _conn_with_cursor()

        # 1st execute(): burn UPDATE ... RETURNING -> succeeds
        # 2nd/3rd execute(): _queue_letter_dispatch + fulfilment insert calls
        #   are mocked out below, so they don't consume fetchone() results.
        # Then: INSERT INTO lead_dispatches (no RETURNING, fetchone irrelevant)
        # Then: quota UPDATE ... RETURNING -> None (quota already hit)
        cur.fetchone.side_effect = [
            ("lead-uuid-3", "PLANIT-003", "3 Test St", "J Bloggs"),  # burn UPDATE
            None,                                                     # quota UPDATE finds nothing
        ]
        allocation_calls = []
        with patch.object(database, "get_db_conn", return_value=conn), \
             patch.object(database, "SURL", "postgres://fake-for-test"), \
             patch.object(database, "_queue_letter_dispatch"), \
             patch.object(database.fulfilment, "create_allocation_and_obligation",
                           side_effect=lambda *a, **k: allocation_calls.append(1)):
            result = database.record_lead_dispatch_and_burn("lead-uuid-3", "sub-1", "contractor@example.com")

        self.assertFalse(result)
        # The allocation WAS attempted (this is what proves the ordering:
        # allocation happens before the quota check can veto it) --
        self.assertEqual(len(allocation_calls), 1)
        # -- but the whole thing was rolled back, not committed, so that
        # attempted allocation never becomes a durable row.
        conn.rollback.assert_called_once()
        conn.commit.assert_not_called()

    def test_quota_available_commits_allocation_normally(self):
        conn, cur = _conn_with_cursor()
        cur.fetchone.side_effect = [
            ("lead-uuid-4", "PLANIT-004", "4 Test St", "J Bloggs"),  # burn UPDATE
            (3,),                                                     # quota UPDATE succeeds, delivered_this_month=3
        ]
        with patch.object(database, "get_db_conn", return_value=conn), \
             patch.object(database, "SURL", "postgres://fake-for-test"), \
             patch.object(database, "_queue_letter_dispatch"), \
             patch.object(database.fulfilment, "create_allocation_and_obligation",
                           return_value=fulfilment.AllocationResult(ok=True, allocation_id="a1", obligation_id="o1")):
            result = database.record_lead_dispatch_and_burn("lead-uuid-4", "sub-1", "contractor@example.com")
        self.assertTrue(result)
        conn.commit.assert_called_once()
        conn.rollback.assert_not_called()


class TestNeverReadsLegacyLetterDispatchesForResending(unittest.TestCase):
    """Section 9: 'migration compatibility' -- the new pipeline must not
    blindly requeue historical rows. There is no migration script in this
    session's work that copies letter_dispatches rows into
    letter_obligations (deliberately -- see fulfilment.py's MIGRATION
    NOTES), so the only way this invariant could be violated is if some
    promotion/send function queried letter_dispatches directly. This test
    greps the actual SQL string literals embedded in the relevant source
    files, so it fails loudly if that ever changes -- it does not rely on
    trusting the docstrings to stay accurate."""

    def _source_of(self, *modules_and_funcs):
        return "\n".join(inspect.getsource(f) for f in modules_and_funcs)

    def test_worker_promotion_and_send_functions_never_mention_letter_dispatches(self):
        src = self._source_of(
            worker.promote_pending_approvals, worker.promote_pending_funding, worker.run_batch,
        )
        self.assertNotIn("letter_dispatches", src)

    def test_registry_attempt_send_never_mentions_letter_dispatches(self):
        src = inspect.getsource(registry_module.attempt_send)
        self.assertNotIn("letter_dispatches", src)

    def test_get_lead_owner_is_the_ONLY_sanctioned_reader_of_letter_dispatches(self):
        """The one deliberate exception -- ownership lookup for historical
        purchases, read-only, documented in fulfilment.py's MIGRATION
        NOTES. This test pins that down explicitly so a future change that
        adds a SECOND read (or a write) doesn't slip in unnoticed."""
        src = inspect.getsource(fulfilment.get_lead_owner)
        self.assertIn("letter_dispatches", src)
        self.assertIn("SELECT buyer_email FROM letter_dispatches", src)
        # And prove it's genuinely read-only in this function.
        self.assertNotIn("UPDATE letter_dispatches", src)
        self.assertNotIn("INSERT INTO letter_dispatches", src)
        self.assertNotIn("DELETE FROM letter_dispatches", src)


if __name__ == "__main__":
    unittest.main()
