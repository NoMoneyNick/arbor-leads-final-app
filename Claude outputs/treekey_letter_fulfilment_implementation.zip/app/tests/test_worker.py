"""
test_worker.py -- worker.py's promotion pipeline (pending_approval ->
pending_funding -> ready) and run_batch's use of the provider registry.
Run with:
    python -m unittest tests.test_worker -v
"""
import os
import sys
import unittest
from unittest.mock import MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import worker
import letter_content
import funding
from letter_providers.fake_provider import FakeLetterProvider
from letter_providers.registry import ProviderRegistry, ProviderSlot


class FakeCursor:
    """Supports both fetchone (a queue of single results) and fetchall (a
    queue of row-list results), consumed in call order -- same convention
    as the other FakeCursor helpers in this test suite."""

    def __init__(self, fetchone_results=None, fetchall_results=None):
        self.executed = []
        self._fetchone_results = list(fetchone_results or [])
        self._fetchall_results = list(fetchall_results or [])

    def execute(self, sql, params=None):
        self.executed.append((sql.strip(), params))

    def fetchone(self):
        return self._fetchone_results.pop(0) if self._fetchone_results else None

    def fetchall(self):
        return self._fetchall_results.pop(0) if self._fetchall_results else []


def _approved_settings(fingerprint):
    return letter_content.ContractorLetterSettings(
        contractor_email="contractor@example.com", business_name="Apex Tree Care", phone="0113 000 0000",
        approved=True, approved_fingerprint=fingerprint,
    )


class TestPromotePendingApprovals(unittest.TestCase):
    def setUp(self):
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"

    def _current_fingerprint(self):
        html = letter_content.render_letter(
            letter_content.ContractorLetterSettings(contractor_email="contractor@example.com",
                                                      business_name="Apex Tree Care", phone="0113 000 0000"),
            lead_reference="PLANIT-001", address="1 Test St", summary="Fell one oak", council="Leeds",
        )
        return letter_content.content_fingerprint(html)

    def test_promotes_when_approval_fingerprint_matches_current_render(self):
        fp = self._current_fingerprint()
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-001", "1 Test St", "J Bloggs", "contractor@example.com")]],
            fetchone_results=[
                ("contractor@example.com", "Apex Tree Care", "0113 000 0000", "", "", "", 1, True, fp),  # settings row
                ("Fell one oak", "Leeds"),   # leads row
                ("ob-1",),                    # UPDATE ... RETURNING id
            ],
        )
        report = worker.promote_pending_approvals(cur)
        self.assertEqual(report.promoted_to_pending_funding, 1)
        self.assertEqual(report.left_pending_approval, 0)

    def test_leaves_in_place_when_not_yet_approved(self):
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-001", "1 Test St", "J Bloggs", "contractor@example.com")]],
            fetchone_results=[None],  # get_contractor_settings -> no row at all
        )
        report = worker.promote_pending_approvals(cur)
        self.assertEqual(report.left_pending_approval, 1)
        self.assertEqual(report.promoted_to_pending_funding, 0)

    def test_leaves_in_place_when_settings_changed_since_approval(self):
        """Section 5: the contractor approved an OLDER version of their
        details; something changed since (business name, phone, insurance
        note) -- re-rendering now produces a different fingerprint than what
        was approved, so this must NOT be promoted."""
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-001", "1 Test St", "J Bloggs", "contractor@example.com")]],
            fetchone_results=[
                ("contractor@example.com", "A DIFFERENT NAME NOW", "0113 000 0000", "", "", "", 2, True, "stale-fingerprint-abc"),
                ("Fell one oak", "Leeds"),
            ],
        )
        report = worker.promote_pending_approvals(cur)
        self.assertEqual(report.left_pending_approval, 1)

    def test_leaves_in_place_when_lead_row_missing(self):
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-GONE", "1 Test St", "J Bloggs", "contractor@example.com")]],
            fetchone_results=[
                ("contractor@example.com", "Apex Tree Care", "0113 000 0000", "", "", "", 1, True, "whatever"),
                None,  # leads lookup finds nothing
            ],
        )
        report = worker.promote_pending_approvals(cur)
        self.assertEqual(report.left_pending_approval, 1)

    def test_missing_privacy_config_is_counted_as_an_error_not_silently_skipped(self):
        os.environ.pop(letter_content.PRIVACY_CONTACT_EMAIL_ENV, None)
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-001", "1 Test St", "J Bloggs", "contractor@example.com")]],
            fetchone_results=[
                ("contractor@example.com", "Apex Tree Care", "0113 000 0000", "", "", "", 1, True, "whatever"),
                ("Fell one oak", "Leeds"),
            ],
        )
        report = worker.promote_pending_approvals(cur)
        self.assertEqual(report.errors, 1)
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"  # restore for other tests


class TestPromotePendingFunding(unittest.TestCase):
    def test_promotes_when_gate_eligible(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(
            fetchall_results=[[("ob-1",)]],
            fetchone_results=[(5000,), ("ob-1",)],  # budget check, then UPDATE RETURNING id
        )
        report = worker.promote_pending_funding(cur, gate, estimated_cost_pence=50)
        self.assertEqual(report.promoted_to_ready, 1)

    def test_leaves_in_place_when_gate_says_no_budget(self):
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(fetchall_results=[[("ob-1",)]], fetchone_results=[(0,)])
        report = worker.promote_pending_funding(cur, gate, estimated_cost_pence=50)
        self.assertEqual(report.left_pending_funding_ineligible, 1)
        self.assertEqual(report.promoted_to_ready, 0)

    def test_partial_budget_promotes_only_what_it_can_cover(self):
        """Two obligations, 50p each, but only 60p available -- the gate is
        re-checked per obligation (via mailing_budget_confirmations' real
        remaining balance in production; here simulated by the FIRST check
        succeeding and consuming nothing itself -- the actual debit happens
        via gate.spend() elsewhere, e.g. after a confirmed send, which this
        promotion step deliberately does NOT call, since promotion is not a
        spend). This test asserts BOTH obligations are checked independently
        rather than the whole batch being all-or-nothing."""
        gate = funding.FundingGate(mode="hold")
        cur = FakeCursor(
            fetchall_results=[[("ob-1",), ("ob-2",)]],
            fetchone_results=[(60,), ("ob-1",), (0,)],  # ob-1: eligible+promoted; ob-2: re-check returns 0 -> ineligible
        )
        report = worker.promote_pending_funding(cur, gate, estimated_cost_pence=50)
        self.assertEqual(report.promoted_to_ready, 1)
        self.assertEqual(report.left_pending_funding_ineligible, 1)


class TestRunBatch(unittest.TestCase):
    def setUp(self):
        os.environ[letter_content.PRIVACY_CONTACT_EMAIL_ENV] = "privacy@treekey.co.uk"

    def test_dry_run_batch_marks_every_ready_obligation_dry_run(self):
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-001", "1 Test St", "J Bloggs", "contractor@example.com", "idem-1")]],
            fetchone_results=[
                ("contractor@example.com", "Apex Tree Care", "0113 000 0000", "", "", "", 1, False, None),  # settings
                ("Fell one oak", "Leeds"),   # lead row
                None,                          # suppression check -> not suppressed
                ("ob-1",),                     # claim_for_submission
            ],
        )
        registry = ProviderRegistry([ProviderSlot(adapter=FakeLetterProvider())])
        outcomes = worker.run_batch(cur, registry, worker_id="w1", is_dry_run=True)
        self.assertEqual(len(outcomes), 1)
        self.assertEqual(outcomes[0].final_status, "dry_run")

    def test_skips_obligation_with_no_contractor_settings_rather_than_crashing(self):
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-001", "1 Test St", "J Bloggs", "nobody-configured@example.com", "idem-1")]],
            fetchone_results=[None],  # no settings row
        )
        registry = ProviderRegistry([ProviderSlot(adapter=FakeLetterProvider())])
        outcomes = worker.run_batch(cur, registry, worker_id="w1", is_dry_run=True)
        self.assertEqual(outcomes, [])

    def test_skips_obligation_when_lead_row_missing(self):
        cur = FakeCursor(
            fetchall_results=[[("ob-1", "PLANIT-GONE", "1 Test St", "J Bloggs", "contractor@example.com", "idem-1")]],
            fetchone_results=[
                ("contractor@example.com", "Apex Tree Care", "0113 000 0000", "", "", "", 1, False, None),
                None,  # lead row missing
            ],
        )
        registry = ProviderRegistry([ProviderSlot(adapter=FakeLetterProvider())])
        outcomes = worker.run_batch(cur, registry, worker_id="w1", is_dry_run=True)
        self.assertEqual(outcomes, [])


if __name__ == "__main__":
    unittest.main()
