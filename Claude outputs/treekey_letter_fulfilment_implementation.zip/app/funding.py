"""
funding.py -- Keeps "the customer paid" separate from "TreeKey has money it
can safely spend on postage", per the brief's section 3.

Five distinct things, deliberately not collapsed into one:

  1. payment_confirmed      -- a signed Stripe event says this specific
                                payment/subscription charge succeeded.
  2. funds_pending_or_available -- Stripe's own view of whether the money
                                has cleared (not implemented against the
                                live Stripe Balance/Payout API in this
                                pass -- see LIMITATIONS below).
  3. payout_evidence        -- proof the money actually reached the bank
                                (not implemented -- see LIMITATIONS).
  4. mailing_budget_available -- TreeKey's own confirmation that there is
                                money set aside to pay a postal vendor.
                                THIS is what gates a real submission today.
  5. eligible_for_submission -- the computed AND of everything else
                                (approved template + not suppressed +
                                address present + funding gate open).

LIMITATIONS (explicit, not hidden):
This pass does NOT implement live Stripe Balance/Payout reconciliation --
tying one specific order to one specific bank credit is a materially bigger
piece of work (Stripe balance transactions, payout objects, the fact that a
payout bundles many charges, refund/dispute clawback timing) and the brief
itself allows a fallback for exactly this case: "a restricted, audited admin
action to confirm a funded mailing budget." That's what's implemented here --
FundingGate.confirm_budget() -- an admin-only, logged action that sets a
budget ceiling TreeKey staff have separately verified is real (e.g. by
looking at the actual bank balance), NOT an automatic Stripe-derived proof.
Wiring genuine payout reconciliation is listed as outstanding work in
docs/launch_checklist.md, not silently declared done.

DEFAULT BEHAVIOUR: FUNDING_MODE=hold. No submission is ever eligible unless
an admin has explicitly confirmed a budget (via confirm_budget) or the
gate is running in "simulate" mode for local development/tests, or a future
explicitly-enabled working_capital mode is on (FUNDING_MODE=working_capital,
NOT the default, must be turned on deliberately -- see class docstring).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger("treekey-funding")

FUNDING_MODES = ("hold", "simulate", "working_capital")


def init_funding_schema(cur) -> None:
    cur.execute("""
        CREATE TABLE IF NOT EXISTS mailing_budget_confirmations (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            amount_pence INT NOT NULL,
            confirmed_by TEXT NOT NULL,
            note TEXT,
            spent_pence INT NOT NULL DEFAULT 0,
            active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_budget_active ON mailing_budget_confirmations(active) WHERE active = TRUE;
    """)


@dataclass
class FundingDecision:
    eligible: bool
    mode: str
    reason: str
    available_pence: Optional[int] = None


class FundingGate:
    """One instance per process/request is fine -- it does not cache
    anything that changes mid-process; every check re-reads the DB (or the
    simulated state) so a fresh admin confirmation takes effect immediately."""

    def __init__(self, mode: Optional[str] = None):
        self.mode = (mode or os.getenv("FUNDING_MODE", "hold")).strip().lower()
        if self.mode not in FUNDING_MODES:
            logger.warning(f"[Funding] Unknown FUNDING_MODE={self.mode!r}, falling back to 'hold' (fail safe).")
            self.mode = "hold"
        # Only used when mode == "simulate" (tests/local dev). Never read in
        # "hold" or "working_capital" mode.
        self._simulated_available_pence: Optional[int] = None

    def simulate_budget(self, available_pence: int) -> None:
        """Test/dev only. Raises if called outside simulate mode so a test
        can't accidentally believe it's testing production behaviour."""
        if self.mode != "simulate":
            raise RuntimeError("simulate_budget() only valid when mode == 'simulate'.")
        self._simulated_available_pence = available_pence

    def confirm_budget(self, cur, *, amount_pence: int, confirmed_by: str, note: str) -> str:
        """The restricted, audited admin action. Caller (main.py) must gate
        this behind verify_dashboard_auth or an equivalent admin check --
        this function itself does not check identity, it only records who
        the caller says did it, which is why main.py must never let this be
        reached without real admin auth."""
        if amount_pence <= 0:
            raise ValueError("amount_pence must be positive.")
        cur.execute("""
            INSERT INTO mailing_budget_confirmations (amount_pence, confirmed_by, note)
            VALUES (%s, %s, %s) RETURNING id;
        """, (amount_pence, confirmed_by, note))
        budget_id = str(cur.fetchone()[0])
        logger.info(f"[Funding] Budget confirmed by {confirmed_by}: £{amount_pence/100:.2f} ({note}) -> {budget_id}")
        return budget_id

    def _available_pence_from_db(self, cur) -> int:
        cur.execute("""
            SELECT COALESCE(SUM(amount_pence - spent_pence), 0)
            FROM mailing_budget_confirmations WHERE active = TRUE;
        """)
        return int(cur.fetchone()[0] or 0)

    def check(self, cur, *, estimated_cost_pence: int) -> FundingDecision:
        if self.mode == "working_capital":
            # Explicitly enabled elsewhere (see class docstring + config
            # example) -- sends proceed on confirmed payment alone, without
            # waiting for a separately confirmed mailing budget. This is
            # NOT the default and nothing in this codebase turns it on by
            # itself.
            return FundingDecision(eligible=True, mode=self.mode,
                                    reason="working_capital mode: funded from existing postage funds by explicit configuration.")

        if self.mode == "simulate":
            available = self._simulated_available_pence
            if available is None:
                return FundingDecision(eligible=False, mode=self.mode,
                                        reason="simulate mode active but simulate_budget() was never called -- fails safe.")
            eligible = available >= estimated_cost_pence
            return FundingDecision(eligible=eligible, mode=self.mode,
                                    reason="simulated budget sufficient" if eligible else "simulated budget insufficient",
                                    available_pence=available)

        # mode == "hold" (default): only an explicit, audited admin
        # confirmation opens the gate.
        available = self._available_pence_from_db(cur)
        eligible = available >= estimated_cost_pence
        return FundingDecision(
            eligible=eligible, mode=self.mode,
            reason=("confirmed mailing budget covers this letter" if eligible
                    else "no confirmed mailing budget (or insufficient) -- held pending admin confirm_budget()"),
            available_pence=available,
        )

    def spend(self, cur, amount_pence: int) -> None:
        """Debits the oldest active confirmed budget(s) FIFO. Called only
        after a real (non-dry-run) provider acceptance -- never for a
        dry-run or a merely 'ready' obligation."""
        remaining = amount_pence
        cur.execute("""
            SELECT id, amount_pence, spent_pence FROM mailing_budget_confirmations
            WHERE active = TRUE AND spent_pence < amount_pence ORDER BY created_at ASC FOR UPDATE;
        """)
        rows = cur.fetchall()
        for budget_id, amt, spent in rows:
            if remaining <= 0:
                break
            headroom = amt - spent
            take = min(headroom, remaining)
            cur.execute("UPDATE mailing_budget_confirmations SET spent_pence = spent_pence + %s WHERE id = %s;",
                        (take, budget_id))
            remaining -= take
        if remaining > 0:
            logger.error(f"[Funding] spend() could not fully account for £{amount_pence/100:.2f} -- "
                         f"£{remaining/100:.2f} unaccounted. Budget confirmations may be stale; admin review needed.")
