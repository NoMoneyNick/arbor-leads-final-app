"""
test_main.py -- Unit tests for main.py's own logic that doesn't need a
real FastAPI/Postgres/Stripe stack.

Sep 3 2026: added alongside the "council-side-fault disclosure" feature
(_COUNCIL_SOURCE_ISSUES / _council_source_issue in main.py) -- Nick's ask:
"we should place a note on the website when an area cannot be accessed due
to the councils fault or issue". main.py had NO test file at all before
this. This file does not attempt to cover the whole app (a full FastAPI
route/DB/Stripe integration suite is a much larger, separate undertaking)
-- it exists specifically to lock the one piece of pure, testable logic
this session added: the mapping from a resolved council/district name to
the public-facing disclosure note shown on /check-postcode for the three
councils confirmed this session to be broken/bot-gated on their OWN end
(Merton, Bath & North East Somerset, West Northamptonshire) -- see that
dict's own comment in main.py for why each one is there.

Neither `fastapi` nor `stripe` is installed in this sandbox (network
egress to pypi.org is blocked here -- see test_payments.py's own docstring
for the same constraint hit earlier this session), so both are stubbed
into sys.modules before importing main.py, same technique test_scrapers.py/
test_payments.py/test_research.py already use for `database`/
`notifications`/`dotenv`. This runs anywhere, no real FastAPI/Postgres/
Stripe install or network access required. The fastapi stub is a plain
pass-through: every `@app.get/post/api_route/on_event` decorator returns
the wrapped function unchanged, so main.py's ~80 route functions import as
ordinary Python functions without ever standing up a real ASGI app.
"""
import os
import sys
import types
import unittest
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Stub heavy/external modules BEFORE importing main.py, so this file runs
# anywhere -- no Postgres, no .env file, no Stripe account, no network.
# Idempotent per-attribute stubbing (matches test_scrapers.py's own fix for
# running under `python -m unittest discover`, where another test file's
# stub of the same module name may already be in sys.modules).
# ---------------------------------------------------------------------------
if "database" not in sys.modules:
    sys.modules["database"] = types.ModuleType("database")
_database = sys.modules["database"]
if not hasattr(_database, "init_db"):
    _database.init_db = MagicMock()
if not hasattr(_database, "get_db_conn"):
    _database.get_db_conn = MagicMock()
if not hasattr(_database, "is_territory_claimed"):
    _database.is_territory_claimed = MagicMock(return_value=False)
if not hasattr(_database, "increment_api_usage"):
    _database.increment_api_usage = MagicMock(return_value={"warning_needed": False})
if not hasattr(_database, "create_magic_auth_token"):
    _database.create_magic_auth_token = MagicMock(return_value={"token": "tok", "otp": "000000", "email": "test@example.com"})
if not hasattr(_database, "verify_magic_auth_token"):
    _database.verify_magic_auth_token = MagicMock(return_value=None)
if not hasattr(_database, "lookup_outcode_centroid"):
    _database.lookup_outcode_centroid = MagicMock(return_value=(53.0, -1.0))
if not hasattr(_database, "create_or_update_limbo_account"):
    _database.create_or_update_limbo_account = MagicMock(return_value={
        "id": "id-1", "email": "dave@apex-trees.co.uk", "customer_name": "Dave", "phone": None,
        "center_outcode": "NG22", "lat": 53.0, "lon": -1.0, "free_lead_ref": None,
        "last_teaser_lead_ref": None, "signed_up_at": None, "last_teaser_sent_at": None, "unsubscribed": False,
    })
if not hasattr(_database, "find_nearest_unclaimed_lead"):
    _database.find_nearest_unclaimed_lead = MagicMock(return_value=None)
if not hasattr(_database, "burn_lead_inventory"):
    _database.burn_lead_inventory = MagicMock(return_value=None)
if not hasattr(_database, "record_free_lead_grant"):
    _database.record_free_lead_grant = MagicMock(return_value=True)
if not hasattr(_database, "get_limbo_account"):
    _database.get_limbo_account = MagicMock(return_value=None)
if not hasattr(_database, "get_lead_by_reference"):
    _database.get_lead_by_reference = MagicMock(return_value=None)
if not hasattr(_database, "get_contractor_subscription"):
    _database.get_contractor_subscription = MagicMock(return_value=None)

if "notifications" not in sys.modules:
    sys.modules["notifications"] = types.ModuleType("notifications")
_notifications = sys.modules["notifications"]
if not hasattr(_notifications, "send_system_incident_alert"):
    _notifications.send_system_incident_alert = MagicMock()
if not hasattr(_notifications, "send_resend_email"):
    _notifications.send_resend_email = MagicMock()
if not hasattr(_notifications, "send_transactional_email"):
    _notifications.send_transactional_email = MagicMock(return_value=True)
if not hasattr(_notifications, "dispatch_lead_alerts"):
    _notifications.dispatch_lead_alerts = MagicMock()
if not hasattr(_notifications, "send_api_quota_warning_email"):
    _notifications.send_api_quota_warning_email = MagicMock()
if not hasattr(_notifications, "send_free_account_welcome_email"):
    _notifications.send_free_account_welcome_email = MagicMock(return_value=True)
if not hasattr(_notifications, "send_teaser_lead_email"):
    _notifications.send_teaser_lead_email = MagicMock(return_value=True)
if not hasattr(_notifications, "send_teaser_email_batch"):
    _notifications.send_teaser_email_batch = MagicMock(return_value=0)

if "dotenv" not in sys.modules:
    _fake_dotenv = types.ModuleType("dotenv")
    _fake_dotenv.load_dotenv = lambda *a, **k: None
    sys.modules["dotenv"] = _fake_dotenv

if "stripe" not in sys.modules:
    _fake_stripe = types.ModuleType("stripe")
    _fake_stripe.api_key = ""

    _fake_stripe_error = types.ModuleType("stripe.error")

    class _StripeError(Exception):
        pass

    class _AuthenticationError(_StripeError):
        pass

    class _SignatureVerificationError(_StripeError):
        pass

    _fake_stripe_error.StripeError = _StripeError
    _fake_stripe_error.AuthenticationError = _AuthenticationError
    _fake_stripe_error.SignatureVerificationError = _SignatureVerificationError
    _fake_stripe.error = _fake_stripe_error

    _fake_checkout = types.ModuleType("stripe.checkout")
    _fake_session = types.ModuleType("stripe.checkout.Session")
    _fake_session.create = MagicMock()
    _fake_checkout.Session = _fake_session
    _fake_stripe.checkout = _fake_checkout

    _fake_stripe.Webhook = MagicMock()

    sys.modules["stripe"] = _fake_stripe
    sys.modules["stripe.error"] = _fake_stripe_error
    sys.modules["stripe.checkout"] = _fake_checkout

if "fastapi" not in sys.modules:
    _fake_fastapi = types.ModuleType("fastapi")

    def _passthrough_decorator_factory(*a, **k):
        def decorator(fn):
            return fn
        return decorator

    class _FakeFastAPI:
        """Every route-registering method is a pure pass-through decorator
        -- main.py's ~80 `@app.get/post/api_route(...)`-decorated functions
        import as ordinary Python functions, no real ASGI routing stood up.
        `on_event` (startup/shutdown hooks) is the same shape."""
        def __init__(self, *a, **k):
            pass

        def get(self, *a, **k):
            return _passthrough_decorator_factory(*a, **k)

        def post(self, *a, **k):
            return _passthrough_decorator_factory(*a, **k)

        def api_route(self, *a, **k):
            return _passthrough_decorator_factory(*a, **k)

        def on_event(self, *a, **k):
            return _passthrough_decorator_factory(*a, **k)

        def mount(self, *a, **k):
            pass

    def _fake_query(*a, **k):
        return None

    def _fake_form(*a, **k):
        return None

    def _fake_depends(*a, **k):
        return None

    class _FakeHTTPException(Exception):
        def __init__(self, status_code=500, detail=None, headers=None):
            self.status_code = status_code
            self.detail = detail
            self.headers = headers
            super().__init__(detail)

    class _FakeRequest:
        pass

    class _FakeBackgroundTasks:
        pass

    _fake_fastapi.FastAPI = _FakeFastAPI
    _fake_fastapi.Query = _fake_query
    _fake_fastapi.BackgroundTasks = _FakeBackgroundTasks
    _fake_fastapi.HTTPException = _FakeHTTPException
    _fake_fastapi.Depends = _fake_depends
    _fake_fastapi.Request = _FakeRequest
    _fake_fastapi.Form = _fake_form
    sys.modules["fastapi"] = _fake_fastapi

    _fake_responses = types.ModuleType("fastapi.responses")

    class _FakeHTMLResponse:
        def __init__(self, *a, **k):
            pass

    class _FakeRedirectResponse:
        """Sep 5 2026: stores url/status_code (matching real
        starlette.RedirectResponse's readable attributes) instead of
        discarding the constructor args -- needed once tests started
        asserting on where a route redirects to (e.g. the free-account
        signup flow), not just that some object came back."""
        def __init__(self, url=None, status_code=307, *a, **k):
            self.url = url
            self.status_code = status_code
            self._cookies = {}

        def set_cookie(self, key=None, value=None, *a, **k):
            self._cookies[key] = value

    class _FakeResponse:
        def __init__(self, *a, **k):
            pass

    _fake_responses.HTMLResponse = _FakeHTMLResponse
    _fake_responses.RedirectResponse = _FakeRedirectResponse
    _fake_responses.Response = _FakeResponse
    sys.modules["fastapi.responses"] = _fake_responses

    _fake_staticfiles = types.ModuleType("fastapi.staticfiles")

    class _FakeStaticFiles:
        def __init__(self, *a, **k):
            pass

    _fake_staticfiles.StaticFiles = _FakeStaticFiles
    sys.modules["fastapi.staticfiles"] = _fake_staticfiles

    _fake_security = types.ModuleType("fastapi.security")

    class _FakeHTTPBasic:
        def __init__(self, *a, **k):
            pass

    class _FakeHTTPBasicCredentials:
        def __init__(self, *a, **k):
            pass

    _fake_security.HTTPBasic = _FakeHTTPBasic
    _fake_security.HTTPBasicCredentials = _FakeHTTPBasicCredentials
    sys.modules["fastapi.security"] = _fake_security

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import main  # noqa: E402


class TestCouncilSourceIssueDisclosure(unittest.TestCase):
    """Locks in the /check-postcode disclosure note added Sep 3 2026 for
    the three councils confirmed this session to be broken/bot-gated on
    their OWN end (see main.py's _COUNCIL_SOURCE_ISSUES for the live
    evidence behind each one) -- distinguishing "council fault, we're on
    it" from an ordinary, healthy "0 leads today" area.

    Nick's explicit instruction on the wording (verbatim): "do not mention
    bots or anything. just state we havent got them and that its on the
    councils end not ours" -- so these tests check for the plain,
    non-technical phrasing itself, and also guard against a future edit
    accidentally reintroducing technical terms into user-facing copy."""

    def test_merton_returns_its_disclosure_note(self):
        note = main._council_source_issue("Merton")
        self.assertIsNotNone(note)
        self.assertIn("council's end", note)

    def test_bath_and_north_east_somerset_returns_its_disclosure_note(self):
        note = main._council_source_issue("Bath and North East Somerset")
        self.assertIsNotNone(note)
        self.assertIn("council's end", note)

    def test_west_northamptonshire_returns_its_disclosure_note(self):
        note = main._council_source_issue("West Northamptonshire")
        self.assertIsNotNone(note)
        self.assertIn("council's end", note)

    def test_no_technical_jargon_leaks_into_user_facing_copy(self):
        """Nick was explicit: no "bots", no technical explanation at all --
        just "we haven't got them" and "it's on the council's end"."""
        banned_terms = ["bot", "captcha", "recaptcha", "waf", "javascript", "js ", "api"]
        for key, message in main._COUNCIL_SOURCE_ISSUES.items():
            lowered = message.lower()
            for term in banned_terms:
                self.assertNotIn(term, lowered, f"{key!r}'s message leaks technical term {term!r}: {message!r}")

    def test_matching_is_case_insensitive_and_tolerates_council_suffix(self):
        """postcodes.io's admin_district naming isn't perfectly consistent
        about a trailing "Council"/"District Council" -- the match must not
        depend on getting that suffix exactly right."""
        self.assertIsNotNone(main._council_source_issue("MERTON"))
        self.assertIsNotNone(main._council_source_issue("merton council"))
        self.assertIsNotNone(main._council_source_issue("West Northamptonshire Council"))

    def test_healthy_council_returns_none(self):
        """An ordinary, fully-working council must never show the notice --
        it would misrepresent a genuine "nothing pending today" as a fault
        on the council's end."""
        self.assertIsNone(main._council_source_issue("Birmingham"))
        self.assertIsNone(main._council_source_issue("Leeds City Council"))

    def test_blank_or_missing_district_returns_none(self):
        self.assertIsNone(main._council_source_issue(None))
        self.assertIsNone(main._council_source_issue(""))

    def test_every_entry_is_confirmed_blocked_not_a_todo(self):
        """Guards against this dict quietly growing into a dumping ground
        for "haven't built this yet" councils -- it exists ONLY for
        councils whose own portal is confirmed broken/bot-gated, per its
        own comment in main.py."""
        for key, message in main._COUNCIL_SOURCE_ISSUES.items():
            self.assertTrue(key.islower(), f"key {key!r} should be lower-case for the substring match")
            self.assertGreater(len(message), 20)


class TestMagicLinkGoesToTheRealContractorNotTestEmail(unittest.IsolatedAsyncioTestCase):
    """Sep 5 2026 CRITICAL FIX regression test. request_magic_link() used to
    call notifications.send_resend_email() for the login-link email --
    that function ALWAYS sends to the fixed internal TEST_EMAIL address
    (it's the admin/incident-alert helper), so every real contractor's
    1-tap login link was silently delivered to Nick's own inbox instead of
    theirs. Root-caused live while building the free-signup feature (which
    also needed a genuine customer-facing send). This locks in that the
    fix (notifications.send_transactional_email, which takes an explicit
    recipient) is what actually gets called, with the contractor's own
    address -- not the old admin-only helper."""

    async def test_login_link_is_sent_to_the_contact_address_supplied(self):
        class _FakeForm(dict):
            pass

        class _FakeRequest:
            def __init__(self, contact):
                self.client = MagicMock(host="127.0.0.1")
                self._contact = contact

            async def form(self):
                return _FakeForm({"contact": self._contact})

        fake_request = _FakeRequest("dave@apex-trees.co.uk")

        with patch.object(main, "_check_rate_limit", return_value=True), \
             patch("database.create_magic_auth_token",
                   return_value={"token": "tok123", "otp": "123456", "email": "dave@apex-trees.co.uk"}), \
             patch.object(_notifications, "send_transactional_email", return_value=True) as mock_send, \
             patch.object(_notifications, "send_resend_email") as mock_old_send:
            await main.request_magic_link(fake_request)

        mock_send.assert_called_once()
        _, kwargs = mock_send.call_args
        self.assertEqual(kwargs.get("to_email"), "dave@apex-trees.co.uk")
        # The old admin-only helper (always TEST_EMAIL) must never be used here again.
        mock_old_send.assert_not_called()


# 2026-09-23, CRITICAL SECURITY FIX (external review finding): the new
# regression coverage for "the magic-link token must never appear in
# /api/request-magic-link's own HTTP response" lives in
# tests/test_magic_link_credential_exposure.py instead of here.
# Reason: this file, standalone, cannot actually import main.py in this
# sandbox -- main.py unconditionally does `import scanners` / `import
# research` at module level, and neither module is present in this working
# copy (a pre-existing gap, confirmed before writing any new test: `python
# -m unittest test_main -v` fails with ModuleNotFoundError on `scanners`
# even without any of this session's edits). The docstring at the top of
# this file references test_scrapers.py/test_payments.py/test_research.py
# as the files that stub those modules first when run together under a
# fuller discovery -- none of those three files exist in this working
# copy either. tests/test_access_control.py (imported by every file under
# tests/) already stubs scanners/research/payments before importing main,
# and `python -m unittest discover -s tests -v` is this session's own
# established, actually-runnable full-suite command (see ERROR_LOG.md /
# docs/operator_guide.md), so the new test lives there instead of adding
# dead-on-arrival tests to a file that cannot execute here.


class TestFreeAccountSignup(unittest.IsolatedAsyncioTestCase):
    """Sep 5 2026, Nick's "limbo account" ask: sign up free (no card) ->
    get one real lead immediately -> land on /free-dashboard, logged in.
    These lock in the route-level wiring; the underlying DB/email logic
    itself is covered in test_database.py/test_notifications.py."""

    class _FakeRequest:
        def __init__(self, fields: dict):
            self.client = MagicMock(host="127.0.0.1")
            self._fields = fields

        async def form(self):
            return dict(self._fields)

    def setUp(self):
        # Sep 5 2026: these are shared MagicMocks on the module-level
        # database stub (persisting across every test in this file), so
        # each test here resets the ones it cares about rather than
        # inheriting call counts/return values left over from another test.
        for mock_attr in ("find_nearest_unclaimed_lead", "burn_lead_inventory",
                          "record_free_lead_grant", "create_or_update_limbo_account",
                          "lookup_outcode_centroid"):
            getattr(_database, mock_attr).reset_mock(side_effect=True)
        _database.lookup_outcode_centroid.return_value = (53.0, -1.0)
        _database.find_nearest_unclaimed_lead.return_value = None
        _database.burn_lead_inventory.return_value = None
        _database.record_free_lead_grant.return_value = True
        _database.create_or_update_limbo_account.return_value = {
            "id": "id-1", "email": "dave@apex-trees.co.uk", "free_lead_ref": None,
        }

    async def test_valid_signup_grants_lead_and_sets_session_cookie(self):
        _database.find_nearest_unclaimed_lead.return_value = {"reference": "TREE-1", "address": "1 A Rd, NG22 8AA"}
        _database.burn_lead_inventory.return_value = {"reference": "TREE-1", "address": "1 A Rd, NG22 8AA",
                                                        "summary": "Felling", "council_source": "Test Council"}
        _database.create_or_update_limbo_account.return_value = {
            "id": "id-1", "email": "dave@apex-trees.co.uk", "free_lead_ref": None,
        }
        fake_request = self._FakeRequest({"name": "Dave", "email": "dave@apex-trees.co.uk",
                                           "phone": "", "postcode": "NG22"})
        with patch.object(main, "_check_rate_limit", return_value=True), \
             patch.object(_notifications, "send_free_account_welcome_email", return_value=True) as mock_welcome:
            response = await main.free_signup(fake_request)

        _database.find_nearest_unclaimed_lead.assert_called_once()
        _database.burn_lead_inventory.assert_called_once_with("TREE-1", "dave@apex-trees.co.uk")
        _database.record_free_lead_grant.assert_called_once_with("dave@apex-trees.co.uk", "TREE-1")
        mock_welcome.assert_called_once()
        self.assertEqual(response.url, "/free-dashboard")

    async def test_signup_with_no_nearby_lead_still_creates_account(self):
        """No lead available near them right now must not block account
        creation -- they still land on /free-dashboard, just with a
        "we'll email you one" message there (that page's own concern)."""
        _database.find_nearest_unclaimed_lead.return_value = None
        _database.create_or_update_limbo_account.return_value = {
            "id": "id-2", "email": "nolead@example.com", "free_lead_ref": None,
        }
        fake_request = self._FakeRequest({"name": "", "email": "nolead@example.com",
                                           "phone": "", "postcode": "ZZ1"})
        with patch.object(main, "_check_rate_limit", return_value=True):
            response = await main.free_signup(fake_request)
        _database.burn_lead_inventory.assert_not_called()
        self.assertEqual(response.url, "/free-dashboard")

    async def test_repeat_signup_does_not_grant_a_second_lead(self):
        """create_or_update_limbo_account already has a free_lead_ref ->
        must not call find_nearest_unclaimed_lead/burn_lead_inventory again."""
        _database.create_or_update_limbo_account.return_value = {
            "id": "id-1", "email": "dave@apex-trees.co.uk", "free_lead_ref": "TREE-ALREADY-GRANTED",
        }
        fake_request = self._FakeRequest({"name": "Dave", "email": "dave@apex-trees.co.uk",
                                           "phone": "", "postcode": "NG22"})
        with patch.object(main, "_check_rate_limit", return_value=True):
            response = await main.free_signup(fake_request)
        _database.find_nearest_unclaimed_lead.assert_not_called()
        _database.burn_lead_inventory.assert_not_called()
        self.assertEqual(response.url, "/free-dashboard")

    async def test_unrecognised_postcode_redirects_with_error_and_creates_no_account(self):
        _database.lookup_outcode_centroid.return_value = (None, None)
        fake_request = self._FakeRequest({"name": "Dave", "email": "dave@apex-trees.co.uk",
                                           "phone": "", "postcode": "NOTAPOSTCODE"})
        with patch.object(main, "_check_rate_limit", return_value=True):
            response = await main.free_signup(fake_request)
        _database.create_or_update_limbo_account.assert_not_called()
        self.assertIn("/free-account", response.url)

    async def test_missing_email_redirects_with_error(self):
        fake_request = self._FakeRequest({"name": "Dave", "email": "", "phone": "", "postcode": "NG22"})
        with patch.object(main, "_check_rate_limit", return_value=True):
            response = await main.free_signup(fake_request)
        self.assertIn("/free-account", response.url)


class TestVerifyLoginRoutesLimboAccountsToFreeDashboard(unittest.TestCase):
    """Sep 5 2026: verify_login() used to send anyone without an ACTIVE
    paid subscription straight to /pricing?msg=no_subscription -- that
    would have wrongly locked out a legitimate free "limbo account" signup
    the moment they tried to log back in. Confirms the new branch: a real
    (but unpaid) limbo account lands on /free-dashboard instead."""

    def test_limbo_account_lands_on_free_dashboard(self):
        with patch("database.verify_magic_auth_token", return_value="dave@apex-trees.co.uk"), \
             patch.object(main, "_check_rate_limit", return_value=True), \
             patch("database.get_contractor_subscription", return_value=None), \
             patch("database.get_limbo_account", return_value={"email": "dave@apex-trees.co.uk"}):
            fake_request = MagicMock()
            fake_request.client = MagicMock(host="127.0.0.1")
            response = main.verify_login(fake_request, token="tok")
        self.assertEqual(response.url, "/free-dashboard")

    def test_unknown_email_still_goes_to_pricing(self):
        with patch("database.verify_magic_auth_token", return_value="stranger@example.com"), \
             patch.object(main, "_check_rate_limit", return_value=True), \
             patch("database.get_contractor_subscription", return_value=None), \
             patch("database.get_limbo_account", return_value=None):
            fake_request = MagicMock()
            fake_request.client = MagicMock(host="127.0.0.1")
            response = main.verify_login(fake_request, token="tok")
        self.assertIn("/pricing", response.url)

    def test_active_paid_subscriber_still_goes_to_full_dashboard(self):
        with patch("database.verify_magic_auth_token", return_value="paid@apex-trees.co.uk"), \
             patch.object(main, "_check_rate_limit", return_value=True), \
             patch("database.get_contractor_subscription", return_value={"active": True}):
            fake_request = MagicMock()
            fake_request.client = MagicMock(host="127.0.0.1")
            response = main.verify_login(fake_request, token="tok")
        self.assertEqual(response.url, "/dashboard")


if __name__ == "__main__":
    unittest.main(verbosity=2)
