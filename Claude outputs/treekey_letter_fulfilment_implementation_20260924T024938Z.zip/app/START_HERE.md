# START HERE — TreeKey / Vector Data Labs letter-fulfilment work

Originally written 2026-09-18 as a resumable checkpoint under a "stop and
save" instruction; updated 2026-09-22 after resuming and finishing the one
item that was left outstanding (Item 5, PostgreSQL concurrency). All 6
items from the original governing task are now implemented and tested.
This file is the resume point / map of the work. Read this before doing
anything else in this project.

## 1. Exact project location

- Working tree: `/home/claude/treekey_work/app`
- Git repo root (tracks a baseline snapshot, one level up): `/home/claude/treekey_work/.git`
- Run `git status` from `/home/claude/treekey_work` to see the exact diff against baseline.

### Modified (tracked) files
- `app/database.py`
- `app/main.py`
- `app/notifications.py`
- `app/payments.py`

### New (untracked) implementation files
- `app/address_release.py`
- `app/fulfilment.py`
- `app/funding.py`
- `app/letter_content.py`
- `app/letter_providers/` (package)
- `app/migrations/`
- `app/suppression.py`
- `app/worker.py`
- `app/worker_runner.py`
- `app/.env.example.letter-fulfilment`
- `app/docs/` (operator_guide.md, launch_checklist.md, handoff.md, letter_provider_assessment.md)
- `app/tests/` (full unit-test suite, plus `app/tests/postgres_concurrency/` — the
  standalone real-Postgres integration test added 2026-09-22)

## 1a. How to apply a delivered ZIP to your actual project (added 2026-09-24)

**Read this before extracting any checkpoint ZIP onto your own machine.**
Added after a live-site audit found `/letter-settings` 404ing and
`/privacy-policy` still showing the old 24-month wording, despite both
being implemented, tested, and delivered days earlier. Diagnosis: every
checkpoint ZIP (including this one) packages files under an `app/`
folder — `app/main.py`, `app/database.py`, etc. — because that's this
session's own working-directory layout. But the copy of your project
uploaded into this session (`VECTOR DATA LABS/`, a flat folder with
`main.py`, `database.py`, `notifications.py` etc. directly inside it, no
`app/` wrapper, alongside `PROJECT_STATE.md`'s own note that a real
deploy "happens once Nick runs `UPDATE_WEBSITE.bat` / deploys on Render")
shows your actual project is FLAT, not nested under an `app/` folder.

**If you extract a checkpoint ZIP and just copy or drop its whole `app/`
folder into your project as a subfolder, your deploy script/Render will
keep running your existing flat `main.py` and never see the updated one**
— which would exactly produce both symptoms above: a missing new route,
and old static text unchanged, with no code defect on either side. The
new/changed files are ALWAYS the ones inside the ZIP's `app/` folder —
copy their CONTENTS (not the `app/` folder itself) directly into your
flat project root, overwriting the matching files by name (`main.py` over
`main.py`, `database.py` over `database.py`, etc.), then run your normal
`UPDATE_WEBSITE.bat` / Render deploy step as usual.

**This is a plausible, evidence-backed diagnosis, not a confirmed one** —
this session cannot see your actual deploy folder or your Render
dashboard. It's equally possible the ZIP was simply never deployed yet at
all (no redeploy run since it was delivered), which would look identical
from a live-site audit. To tell the two apart: check your Render
service's "Last Deploy" timestamp/commit against when you last received a
checkpoint ZIP. Newer than the ZIP → the flattening issue above is the
likely cause. Older/unchanged → it just hasn't been deployed yet, and
this note doesn't apply.

## 1b. 2026-09-24 pass — broken account "Letter" link + letter onboarding/personalisation

Nick reported: clicking "Letter" from his account gave a 404, and that
error page itself was largely unstyled (no nav/footer). Separately asked
for a first-time onboarding choice (personalise vs standard letter),
prefilling of known business details, and purchase-time handling for
contractors still on standard wording.

**Cause of the reported 404 — confirmed cause, not a guess, but with one
caveat stated plainly below.** Both places the dashboard/my-leads pages
render a "Letter" button (`contractor_dashboard`, `my_leads_view`) link
correctly to `/generate-letter/{buyer_facing_ref}` — traced and empirically
verified end-to-end (render the real dashboard HTML, extract the actual
href it produced, navigate it as the owning contractor — see
`tests/test_letter_onboarding.py::TestActualDashboardLinkNavigation`); this
route itself was not broken for the normal case. What WAS broken, and
squarely matches "404, largely unstyled nav/footer": `generate_homeowner_
letter` and `generate_street_flyer` (`/generate-letter/{id}`,
`/generate-street-flyer/{id}`) returned their own hand-rolled, completely
bare `HTMLResponse(...)` snippets — no nav, no footer, no branding at all —
for every one of their own internal error cases (DB error, lead not
found, lead not unlocked, address-not-releasable, missing server config),
instead of the `_branded_message_page` helper Nick already asked be used
sitewide back on 2026-09-16. All 8 of these (4 per route) now go through
that existing helper — same fix pattern as everywhere else on the site,
no redesign. **The caveat:** a direct code-level reproduction of the
mainline path returns 200, not literally 404, so this is the most
plausible explanation available from the code (a completely bare snippet
reads as "broken" to a non-technical viewer, close enough to be described
as a 404) rather than a byte-for-byte confirmed repro of that exact status
code. If it recurs after this fix is deployed, the one thing needed to go
further is the actual failing URL (not just "Letter" — the full
`/generate-letter/...` or `/generate-street-flyer/...` link, ideally from
the browser's address bar after the click) — see this pass's own final
report for the full reasoning.

**Also found and fixed while investigating (item 3, "never save or print
example business names, numbers or fictional credentials"):** both of
those same two routes had a genuine, separate defect — when a real,
logged-in contractor had no saved `contractor_letter_settings` row, they
fell straight through to the route's own query-string defaults
(`"Your Local Tree Specialists"` / `"Your Local Tree Surgery Team"` /
`"07XXX XXXXXX"`), rendered as if they were that contractor's real
business identity on an actual homeowner-facing letter/flyer. Fixed: such
a contractor is now redirected to `/letter-settings` to add their real
details, `next` carrying them straight back to the exact letter/flyer
they came from. The admin/no-session preview path (used by
`tests/test_address_release_gate.py`) is unchanged — it has no specific
contractor to misrepresent.

**Onboarding/personalisation (task items 2–5) — implemented, reusing the
existing setup→preview→approve pipeline throughout, not a new mechanism:**
- New `/letter-onboarding` page, offered once via `_login_session_response`
  the first time a contractor has no saved letter settings at all (and
  only when no `next`/checkout continuation is already pending — that
  case is left to the pre-existing checkout gate, unchanged, which already
  satisfies "preserve the original purchase destination"). Never repeats
  once a settings row exists — choosing either option still lands on the
  real `/letter-settings` form, which still requires an explicit Save,
  then Preview, then Approve (item 5: approval stays explicit; skipping
  personalisation is never silently treated as approval).
- `/letter-settings` now prefills business name/phone from whatever is
  already on file (`limbo_accounts.company_name`/`.phone`, or a
  subscriber's `.phone`) — **never** a subscriber's personal
  `customer_name` as a business name (task's explicit instruction).
  Every field now has a real example placeholder (`placeholder=`
  attribute only — never a submitted value).
- The purchase-time forced-setup banner (existing "Request E" gate) now
  reads "Add a personal introduction, or continue with your standard
  letter" once essential details are already saved, and the existing
  "Preview" link is relabelled "Continue with your standard letter" in
  that case — no new click is required, it just no longer reads as a
  mandatory rewrite.
- `/account`'s existing "Letter Template" status line now says
  "(standard wording)" or "(personalised wording)" once approved, based
  on whether `business_intro` is blank.

**UPDATE 2026-09-24, second pass — the gap above is now fixed, explicitly
authorised by Nick ("the purchase-time personalisation opportunity for
contractors who already have an approved standard letter... was part of
my original request").** `checkout()` (`GET /checkout/{plan_key}`, both
the single-lead-direct-to-Stripe branch and the subscription area-
selector branch) now shows a compact "Add a personal introduction, or
continue with your standard letter" choice screen the moment
`_letter_setup_complete` is true (approved, fingerprint-current) but
`business_intro` is still blank — before anything below that point ever
reserves a lead or talks to Stripe. Key properties, each with its own
test in `tests/test_letter_onboarding.py::TestPurchaseTimePersonalisationNudge`:
- **Read-only.** Rendering it never calls `upsert_contractor_settings` or
  `approve_template` — an unchanged approval is never touched, let alone
  invalidated, by seeing or dismissing it.
- **No duplicate reservation/Stripe session.** "Continue with your
  standard letter" is a link back to the exact same checkout URL plus one
  marker (`letter_nudge=continue`); the FIRST hit (showing the nudge)
  never reserves anything or calls Stripe, so the follow-up hit is a
  single, ordinary purchase, not a second one.
- **Already-personalised contractors are unaffected** — a non-blank
  `business_intro` skips this entirely, every time, "proceed normally".
- **Never asks the same question twice in a row.** `approve_letter_settings`'s
  own redirect back to a pending checkout `next` now carries the same
  dismiss marker — found by actually testing the brand-new-customer
  journey end to end (not just confirming the gate exists), since without
  this a buyer who just chose standard wording during the forced setup
  detour would see the identical prompt again one redirect later. See
  `tests/test_letter_onboarding.py::TestPurchaseTimePersonalisationNudge::
  test_approving_during_a_checkout_detour_does_not_immediately_reshow_the_nudge`.
- Fails OPEN on any lookup error (a UX nicety, never a second mailing
  gate — `_letter_setup_complete`, unchanged, is still the only real one).
`checkout_post` (the subscription POST submit) was not touched — a
contractor only reaches it after already passing through the GET above,
where the nudge is already resolved by then.

**Also found, NOT fixed, flagged for a separate decision:**
`generate_street_flyer` renders its own, entirely separate, hardcoded
neighbor-flyer copy — unconditionally, for every contractor, regardless of
what they've actually told TreeKey — including `"NPTC Certified • £5M
Insured"` and a `"20% Same-Day Street Discount"` offer. This never went
through `letter_content.py`'s governed template system at all and appears
to be the same class of problem as the fake business-name default just
fixed, only worse (a specific, invented certification and insurance
figure, and a discount no contractor was asked to confirm), but rewriting
this route's whole content model is a materially bigger, separate change
this pass did not attempt — flagging for explicit sign-off before any fix.

Tests: `tests/test_letter_onboarding.py` (new, 13 tests) plus updates to
`tests/test_access_control.py`'s two affected tests (the old tests
asserted the fake-default fallback as correct behaviour — that was the
bug; they now assert the fixed redirect behaviour). Full suite: 509/509
passing (`python -m unittest discover -s tests -v`, run 2026-09-24).

## 1c. 2026-09-24, later pass (Request D) — the "Letter" 404 root-caused and fixed; account/dashboard/my-leads link audit; street-flyer fabricated claims removed; error-page stylesheet gap fixed

**This section resolves both open flags 1b left above.**

**The 404 (1b's own stated caveat: "a direct code-level reproduction of
the mainline path returns 200, not literally 404... the one thing needed
to go further is the actual failing URL") — REPRODUCED AND FIXED, no
failing URL needed after all.** Root cause: a historical claim's
buyer-facing reference is the real council planning reference (e.g.
`"26/P/1118/S73"` — a real shape, taken verbatim from this codebase's own
`_SUSPECT_DISCHARGE_REFS_SEP11` constant, not invented for this test). The
links `main.py` builds via `urllib.parse.quote()` do NOT escape `/` by
default, and Starlette's default `{param}` route convertor cannot match a
path containing `/` — encoded or not (a percent-encoded `%2F` is decoded
back to `/` before route matching runs). So any historical buyer whose
council reference contains a `/` got a genuine 404 from the ROUTER
itself, before `generate_homeowner_letter`/`generate_street_flyer`/
`street_view_redirect` ever ran — which is exactly why 1b's styling fix
(fixing what those functions RETURN) could not have reproduced or fixed
it. Fixed: all three routes' decorators changed from `{param}` to the
`{param:path}` multi-segment convertor. Verified against the genuinely-
installed `starlette` package directly (FastAPI's `APIRoute` is an
unmodified subclass of `starlette.routing.Route`, so this is a faithful
proxy — `fastapi` itself cannot be installed in this sandbox, no PyPI
access here), via new `tests/test_slash_reference_routing.py` (10 tests,
extracting the actual decorator strings from `main.py`'s own source so it
can't silently drift). **Caveat, stated plainly:** verified against real
Starlette routing logic, not the actual installed FastAPI app end to end
(cannot run here at all) — see the completion checklist below.

**Street-flyer fabricated claims (1b: "Also found, NOT fixed, flagged for
a separate decision") — now fixed, per Nick's explicit instruction this
pass.** `"NPTC Certified • £5M Insured"` and the `"20% Same-Day Street
Discount"` offer are gone. The discount was removed outright (no
underlying real setting exists to condition it on, and inventing one
would be the same class of problem being fixed). The credentials line now
reuses the exact "never invented by TreeKey" mechanism
`letter_content.render_letter` already uses for the homeowner letter — a
contractor's own real, saved `insurance_note`/`qualifications_note`,
shown only when actually present. A separate, unrelated occurrence of a
similar claim on `boost_review_page` (a different route) was deliberately
left untouched — out of scope ("the separate street-flyer route" was
named specifically) — and flagged for Nick, not silently fixed or
ignored.

**Account/dashboard/my-leads link audit (new this pass).** `/account` was
already correct (no change needed). `/dashboard`, `/my-leads`, and
`/free-dashboard` all now distinguish historical (real address — genuine
"Letter" + "Street Flyer", unchanged) from a new allocation (redacted
address — "Preview Letter", never "Street Flyer" since that route is
structurally guaranteed to refuse a non-historical buyer, plus a new
honest mailing-status line from `fulfilment.get_letter_status_label_for_
lead_reference`, omitted rather than fabricated when no obligation row
exists yet).

**Error pages' shared styling (1b never actually diagnosed this — it
diagnosed the 404, not the "largely unstyled" half of the same report)
— root cause found and fixed.** `_branded_message_page`/`_branded_404_
handler`/`_branded_500_handler` all called the shared nav/footer helpers
but never linked `/static/tailwind.css` in their own `<head>` — so every
Tailwind class those helpers emit rendered bare. Fixed by adding the
missing `<link>` to all three.

Full detail, including the test-infrastructure gaps found and fixed while
building this pass's own tests, is in `ERROR_LOG.md`'s matching
2026-09-24 "Request D" entry (same date as 1b above — this is a later,
separate pass). Tests: `tests/test_slash_reference_routing.py` (10 new),
`tests/test_lead_action_links_and_flyer_claims.py` (17 new). **Full
suite: 542/542 passing** (`python3 -m unittest discover -s tests -p
"test_*.py"`, run 2026-09-24 — supersedes the 509/509 count at the end of
section 1b above, and the 290/290 count in Section 4 below, which predate
both 2026-09-24 passes and are kept only as historical record).

## 1d. 2026-09-24, later still pass (Request E) — marketplace privacy review for the mailed-introduction model: raw council reference removed from public URLs/links, a second independent leak fixed in subscriber alert emails, free-text redaction extended to reference/TPO patterns

**Nick's own framing drove the fix shape: "Encoding the raw reference is
not sufficient."** The raw council reference is the exact search key
someone could use on the council's own public planning portal to locate
the original application, address, and applicant — a URL-encoding or
routing fix (like 1c's `{param:path}` change, which only made
multi-segment references route correctly) does not address this; the
value itself has to stop being placed in public output.

**Confirmed leak #1 (public, unauthenticated) — fixed by swapping the
lookup key, not encoding it.** The marketplace detail route
(`/marketplace/lead/{reference}`) and every card link on `/marketplace`
both used the raw `leads.reference` directly, reachable with no login.
Both now use `leads.id` (a genuine `UUID PRIMARY KEY`, already used
safely in checkout links elsewhere in this codebase before this pass) as
the only lookup key. The council reference is still resolved internally,
server-side, wherever the app itself genuinely needs it (letter
generation, fulfilment, admin tooling) — it is simply never again placed
in a URL, href, or query string.

**Confirmed leak #2 (found during this pass's own audit, not on Nick's
"known concerns" list) — also a live functional bug, now fixed.** The
subscriber lead-alert email's "Unlock" checkout link
(`notifications.dispatch_lead_alerts`) used the same raw reference. This
email path (a direct `requests.post` to the contractor's own address) is
genuinely customer-facing — confirmed by first ruling out the OTHER two
branches of that same function, which route through
`send_resend_email` and only ever deliver to a fixed internal test
address. Independently, `payments._resolve_live_single_lead_price`
looks leads up by `id`, never by reference — so the raw-reference link
could never have resolved a real checkout anyway; this was a real,
previously broken "Unlock" button for every subscribed contractor, not a
theoretical concern. Fixed the same way: the link now uses the lead's
`id`.

**Regex redaction gap (named directly in Nick's "known concerns") —
extended, not claimed as a guarantee.** `database.
_redact_address_from_summary` redacted postcodes and street addresses
but never a TPO number or council reference appearing inline in
free-text summaries. Two new patterns added (TPO-number shape;
multi-segment alphanumeric reference shape, with a letter-required
lookahead specifically so plain dates/fractions are never
false-positived), verified against real reference examples already in
this codebase and against known non-matches. **Stated plainly, matching
the instruction's own caution:** this closes the specific pattern gap
flagged, it is not offered as a guarantee — Nick's own preferred
long-term approach (a structured summary built from reliably available,
approved non-identifying fields, omitting anything that can't be safely
produced) remains the stronger fix and is unchanged by this pass.

**Broad sweep against the instruction's own inspection list (HTML, URLs,
query strings, data attributes, embedded JSON, API responses, emails,
PDFs, previews, downloads, maps, search metadata) — all confirmed already
safe by direct source inspection, no change needed:** homepage ticker,
`/api/check-postcode`, the Leaflet map, `sitemap.xml`/`robots.txt`,
JSON-LD structured data, `applicant_name` exposure, `/street-view/`
gating, and letter-PDF generation.

**Flagged, not fixed — out of scope for a privacy review.**
`/generate-storm-quote/{lead_id}` carries the same fabricated-credentials
text already fixed for the street flyer in 1c and still open for
`boost_review_page` — a third occurrence of that pattern, named for
visibility only; this is a fabricated-claims issue, not an
identifier/privacy issue.

Full detail in `ERROR_LOG.md`'s matching 2026-09-24 "Request E" entry and
`docs/operator_guide.md` section 20. Tests: new
`tests/test_marketplace_privacy_review.py` (20 new). **Full suite:
562/562 passing** (`python3 -m unittest discover -s tests -p
"test_*.py"`, run 2026-09-24 — supersedes the 542/542 count at the end of
section 1c above, which is kept only as historical record). Nothing
deployed; no retention, provider, pricing, or live-sending setting
changed.

## 2. Completed items — ALL SIX (implemented + tested)

- **Item 1** — Contractor setup / letter-preview / reusable-template-approval
  UI with auth/ownership/fingerprint checks, plus a fake-provider end-to-end
  customer-journey test.
- **Item 2** — `ADDRESS_RELEASE_LIVE` review. Historical purchase access is
  preserved unconditionally. New-allocation eligibility now requires BOTH an
  explicit per-`lead_reference` operator decision (new
  `address_disclosure_decisions` table, via `address_release.py`) AND the
  global `ADDRESS_RELEASE_LIVE` flag as an additional control. No automatic
  eligibility inference exists anywhere — the actual legal release trigger
  is deliberately left unresolved/configurable (see Section 6 below).
  - Also fixed a real, previously-undetected test-infrastructure bug: a
    cross-module `sys.modules["database"]` identity desync that let some
    pre-existing "enabled" tests pass without exercising their logic under
    full-suite `unittest discover`. Fix: `address_release.py` now binds
    `database` at module level (not per-call), matching how `main.py` binds
    it. See inline comments in `address_release.py` and
    `tests/test_address_release_gate.py` for the full explanation.
- **Item 3** — Public letter-posting promise (`fulfilment.letter_sending_live()`)
  now requires ALL THREE of: `LETTER_SENDING_LIVE` flag, correct pipeline
  (`active_pipeline() == "fulfilment"`), AND a real, enabled, configured
  provider (not `fake_test`) via `letter_providers.registry`. All invalid
  combinations are tested in
  `tests/test_letter_promise_gate.py::TestInvalidConfigurationCombinationsLeavePromiseOff`
  (7 tests) plus one positive control.
- **Item 4** — Payment/allocation reconciliation for the
  successful-payment→DB-failure→delayed-retry-after-reservation-expiry
  scenario:
  - `database.has_unresolved_payment_reconciliation_issue()` — durable-identity
    check by `stripe_event_id` OR `stripe_reference` against
    `payment_allocation_reconciliation WHERE resolved = FALSE`. Fails SAFE to
    `True` (opposite of most read helpers in this codebase) on any DB error
    or missing `DATABASE_URL`, so an unanswerable check never permits an
    automatic refund.
  - `fulfilment.has_unresolved_reconciliation_issue()` — thin DB-cursor
    wrapper around the same check, used inside a single transaction.
  - `payments.py`'s `handle_stripe_webhook` now checks this BEFORE falling
    through to the auto-refund branch, so a delayed retry after the
    reservation has already expired is recognized and left retryable
    (`{"retry": True}`, event NOT marked fulfilled, no refund issued)
    instead of silently refunding a payment that may still be fulfillable.
  - Reconciliation-record-write failure during a DB outage is also covered:
    if `record_payment_reconciliation_issue` itself returns `None` (its own
    write failed), the webhook still returns retryable and still does not
    mark the event fulfilled.
  - Tests: `tests/test_payments_webhook.py` (new classes
    `TestDelayedRetryAfterReservationExpiryReconcilesByDurableIdentity`,
    `TestReconciliationCheckItselfFailsDuringOutage`,
    `TestReconciliationRecordWriteFailsDuringOutage`),
    `tests/test_fulfilment.py::TestHasUnresolvedReconciliationIssue`,
    `tests/test_reconciliation.py::TestHasUnresolvedPaymentReconciliationIssueWrapper`.
- **Item 5 — CLOSED 2026-09-22** (was the one outstanding item as of the
  2026-09-18 checkpoint). `tests/postgres_concurrency/run_concurrency_tests.py`
  starts a real, disposable, local PostgreSQL 16 server, applies the actual
  `migrations/0001_letter_fulfilment.sql` file verbatim, and drives the exact
  SQL from `FundingGate.reserve()` and `claim_for_submission()` through
  concurrent `psql` subprocesses (kept as a standalone script, not part of
  `unittest discover`, because `psycopg2`/`psycopg` cannot be installed in
  this sandbox — see `tests/postgres_concurrency/README.md`). **5/5
  scenarios passing**, run twice in a row for reliability: (1) simultaneous
  workers racing for a budget that can only cover one of them; (2) a single
  worker requesting more than is available from the start; (3) a
  reservation whose transaction is rolled back; (4) an `'unknown'` provider
  outcome, verified to leave the reservation genuinely held; (5) two workers
  racing to claim the same `'ready'` obligation. Full detail in
  `docs/launch_checklist.md` item 6a and `tests/postgres_concurrency/README.md`.
- **Item 6** — Verified worker scheduling/entry points are genuinely invoked
  (not just defined) and documented local/deployed startup without
  deploying. See `app/worker.py`, `app/worker_runner.py`, and
  `docs/operator_guide.md`.

All of the above is documented in `docs/operator_guide.md` (sections 7a, 8,
9, 10) and `docs/launch_checklist.md` (items 2a, 5, 6, 6a).

## 3. Incomplete items / partially-edited code

**None.** As of 2026-09-22, every item from the original governing task is
implemented and tested. There is no half-finished edit anywhere in the
repo — confirmed via `ast.parse` across every `.py` file (zero syntax
errors) and a full passing test run (below).

The genuine scope boundaries that remain (not incomplete work, but
deliberately out of reach of this sandbox or deliberately left to a human)
are listed in Section 6 below (config defaults / outstanding decisions) and
in Section 8 (verified vs. assumed).

## 4. Last tests actually run, results, and changes since

- **Last full unit-test run**: `python3 -m unittest discover -s tests -p "test_*.py"`
  from `/home/claude/treekey_work/app` → **290/290 passing, "OK"** (same
  count as the 2026-09-18 checkpoint — Item 5's new work is a standalone
  script, not part of this suite, so it doesn't change this number).
- **Last PostgreSQL concurrency run**: `python3 tests/postgres_concurrency/run_concurrency_tests.py`
  → **5/5 scenarios passing**, run twice in a row on 2026-09-22 for
  reliability. Confirmed no postgres process and no leftover temp directory
  after each run.
- **Changes made since the last full-suite run**: documentation-only edits
  to `docs/launch_checklist.md` and `docs/operator_guide.md` (Item 5's
  write-up). No `.py` file was touched after the last full-suite run that
  produced 290/290 — that run was re-verified as the final action of this
  phase, alongside a full `ast.parse` sweep, both clean. The checkpoint ZIP
  reflects exactly this verified state.
- No adversarial/manually-reordered test invocation issues affect this
  state: a manually reordered invocation was tried in an earlier phase and
  showed 7 unrelated failures, root-caused to pre-existing test-infra
  fragility unrelated to this work, confirmed NOT present under the real
  alphabetical `unittest discover` run, and logged as explicitly out of
  scope (see `docs/launch_checklist.md` item 12 precedent).

## 5. Exact commands to reproduce the last verified state

```bash
cd /home/claude/treekey_work/app

# Full mocked unit-test suite (no external dependencies, runs in well under 1s)
python3 -m unittest discover -s tests -p "test_*.py"

# Real-PostgreSQL concurrency integration tests (Item 5) -- requires a local
# PostgreSQL 16 server + a non-root OS user to run it as (defaults to
# 'claude'); starts and fully tears down its own disposable server, never
# touches a real database. Exit code 2 (not a failure) if Postgres isn't
# available in the environment -- see that script's own docstring.
python3 tests/postgres_concurrency/run_concurrency_tests.py

# Syntax sweep
find . -name "*.py" -not -path "*/__pycache__/*" \
  -exec python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" {} \;
```

### If further payment-recovery verification is wanted (Item 4, beyond scope)

Item 4's core implementation and unit tests are complete (Section 2). What
remains is verification beyond what this sandbox can reach — not scoped as
required by the original task, but worth naming:

- Real Stripe test-mode webhook retry timing (this sandbox only simulates
  retries by calling the webhook handler twice in-process; it never talks
  to a real or sandboxed Stripe).
- The actual post-3-day admin reconciliation process referenced in
  `docs/launch_checklist.md` item 2a — a process/ops gap, not code.

## 6. Configuration defaults and outstanding provider/legal decisions

### Defaults (fail-safe / dry-run unless explicitly overridden)
- `LETTER_DISPATCH_PIPELINE` — defaults to `legacy` (NOT `fulfilment`).
- `LETTER_SENDING_LIVE` — defaults unset/false.
- `ADDRESS_RELEASE_LIVE` — defaults unset/false.
- `FUNDING_MODE` — defaults to `hold`.
- All `LETTER_PROVIDER_PRIMARY` / `_BACKUP_1` / `_BACKUP_2` slots — default
  unconfigured/disabled. See `.env.example.letter-fulfilment` for the full
  set of recognized environment variables and their safe defaults.

### Outstanding decisions this work explicitly did NOT make up
- No real postal provider account or credentials exist anywhere in this
  repo or environment. Stannp is used only as an illustrative/placeholder
  adapter name and has never been verified against a live API.
- The exact legal/Article-14 disclosure-timing trigger for address release
  was deliberately left unresolved and configurable (per the original
  instruction not to invent this) — requires a UK data-protection adviser's
  sign-off before `ADDRESS_RELEASE_LIVE` is ever set true in a real
  environment.
- Whether funding reconciliation should ever become automated vs. remaining
  a manual `confirm_budget` action is undecided.
- Policy for unsold leads is undecided.

## 7. Confirmation: nothing was deployed, charged, or posted

Throughout this entire body of work, including the 2026-09-22 resumption:
- **No deployment** occurred. No production migrations were run. No
  production records were modified.
- **No real charge** was made. No paid provider account was created.
- **No real letter** was sent or posted. All provider integrations remain
  in `fake_test` / dry-run mode by default, and the live-sending gate
  (Item 3) requires three independent conditions to all be true before any
  real send could occur — none of which are true in this checkpoint's
  default configuration.
- The PostgreSQL instances started during this work (once during Item 5's
  original research, and again by `run_concurrency_tests.py` during its
  test runs) were each disposable, local, self-created, and fully stopped
  and deleted afterward — confirmed by hand each time. Nothing is running.
- `run_concurrency_tests.py` itself never reads `DATABASE_URL` /
  `SUPABASE_DB_URL` or any variable that could point at a real database —
  see that script's own module docstring.

## 8. Distinguishing verified results from assumptions

**Verified this work** (directly observed via tool output):
- 290/290 unit tests passing under `python3 -m unittest discover -s tests -p "test_*.py"`.
- 5/5 PostgreSQL concurrency scenarios passing, run twice in a row, under
  `python3 tests/postgres_concurrency/run_concurrency_tests.py`.
- `ast.parse` clean (no syntax errors) across every `.py` file in the repo.
- The checkpoint ZIPs are valid (`unzip -t` reported no errors).
- Both prior checkpoint ZIPs (2026-09-18) were confirmed untouched
  (unchanged size/timestamp) after this phase's edits.
- PostgreSQL 16 can be started as the non-root `claude` user in this
  sandbox; `psycopg2`/`psycopg` cannot be installed via pip or apt here
  (both attempts failed with explicit, observed errors).
- No postgres process or leftover temp directory remained after any run of
  `run_concurrency_tests.py` (checked by hand each time).

**Assumptions / not verified** (stated as such, not fact):
- `run_concurrency_tests.py` proves the *SQL's* locking discipline is sound
  under real concurrency. It does not, and cannot from this sandbox, prove
  the full Python call path (`FundingGate.reserve()` itself, calling
  through a real `psycopg2` connection) behaves identically, since that
  library could not be installed here. The existing mocked unit tests
  cover that the Python glue calls the right SQL in the right order; this
  is the one remaining gap, stated plainly rather than papered over.
- Real Stripe webhook retry timing/behaviour matches what the in-process
  simulated double-delivery tests assume.
- Whether the existing `letter_providers.registry` code would work against
  a real Stannp (or other) account — never tested against a live API by
  design (no paid account exists, and creating one is out of scope).

## 9. Where the checkpoint files are

- **Latest implementation ZIP** (2026-09-22, includes the closed-out Item 5
  work — does NOT overwrite either earlier checkpoint):
  `/mnt/user-data/outputs/treekey_letter_fulfilment_implementation_20260922T151929Z.zip`
- **Previous checkpoint ZIP** (2026-09-18, end of that phase, untouched):
  `/mnt/user-data/outputs/treekey_letter_fulfilment_implementation_20260918T215016Z.zip`
- **Earliest checkpoint ZIP** (predates both of the above, untouched):
  `/mnt/user-data/outputs/treekey_letter_fulfilment_implementation.zip`
- **This file**: `/home/claude/treekey_work/app/START_HERE.md`

## 10. What remains after this checkpoint

- The final 3-tier completion report (Implemented+tested /
  Implemented+awaiting verification / External decisions) covering all 6
  original items has now been produced and delivered in the conversation
  itself (2026-09-22), alongside this file.
- Nothing else from the original governing task is outstanding. Section 6
  above lists the genuine external decisions (provider account, legal
  sign-off, funding-automation policy, unsold-lead policy) that were never
  this session's to make.
