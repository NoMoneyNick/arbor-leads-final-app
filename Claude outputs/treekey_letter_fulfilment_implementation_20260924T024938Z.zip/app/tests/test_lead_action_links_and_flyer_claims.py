"""
test_lead_action_links_and_flyer_claims.py -- 2026-09-24 handoff.

Nick's task: "Inspect actual account/dashboard/my-leads links and
distinguish: Letter Settings; fictional template preview; historical
per-lead letter; street flyer. For new mailed-introduction purchases,
replace misleading old actions with the appropriate template preview or
mailing-status action. Do not offer address-dependent tools that the
customer cannot legitimately use." Also: "Remove unconditional claims from
the separate street-flyer route: 'NPTC Certified', '£5M Insured' and '20%
Same-Day Street Discount'."

Covers:
  1. my_leads_view / contractor_dashboard / free_dashboard: a NEW
     allocation's card shows "Preview Letter" (never the old "Letter"
     label, which implied this is the actual posted letter), never offers
     "Street Flyer" at all (lead_address_release_allowed is structurally
     False for anything but a historical claim -- offering it would always
     404/403), and shows an honest mailing-status line when one is on
     record. A HISTORICAL claim is untouched -- both "Letter" and "Street
     Flyer" still work exactly as before (real address, both routes
     genuinely usable).
  2. fulfilment.get_letter_status_label_for_lead_reference: the status
     mapping in isolation, including the is_dry_run override and the
     fail-toward-None posture on a missing row or a DB error.
  3. generate_street_flyer: the old hardcoded "NPTC Certified", "£5M
     Insured" and "20% Same-Day Street Discount" claims never render for
     any contractor, a contractor's own real, saved insurance/
     qualifications notes DO render (reusing the exact mechanism
     letter_content.render_letter already uses for the homeowner letter),
     and a contractor with neither saved just gets no credentials line at
     all -- never a fabricated one.

Run with:
    python -m unittest tests.test_lead_action_links_and_flyer_claims -v
"""
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_DIR = os.path.dirname(_THIS_DIR)
sys.path.insert(0, _APP_DIR)
sys.path.insert(0, _THIS_DIR)

# Reuses the established fastapi/database/notifications stubbing chain --
# see test_indirect_identifier_gating.py's own import comment for exactly
# what this pulls in and why importing it (rather than duplicating ~150
# lines of stub setup) is this codebase's own convention.
import test_indirect_identifier_gating as _tiig  # noqa: E402
import main  # noqa: E402
import fulfilment  # noqa: E402
import address_release  # noqa: E402
import letter_content  # noqa: E402

_ensure_database_stub_has_dashboard_attrs = _tiig._ensure_database_stub_has_dashboard_attrs
_ensure_shared_notifications_stub_has_dashboard_attrs = _tiig._ensure_shared_notifications_stub_has_dashboard_attrs


class _CapturingHTMLResponse:
    """The shared fastapi stub's HTMLResponse (test_main.py's own
    _FakeHTMLResponse, which this whole chain's sys.modules["fastapi.
    responses"] resolves to) discards every constructor argument -- `def
    __init__(self, *a, **k): pass` -- including the rendered content
    itself. That's harmless for routes tests only assert_called_with on,
    but my_leads_view and free_dashboard both `return HTMLResponse(f"\"\"...
    \"\"\")` (unlike contractor_dashboard/generate_homeowner_letter/
    generate_street_flyer, which return bare f-strings), so this codebase's
    established `body = response if isinstance(response, str) else
    getattr(response, "body", str(response))` extraction pattern silently
    got the object's repr instead of real HTML for those two. Patching
    main.HTMLResponse to this capturing fake -- only for the tests that
    need it -- stores the positional `content` arg as `.body`, matching
    the attribute name real starlette.responses.HTMLResponse exposes, so
    that same established extraction pattern works here too. No production
    code changes; this is a test-only fix for a pre-existing stub gap that
    no earlier test happened to hit."""
    def __init__(self, content="", status_code=200, **kwargs):
        self.body = content
        self.status_code = status_code
        self._cookies = {}

    def set_cookie(self, key=None, value=None, *a, **k):
        self._cookies[key] = value


def _lead(ref="PLANIT-NEW-001", addr="1 Real Street, Leeds"):
    return {
        "id": "lead-uuid-1", "ref": ref, "addr": addr,
        "summary": "Fell one oak", "council": "Leeds City Council", "score": "small",
        "price": 25, "dispatched_at": "2026-09-20 10:00", "registered_date": None,
        "applicant_name": "Jane Homeowner", "has_agent": None,
    }


class _DashboardTestBase(unittest.TestCase):
    def setUp(self):
        os.environ["SESSION_SECRET"] = "test-session-secret"
        main._SESSION_SECRET = b"test-session-secret"
        _ensure_database_stub_has_dashboard_attrs()
        _ensure_shared_notifications_stub_has_dashboard_attrs()

    def _request(self, email="contractor@example.com"):
        request = MagicMock()
        request.cookies = {"treekey_contractor_session": main._sign_session_cookie(email)}
        return request


class TestMyLeadsViewNewAllocation(_DashboardTestBase):

    @patch("main.HTMLResponse", _CapturingHTMLResponse)
    @patch("fulfilment.get_letter_status_label_for_lead_reference", return_value="Preparing to post")
    @patch("main.database.get_db_conn")
    @patch("main.database.get_contractor_settings")
    @patch("main.database.get_contractor_dashboard_data")
    @patch("main.database.get_contractor_subscription")
    def test_new_allocation_shows_preview_letter_no_street_flyer_and_a_status_line(
        self, mock_sub, mock_dash_data, mock_settings, mock_get_conn, mock_status
    ):
        mock_sub.return_value = {"active": True}
        mock_dash_data.return_value = {"dispatched_leads": [_lead()]}
        mock_settings.return_value = {"notification_preference": "email"}
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.return_value = ("alloc-id-999",)  # every address_release call -> "new allocation"
        conn.cursor.return_value = cur
        mock_get_conn.return_value = conn

        response = main.my_leads_view(self._request())
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn("Preview Letter", body)
        self.assertNotIn(">Letter<", body)
        self.assertNotIn("Street Flyer", body)
        self.assertIn("Mailed introduction:", body)
        self.assertIn("Preparing to post", body)

    @patch("main.HTMLResponse", _CapturingHTMLResponse)
    @patch("main.database.get_db_conn")
    @patch("main.database.get_contractor_settings")
    @patch("main.database.get_contractor_dashboard_data")
    @patch("main.database.get_contractor_subscription")
    def test_new_allocation_with_no_obligation_on_record_shows_no_status_line(
        self, mock_sub, mock_dash_data, mock_settings, mock_get_conn
    ):
        """fulfilment.get_letter_status_label_for_lead_reference itself
        opens its own DB connection (database.get_db_conn(), patched here
        too via the same mock) and, given this test's blanket 1-tuple
        return_value, fails its own unpack safely and returns None -- the
        status line must be omitted entirely, never a fabricated one."""
        mock_sub.return_value = {"active": True}
        mock_dash_data.return_value = {"dispatched_leads": [_lead()]}
        mock_settings.return_value = {"notification_preference": "email"}
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.return_value = ("alloc-id-999",)
        conn.cursor.return_value = cur
        mock_get_conn.return_value = conn

        response = main.my_leads_view(self._request())
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn("Preview Letter", body)
        self.assertNotIn("Mailed introduction:", body)


class TestMyLeadsViewHistorical(_DashboardTestBase):

    @patch("main.HTMLResponse", _CapturingHTMLResponse)
    @patch("main.database.get_db_conn")
    @patch("main.database.get_contractor_settings")
    @patch("main.database.get_contractor_dashboard_data")
    @patch("main.database.get_contractor_subscription")
    def test_historical_claim_keeps_the_real_letter_and_street_flyer_buttons(
        self, mock_sub, mock_dash_data, mock_settings, mock_get_conn
    ):
        mock_sub.return_value = {"active": True}
        mock_dash_data.return_value = {"dispatched_leads": [_lead()]}
        mock_settings.return_value = {"notification_preference": "email"}
        conn = MagicMock()
        cur = MagicMock()
        # Four address_release calls in the loop (addr, buyer_ref, summary,
        # applicant_name), each its own is_historical_purchase check:
        # lead_allocations miss (None), letter_dispatches hit ((1,)) ->
        # historical. buyer_facing_reference's historical branch takes the
        # early return (no extra query) -- exactly 2 fetchones per call.
        cur.fetchone.side_effect = [None, (1,)] * 4
        conn.cursor.return_value = cur
        mock_get_conn.return_value = conn

        response = main.my_leads_view(self._request())
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn(">Letter<", body)
        self.assertIn("Street Flyer", body)
        self.assertNotIn("Preview Letter", body)


class TestContractorDashboardNewAllocation(_DashboardTestBase):

    @patch("fulfilment.get_letter_status_label_for_lead_reference", return_value="Posted")
    @patch("main.database.get_db_conn")
    @patch("main.database.get_contractor_settings")
    @patch("main.database.get_contractor_dashboard_data")
    def test_new_allocation_shows_preview_letter_no_street_flyer_and_a_status_line(
        self, mock_dash_data, mock_settings, mock_get_conn, mock_status
    ):
        mock_dash_data.return_value = {"subscription": {"active": True, "tier": "pro"}, "dispatched_leads": [_lead()]}
        mock_settings.return_value = {"notification_preference": "email"}
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.return_value = ("alloc-id-999",)
        conn.cursor.return_value = cur
        mock_get_conn.return_value = conn

        response = main.contractor_dashboard(self._request())
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn("Preview Letter", body)
        self.assertNotIn(">Letter<", body)
        self.assertNotIn("Street Flyer", body)
        self.assertIn("Mailed introduction:", body)
        self.assertIn("Posted", body)


class TestContractorDashboardHistorical(_DashboardTestBase):

    @patch("main.database.get_db_conn")
    @patch("main.database.get_contractor_settings")
    @patch("main.database.get_contractor_dashboard_data")
    def test_historical_claim_keeps_the_real_letter_and_street_flyer_buttons(
        self, mock_dash_data, mock_settings, mock_get_conn
    ):
        mock_dash_data.return_value = {"subscription": {"active": True, "tier": "pro"}, "dispatched_leads": [_lead()]}
        mock_settings.return_value = {"notification_preference": "email"}
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.side_effect = [None, (1,)] * 4
        conn.cursor.return_value = cur
        mock_get_conn.return_value = conn

        response = main.contractor_dashboard(self._request())
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn(">Letter<", body)
        self.assertIn("Street Flyer", body)
        self.assertNotIn("Preview Letter", body)


class TestFreeDashboardToolCards(_DashboardTestBase):

    @patch("main.HTMLResponse", _CapturingHTMLResponse)
    @patch("fulfilment.get_letter_status_label_for_lead_reference", return_value=None)
    @patch("main.database.get_db_conn")
    @patch("main.database.get_contractor_settings")
    @patch("main.database.get_limbo_account")
    def test_free_lead_shows_preview_letter_and_never_street_flyer(
        self, mock_limbo, mock_settings, mock_get_conn, mock_status
    ):
        mock_limbo.return_value = {"free_lead_ref": "PLANIT-FREE-001", "customer_name": None, "signed_up_at": None}
        mock_settings.return_value = {"notification_preference": "email"}
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.return_value = ("alloc-id-777",)
        conn.cursor.return_value = cur
        mock_get_conn.return_value = conn

        with patch("main.database.get_lead_by_reference", return_value={
            "reference": "PLANIT-FREE-001", "address": "1 Real Street, Leeds", "summary": "Fell one oak",
            "council_source": "Leeds City Council", "registered_date": None,
        }):
            response = main.free_dashboard(self._request())
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn("Preview Intro Letter", body)
        self.assertNotIn("Street Flyer", body)


class TestLetterStatusLabelForLeadReference(unittest.TestCase):
    """fulfilment.get_letter_status_label_for_lead_reference in isolation.

    NOTE on `create=True` (found chasing a full-suite-only failure, same
    class of bug test_magic_link_credential_exposure.py's own NOTE already
    documents): fulfilment.py has no top-level `import database` -- it
    can't, database.py itself does `import fulfilment` at ITS top level
    (see database.py line ~15), so a top-level import here would be a
    genuine circular import, not just a test inconvenience. This function
    therefore does a plain `import database` INSIDE its own body, which
    means it re-resolves sys.modules["database"] fresh on every call --
    unlike main.py's own `import database` (bound once, at main's first
    import) or address_release.py's. Under `unittest discover`,
    tests/test_letter_promise_gate.py unconditionally dels and replaces
    sys.modules["database"] with a bare, attribute-less module at ITS OWN
    collection time (its own comment explains why that's safe for main.py/
    address_release.py specifically, since those bind "database" once and
    never look at sys.modules again) -- and because discover() finishes
    importing every test file before running any of them, that bare
    replacement is already in place by the time these tests actually run,
    regardless of file order. patch("database.get_db_conn", ...) needs the
    attribute to already exist on whatever sys.modules["database"] holds
    AT PATCH TIME to work without `create=True` -- it didn't, hence
    `AttributeError: <module 'database'> does not have the attribute
    'get_db_conn'` under the full suite despite this file passing every
    time it was run standalone. `create=True` is the correct fix here
    (rather than patching a bound reference like main.database, which
    fulfilment's fresh per-call import does not use)."""

    def _with_row(self, status, is_dry_run):
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.return_value = (status, is_dry_run)
        conn.cursor.return_value = cur
        return conn

    def test_empty_reference_short_circuits(self):
        self.assertIsNone(fulfilment.get_letter_status_label_for_lead_reference(""))

    def test_no_row_returns_none(self):
        conn = MagicMock()
        cur = MagicMock()
        cur.fetchone.return_value = None
        conn.cursor.return_value = cur
        with patch("database.get_db_conn", return_value=conn, create=True):
            self.assertIsNone(fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"))

    def test_db_error_fails_toward_none_not_a_crash(self):
        with patch("database.get_db_conn", side_effect=RuntimeError("db down"), create=True):
            self.assertIsNone(fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"))

    def test_dispatched_and_not_dry_run_is_posted(self):
        conn = self._with_row("dispatched", False)
        with patch("database.get_db_conn", return_value=conn, create=True):
            self.assertEqual(fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"), "Posted")

    def test_dry_run_never_claims_posted_even_if_status_says_dispatched(self):
        conn = self._with_row("dispatched", True)
        with patch("database.get_db_conn", return_value=conn, create=True):
            self.assertEqual(fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"), "Preparing to post")

    def test_provider_accepted_maps_to_being_printed_and_posted(self):
        conn = self._with_row("provider_accepted", False)
        with patch("database.get_db_conn", return_value=conn, create=True):
            self.assertEqual(fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"), "Being printed & posted")

    def test_failed_maps_to_an_honest_issue_message(self):
        conn = self._with_row("failed", False)
        with patch("database.get_db_conn", return_value=conn, create=True):
            self.assertEqual(
                fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"), "Issue detected -- contact support"
            )

    def test_suppressed_maps_to_on_hold(self):
        conn = self._with_row("suppressed", False)
        with patch("database.get_db_conn", return_value=conn, create=True):
            self.assertEqual(fulfilment.get_letter_status_label_for_lead_reference("PLANIT-1"), "On hold")


class TestStreetFlyerRemovesUnconditionalClaims(unittest.TestCase):
    """generate_street_flyer no longer shows a hardcoded credential/discount
    claim for every contractor -- see main.py's own 2026-09-24 comment."""

    def _base_cur_side_effect(self, settings_row):
        return [
            None,  # resolve_buyer_facing_reference miss -> use as-is
            ("PLANIT-001", "1 Real Street, Leeds, LS1 1AA", "Fell one oak", "claimed"),
            settings_row,
        ]

    def test_no_saved_settings_shows_no_credentials_line_and_no_discount(self):
        cur = MagicMock()
        cur.fetchone.side_effect = self._base_cur_side_effect(None)
        conn = MagicMock()
        conn.cursor.return_value = cur
        request = MagicMock()
        request.cookies = {}
        # require_lead_ownership (called unconditionally, before any of the
        # claims-removal logic runs) 404s for a request with no session
        # UNLESS _admin_basic_auth_ok(request) is True -- see its docstring
        # ("Admin ... always passes"). Mocking fulfilment.get_lead_owner
        # alone (this test's original approach) never reaches that: the
        # function raises on the "no session" branch before get_lead_owner
        # is ever called. Patching _admin_basic_auth_ok directly is the
        # correct way to simulate the anonymous/admin preview path this
        # test is actually about.
        with patch("main.database.get_db_conn", return_value=conn), \
             patch("main._admin_basic_auth_ok", return_value=True), \
             patch("main.address_release.lead_address_release_allowed", return_value=True), \
             patch("main._verify_session_cookie", return_value=None):
            response = main.generate_street_flyer(request, "PLANIT-001")
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertNotIn("NPTC Certified", body)
        self.assertNotIn("£5M Insured", body)
        self.assertNotIn("Same-Day Street Discount", body)
        self.assertNotIn("20%", body)

    def test_a_contractors_own_real_saved_insurance_note_renders_instead(self):
        settings_row = (
            "contractor@example.com", "Ashcroft Tree Surgery", "01234 567890", "",
            "Fully insured up to £2M, NPTC certified crew", "City & Guilds NPTC Level 3",
            1, True, "fp", "friendly_introduction", "", "", "",
        )
        cur = MagicMock()
        cur.fetchone.side_effect = self._base_cur_side_effect(settings_row)
        conn = MagicMock()
        conn.cursor.return_value = cur
        request = MagicMock()
        request.cookies = {"treekey_contractor_session": main._sign_session_cookie("contractor@example.com")}
        with patch("main.database.get_db_conn", return_value=conn), \
             patch("main.fulfilment.get_lead_owner", return_value="contractor@example.com"), \
             patch("main.address_release.lead_address_release_allowed", return_value=True):
            response = main.generate_street_flyer(request, "PLANIT-001")
        body = response if isinstance(response, str) else getattr(response, "body", str(response))

        self.assertIn("Fully insured up to £2M, NPTC certified crew", body)
        self.assertIn("City &amp; Guilds NPTC Level 3", body)
        self.assertNotIn("NPTC Certified • £5M Insured", body)
        self.assertNotIn("Same-Day Street Discount", body)

    def test_title_no_longer_promises_a_discount(self):
        cur = MagicMock()
        cur.fetchone.side_effect = self._base_cur_side_effect(None)
        conn = MagicMock()
        conn.cursor.return_value = cur
        request = MagicMock()
        request.cookies = {}
        # See test_no_saved_settings_shows_no_credentials_line_and_no_discount
        # above for why _admin_basic_auth_ok (not get_lead_owner) is the
        # correct thing to patch here.
        with patch("main.database.get_db_conn", return_value=conn), \
             patch("main._admin_basic_auth_ok", return_value=True), \
             patch("main.address_release.lead_address_release_allowed", return_value=True), \
             patch("main._verify_session_cookie", return_value=None):
            response = main.generate_street_flyer(request, "PLANIT-001")
        body = response if isinstance(response, str) else getattr(response, "body", str(response))
        self.assertIn("Neighbor Street Notice |", body)
        self.assertNotIn("Neighbor Street Notice & Discount", body)


if __name__ == "__main__":
    unittest.main()
