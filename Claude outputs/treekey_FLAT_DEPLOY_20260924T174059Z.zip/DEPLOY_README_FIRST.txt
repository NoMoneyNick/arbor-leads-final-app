TREEKEY -- FLAT DEPLOYMENT PACKAGE
Built: 2026-09-24T17:40:59Z (matches ZIP filename timestamp)

WHAT THIS IS
Every file in this ZIP sits at the ZIP's root -- there is NO "app/" wrapper
folder this time. Copy these files/folders directly into:

    C:\Users\twobo\Projects\VECTOR DATA LABS

...overwriting any file with the same name. Do NOT copy them into a new
"app" subfolder -- that was the earlier source of confusion.

THIS IS AN OVERLAY, NOT A FULL COPY OF YOUR PROJECT
This package contains only the files this engagement has touched or added
(the letter-fulfilment feature and everything built on top of it). It does
NOT include every file your live project has. Two files main.py imports
that are NOT in this ZIP and were NEVER part of this engagement's working
copy:

  - scanners.py   -- confirmed to exist in your original project upload,
                      just never part of this session's working files.
  - research.py   -- NOT seen anywhere in this session at any point. I
                      cannot confirm this file exists in your live project.
                      If it doesn't, main.py will fail to start
                      (ImportError) the moment it's deployed.

BEFORE YOU DEPLOY: confirm both files already exist in
C:\Users\twobo\Projects\VECTOR DATA LABS. Do not delete or skip them --
this ZIP does not replace them, it assumes they're already there.

Every other file main.py/database.py/etc. import from this same project
(payments, fulfilment, worker, letter_content, address_release,
suppression, funding, notifications, net_utils, scraper_resilience,
retention_dispatch_purge, letter_providers/, worker_runner.py) IS included
in this ZIP.

WHAT ELSE THIS PACKAGE DOES NOT INCLUDE (by design, not omission)
  - No .env file (only .env.example.letter-fulfilment, a template -- no
    real secrets in this package).
  - No Procfile / render.yaml / platform start-command file -- none exists
    anywhere in this engagement's working files. Your Render service's
    Start Command is configured directly in the Render dashboard, outside
    this repo, and was not touched or verified this session -- confirm it
    still points at `main:app` (e.g. `uvicorn main:app --host 0.0.0.0
    --port $PORT`) yourself.
  - `tests/letter_pagination_check/_out/` -- regenerable script output,
    left out to keep the ZIP a reasonable size.

FULL DETAIL
See START_HERE.md (this pass's work is section 1j) and ERROR_LOG.md for
the complete technical narrative, and the message this ZIP was delivered
with for the startup/schema/rollback/pilot-checklist summary.
